export interface Location {
  latitude: number;
  longitude: number;
  address: string;
  name?: string;
}

export interface Restaurant {
  id: string;
  name: string;
  image?: string;
  cuisineType: string;
  establishmentType: string;
  priceRange: 1 | 2 | 3 | 4;
  distance: number;
  latitude?: number;
  longitude?: number;
  isOpen: boolean;
  openUntil?: string;
  opensAt?: string;
  tags: string[];
  address: string;
  phone: string;
  description?: string;
  services: string[];
  hasActivePromotions: boolean;
  currentPromotions: string[];
  promoTypes: string[];
  views: number;
  savedCount: number;
}

export interface Dish {
  id: string;
  name: string;
  image?: string;
  price: number;
  originalPrice?: number;
  description: string;
  shortDescription: string;
  restaurant: Restaurant;
  distance: number;
  spiceLevel: number;
  dietTags: string[];
  allergens: string[];
  promoTypes?: string[];
  cartCount: number;
}

export interface Event {
  id: string;
  name: string;
  image?: string;
  price: number;
  description: string;
  shortDescription: string;
  restaurant: Restaurant;
  distance: number;
  likes: number;
  eventType: string;
  date: string;
  time: string;
  duration: string;
  views: number;
  requiresReservation: boolean;
  isFree: boolean;
  tags: string[];
  includes: string[];
  ageRestriction?: string;
  dresscode?: string;
  availableSpots?: number;
}
export interface Filters {
  location: {
    radius: number;
    customLocation?: Location;
  };
  price: number[];
  schedule: string[];
  rating: number;
  establishmentType: string[];
  cuisineType: string[];
  services: string[];
  categories: string[];
  diets: string[];
  allergens: string[];
  spiceLevel: number[];
  occasion: string[];
  scheduleHours: string[];
  hasPromotions: boolean;
  promoType: string[];
  eventType: string[];
  requiresReservation: boolean | null;
  isFree: boolean | null;
  dateRange: string[];
  timeSlots: string[];
}

export type SearchTab = 'restaurants' | 'dishes' | 'events';

export type SortOption = 'distance' | 'rating' | 'price' | 'relevance' | 'expiring';

export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  phone?: string;
  preferences: {
    favoriteLocation?: Location;
    dietaryRestrictions: string[];
    allergens: string[];
    priceRange: number[];
  };
  savedEvents: string[];
  savedRestaurants: string[];
  savedDishes: string[];
  reservations: string[];
  notifications: {
    email: boolean;
    push: boolean;
    calendar: boolean;
  };
}

export interface SavedEvent {
  eventId: string;
  savedAt: string;
  reminderType: 'notification' | 'calendar' | 'both';
  reminderTime: string; // e.g., '1 hour before', '1 day before'
}

export interface SavedItem {
  id: string;
  type: 'event' | 'restaurant' | 'dish';
  savedAt: string;
  reminderType?: 'notification' | 'calendar' | 'both';
  reminderTime?: string;
}

export interface Reservation {
  id: string;
  type: 'restaurant' | 'event';
  restaurantId: string;
  restaurantName: string;
  restaurantImage?: string;
  date: string;
  time: string;
  guests: number;
  status: 'confirmed' | 'pending' | 'cancelled' | 'completed';
  specialRequests?: string;
  createdAt: string;
  confirmationCode: string;
  restaurantPhone: string;
  restaurantAddress: string;
  // Event-specific fields
  eventId?: string;
  eventName?: string;
  eventType?: string;
  eventPrice?: number;
  eventDuration?: string;
  ticketCount?: number;
}