import { Restaurant, Dish, Event } from '../types';
import type { Reservation } from '../types';

export const mockRestaurants: Restaurant[] = [
  // CENTRO HISTÓRICO - CATEDRAL Y ALREDEDORES
  {
    id: '1',
    name: 'Abantal',
    image: 'https://images.pexels.com/photos/260922/pexels-photo-260922.jpeg',
    cuisineType: 'Andaluza Moderna',
    establishmentType: 'Restaurante',
    priceRange: 4,
    latitude: 37.3856,
    longitude: -5.9931,
    isOpen: true,
    openUntil: '23:30',
    tags: ['Estrella Michelin', 'Terraza', 'Exclusivo'],
    address: 'Calle Alcalde Abades 13, Centro, Sevilla',
    phone: '+34 954 540 000',
    description: 'Restaurante con estrella Michelin que ofrece cocina andaluza moderna con técnicas innovadoras.',
    services: ['Reservas online', 'Eventos privados', 'Aire acondicionado'],
    hasActivePromotions: false,
    currentPromotions: [],
    promoTypes: [],
    views: 2847,
    savedCount: 189
  },
  {
    id: '2',
    name: 'El Rinconcillo',
    image: 'https://images.pexels.com/photos/776538/pexels-photo-776538.jpeg',
    cuisineType: 'Andaluza Tradicional',
    establishmentType: 'Bar de tapas',
    priceRange: 2,
    latitude: 37.3925,
    longitude: -5.9908,
    isOpen: true,
    openUntil: '01:00',
    tags: ['Histórico', 'Tapas tradicionales', 'Ambiente auténtico'],
    address: 'Calle Gerona 40, Alfalfa, Sevilla',
    phone: '+34 954 223 183',
    description: 'El bar más antiguo de Sevilla (1670), famoso por sus tapas tradicionales y ambiente histórico.',
    services: ['Para llevar', 'Terraza/Exterior'],
    hasActivePromotions: true,
    currentPromotions: ['Tapa + bebida por 3€'],
    promoTypes: ['Menú del día'],
    views: 3456,
    savedCount: 267
  },
  {
    id: '3',
    name: 'Eslava',
    image: 'https://images.pexels.com/photos/1395964/pexels-photo-1395964.jpeg',
    cuisineType: 'Tapas Modernas',
    establishmentType: 'Bar de tapas',
    priceRange: 3,
    latitude: 37.3838,
    longitude: -5.9873,
    isOpen: true,
    openUntil: '00:30',
    tags: ['Tapas creativas', 'Moderno', 'Popular'],
    address: 'Calle Eslava 3, Santa Cruz, Sevilla',
    phone: '+34 954 906 568',
    description: 'Tapas modernas y creativas en el corazón del barrio de Santa Cruz.',
    services: ['Reservas online', 'Terraza/Exterior'],
    hasActivePromotions: false,
    currentPromotions: [],
    promoTypes: [],
    views: 2134,
    savedCount: 198
  },

  // TRIANA
  {
    id: '4',
    name: 'Casa Cuesta',
    image: 'https://images.pexels.com/photos/1058277/pexels-photo-1058277.jpeg',
    cuisineType: 'Mariscos',
    establishmentType: 'Marisquería',
    priceRange: 3,
    latitude: 37.3844,
    longitude: -6.0021,
    isOpen: true,
    openUntil: '23:00',
    tags: ['Mariscos frescos', 'Triana', 'Familiar'],
    address: 'Calle Castilla 1, Triana, Sevilla',
    phone: '+34 954 333 335',
    description: 'Marisquería tradicional en Triana con los mejores productos del mar.',
    services: ['Terraza/Exterior', 'Reservas online'],
    hasActivePromotions: true,
    currentPromotions: ['Mariscada para 2 personas'],
    promoTypes: ['Menú del día'],
    views: 1876,
    savedCount: 145
  },
  {
    id: '5',
    name: 'Sol y Sombra',
    image: 'https://images.pexels.com/photos/1267697/pexels-photo-1267697.jpeg',
    cuisineType: 'Andaluza',
    establishmentType: 'Bar de tapas',
    priceRange: 2,
    latitude: 37.3856,
    longitude: -6.0031,
    isOpen: true,
    openUntil: '01:30',
    tags: ['Tapas', 'Ambiente local', 'Terraza'],
    address: 'Calle Castilla 151, Triana, Sevilla',
    phone: '+34 954 334 926',
    description: 'Bar de tapas tradicional con ambiente auténtico de Triana.',
    services: ['Terraza/Exterior', 'Para llevar'],
    hasActivePromotions: false,
    currentPromotions: [],
    promoTypes: [],
    views: 1234,
    savedCount: 89
  },

  // ALAMEDA DE HÉRCULES
  {
    id: '6',
    name: 'Duo Tapas',
    image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg',
    cuisineType: 'Fusión',
    establishmentType: 'Bar de tapas',
    priceRange: 3,
    latitude: 37.3981,
    longitude: -5.9919,
    isOpen: true,
    openUntil: '02:00',
    tags: ['Fusión', 'Moderno', 'Ambiente joven'],
    address: 'Alameda de Hércules 31, Alameda, Sevilla',
    phone: '+34 954 906 656',
    description: 'Tapas de fusión con toques internacionales en la vibrante Alameda.',
    services: ['Terraza/Exterior', 'Música en vivo'],
    hasActivePromotions: true,
    currentPromotions: ['Happy hour cócteles'],
    promoTypes: ['Happy Hour'],
    views: 1567,
    savedCount: 123
  },
  {
    id: '7',
    name: 'Habanilla',
    image: 'https://images.pexels.com/photos/2323399/pexels-photo-2323399.jpeg',
    cuisineType: 'Mexicana',
    establishmentType: 'Restaurante',
    priceRange: 2,
    latitude: 37.3975,
    longitude: -5.9925,
    isOpen: true,
    openUntil: '01:00',
    tags: ['Mexicana', 'Cócteles', 'Ambiente festivo'],
    address: 'Alameda de Hércules 63, Alameda, Sevilla',
    phone: '+34 954 907 204',
    description: 'Auténtica comida mexicana con los mejores cócteles de la Alameda.',
    services: ['Terraza/Exterior', 'Delivery', 'Para llevar'],
    hasActivePromotions: false,
    currentPromotions: [],
    promoTypes: [],
    views: 1345,
    savedCount: 98
  },

  // NERVIÓN
  {
    id: '8',
    name: 'Cañabota',
    image: 'https://images.pexels.com/photos/1484516/pexels-photo-1484516.jpeg',
    cuisineType: 'Mariscos',
    establishmentType: 'Marisquería',
    priceRange: 4,
    latitude: 37.3831,
    longitude: -5.9581,
    isOpen: true,
    openUntil: '23:30',
    tags: ['Mariscos premium', 'Exclusivo', 'Moderno'],
    address: 'Avenida Luis de Morales 11, Nervión, Sevilla',
    phone: '+34 954 616 412',
    description: 'Marisquería de alta calidad con los mejores productos del Atlántico.',
    services: ['Reservas online', 'Eventos privados', 'Aire acondicionado'],
    hasActivePromotions: false,
    currentPromotions: [],
    promoTypes: [],
    views: 2456,
    savedCount: 178
  },
  {
    id: '9',
    name: 'Taberna del Alabardero',
    image: 'https://images.pexels.com/photos/2147491/pexels-photo-2147491.jpeg',
    cuisineType: 'Española Tradicional',
    establishmentType: 'Restaurante',
    priceRange: 4,
    latitude: 37.3863,
    longitude: -5.9969,
    isOpen: true,
    openUntil: '23:00',
    tags: ['Tradicional', 'Elegante', 'Histórico'],
    address: 'Calle Zaragoza 20, Centro, Sevilla',
    phone: '+34 954 502 721',
    description: 'Restaurante tradicional con más de 40 años de historia y cocina clásica española.',
    services: ['Reservas online', 'Eventos privados', 'Parking público cerca'],
    hasActivePromotions: false,
    currentPromotions: [],
    promoTypes: [],
    views: 1987,
    savedCount: 156
  },

  // MACARENA
  {
    id: '10',
    name: 'La Azotea',
    image: 'https://images.pexels.com/photos/103566/pexels-photo-103566.jpeg',
    cuisineType: 'Mediterránea',
    establishmentType: 'Restaurante',
    priceRange: 3,
    latitude: 37.4025,
    longitude: -5.9856,
    isOpen: true,
    openUntil: '00:00',
    tags: ['Mediterránea', 'Saludable', 'Terraza'],
    address: 'Calle Feria 136, Macarena, Sevilla',
    phone: '+34 954 916 748',
    description: 'Cocina mediterránea fresca y saludable con productos de temporada.',
    services: ['Terraza/Exterior', 'Reservas online', 'Opciones veganas'],
    hasActivePromotions: true,
    currentPromotions: ['Menú degustación'],
    promoTypes: ['Menú del día'],
    views: 1456,
    savedCount: 112
  },

  // LOS REMEDIOS
  {
    id: '11',
    name: 'Bardot',
    image: 'https://images.pexels.com/photos/1307658/pexels-photo-1307658.jpeg',
    cuisineType: 'Internacional',
    establishmentType: 'Restaurante',
    priceRange: 3,
    latitude: 37.3756,
    longitude: -6.0031,
    isOpen: true,
    openUntil: '01:00',
    tags: ['Internacional', 'Moderno', 'Cócteles'],
    address: 'Avenida de la República Argentina 27, Los Remedios, Sevilla',
    phone: '+34 954 276 565',
    description: 'Restaurante internacional con ambiente moderno y excelente carta de cócteles.',
    services: ['Terraza/Exterior', 'Reservas online', 'Música en vivo'],
    hasActivePromotions: false,
    currentPromotions: [],
    promoTypes: [],
    views: 1678,
    savedCount: 134
  },

  // CENTRO - SIERPES
  {
    id: '12',
    name: 'Robles Placentines',
    image: 'https://images.pexels.com/photos/262959/pexels-photo-262959.jpeg',
    cuisineType: 'Andaluza',
    establishmentType: 'Bar de tapas',
    priceRange: 2,
    latitude: 37.3890,
    longitude: -5.9940,
    isOpen: true,
    openUntil: '00:00',
    tags: ['Tapas tradicionales', 'Céntrico', 'Histórico'],
    address: 'Calle Placentines 4, Centro, Sevilla',
    phone: '+34 954 213 150',
    description: 'Bar de tapas tradicional en pleno centro histórico de Sevilla.',
    services: ['Para llevar', 'Terraza/Exterior'],
    hasActivePromotions: true,
    currentPromotions: ['Ruta de tapas'],
    promoTypes: ['Menú del día'],
    views: 2345,
    savedCount: 189
  },

  // ARENAL
  {
    id: '13',
    name: 'Modesto',
    image: 'https://images.pexels.com/photos/4061522/pexels-photo-4061522.jpeg',
    cuisineType: 'Mariscos',
    establishmentType: 'Marisquería',
    priceRange: 3,
    latitude: 37.3863,
    longitude: -5.9969,
    isOpen: true,
    openUntil: '23:30',
    tags: ['Mariscos', 'Tradicional', 'Familiar'],
    address: 'Calle Cano y Cueto 5, Arenal, Sevilla',
    phone: '+34 954 416 811',
    description: 'Marisquería familiar con tradición desde 1979, especializada en pescados y mariscos frescos.',
    services: ['Reservas online', 'Para llevar', 'Terraza/Exterior'],
    hasActivePromotions: false,
    currentPromotions: [],
    promoTypes: [],
    views: 1789,
    savedCount: 145
  },

  // SANTA CATALINA
  {
    id: '14',
    name: 'La Brunilda',
    image: 'https://images.pexels.com/photos/2097090/pexels-photo-2097090.jpeg',
    cuisineType: 'Tapas Modernas',
    establishmentType: 'Bar de tapas',
    priceRange: 3,
    latitude: 37.3925,
    longitude: -5.9908,
    isOpen: true,
    openUntil: '01:00',
    tags: ['Tapas modernas', 'Popular', 'Creativo'],
    address: 'Calle Galera 5, Alfalfa, Sevilla',
    phone: '+34 954 220 049',
    description: 'Tapas modernas y creativas que han revolucionado la escena gastronómica sevillana.',
    services: ['Para llevar', 'Sin reservas'],
    hasActivePromotions: false,
    currentPromotions: [],
    promoTypes: [],
    views: 3456,
    savedCount: 278
  },

  // ENCARNACIÓN
  {
    id: '15',
    name: 'Puratasca',
    image: 'https://images.pexels.com/photos/1581384/pexels-photo-1581384.jpeg',
    cuisineType: 'Mariscos',
    establishmentType: 'Bar de tapas',
    priceRange: 2,
    latitude: 37.3931,
    longitude: -5.9925,
    isOpen: true,
    openUntil: '00:30',
    tags: ['Mariscos', 'Informal', 'Auténtico'],
    address: 'Plaza de la Encarnación 2, Encarnación, Sevilla',
    phone: '+34 954 501 084',
    description: 'Bar de mariscos informal con productos frescos y ambiente auténtico sevillano.',
    services: ['Para llevar', 'Terraza/Exterior'],
    hasActivePromotions: true,
    currentPromotions: ['Fritura mixta especial'],
    promoTypes: ['Menú del día'],
    views: 1567,
    savedCount: 123
  },

  // FERIA
  {
    id: '16',
    name: 'Casa Morales',
    image: 'https://images.pexels.com/photos/1395964/pexels-photo-1395964.jpeg',
    cuisineType: 'Andaluza Tradicional',
    establishmentType: 'Taberna',
    priceRange: 2,
    latitude: 37.3900,
    longitude: -5.9950,
    isOpen: true,
    openUntil: '00:00',
    tags: ['Histórica', 'Vinos', 'Tradicional'],
    address: 'Calle García de Vinuesa 11, Centro, Sevilla',
    phone: '+34 954 221 242',
    description: 'Taberna histórica desde 1850, famosa por sus vinos y jamones ibéricos.',
    services: ['Catas de vino', 'Productos gourmet'],
    hasActivePromotions: false,
    currentPromotions: [],
    promoTypes: [],
    views: 2134,
    savedCount: 167
  },

  // SANTA CRUZ
  {
    id: '17',
    name: 'Vineria San Telmo',
    image: 'https://images.pexels.com/photos/776538/pexels-photo-776538.jpeg',
    cuisineType: 'Tapas y Vinos',
    establishmentType: 'Vinería',
    priceRange: 3,
    latitude: 37.3844,
    longitude: -5.9881,
    isOpen: true,
    openUntil: '01:30',
    tags: ['Vinos', 'Tapas gourmet', 'Romántico'],
    address: 'Pasaje Catalina de Ribera 4, Santa Cruz, Sevilla',
    phone: '+34 954 410 600',
    description: 'Vinería especializada en vinos selectos y tapas gourmet en el barrio de Santa Cruz.',
    services: ['Catas de vino', 'Terraza/Exterior', 'Reservas online'],
    hasActivePromotions: false,
    currentPromotions: [],
    promoTypes: [],
    views: 1876,
    savedCount: 145
  },

  // BETIS (TRIANA)
  {
    id: '18',
    name: 'Abades Triana',
    image: 'https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg',
    cuisineType: 'Andaluza Moderna',
    establishmentType: 'Restaurante',
    priceRange: 4,
    latitude: 37.3850,
    longitude: -6.0000,
    isOpen: true,
    openUntil: '23:00',
    tags: ['Vistas al río', 'Elegante', 'Terraza'],
    address: 'Calle Betis 69, Triana, Sevilla',
    phone: '+34 954 286 459',
    description: 'Restaurante elegante con vistas al Guadalquivir y cocina andaluza moderna.',
    services: ['Terraza/Exterior', 'Reservas online', 'Eventos privados'],
    hasActivePromotions: false,
    currentPromotions: [],
    promoTypes: [],
    views: 2567,
    savedCount: 198
  },

  // PLAZA NUEVA
  {
    id: '19',
    name: 'Corral del Agua',
    image: 'https://images.pexels.com/photos/2097090/pexels-photo-2097090.jpeg',
    cuisineType: 'Andaluza',
    establishmentType: 'Restaurante',
    priceRange: 3,
    latitude: 37.3825,
    longitude: -5.9856,
    isOpen: true,
    openUntil: '23:30',
    tags: ['Patio andaluz', 'Romántico', 'Tradicional'],
    address: 'Callejón del Agua 6, Santa Cruz, Sevilla',
    phone: '+34 954 224 841',
    description: 'Restaurante con encantador patio andaluz en el corazón del barrio de Santa Cruz.',
    services: ['Terraza/Exterior', 'Reservas online', 'Bodas y eventos'],
    hasActivePromotions: false,
    currentPromotions: [],
    promoTypes: [],
    views: 1789,
    savedCount: 134
  },

  // MUSEO
  {
    id: '20',
    name: 'Becerrita',
    image: 'https://images.pexels.com/photos/1058277/pexels-photo-1058277.jpeg',
    cuisineType: 'Andaluza',
    establishmentType: 'Bar de tapas',
    priceRange: 2,
    latitude: 37.3819,
    longitude: -5.9906,
    isOpen: true,
    openUntil: '00:00',
    tags: ['Tapas tradicionales', 'Ambiente local', 'Económico'],
    address: 'Calle Recaredo 9, Santa Cruz, Sevilla',
    phone: '+34 954 412 057',
    description: 'Bar de tapas tradicional con ambiente auténtico y precios populares.',
    services: ['Para llevar', 'Terraza/Exterior'],
    hasActivePromotions: true,
    currentPromotions: ['Tapa + bebida por 2.50€'],
    promoTypes: ['Menú del día'],
    views: 1345,
    savedCount: 89
  },

  // RESOLANA
  {
    id: '21',
    name: 'La Bartola',
    image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg',
    cuisineType: 'Tapas Creativas',
    establishmentType: 'Bar de tapas',
    priceRange: 3,
    latitude: 37.3856,
    longitude: -5.9894,
    isOpen: true,
    openUntil: '01:00',
    tags: ['Tapas creativas', 'Moderno', 'Innovador'],
    address: 'Plaza de la Pescadería 1, Centro, Sevilla',
    phone: '+34 954 215 666',
    description: 'Tapas creativas e innovadoras con toques modernos en pleno centro.',
    services: ['Terraza/Exterior', 'Reservas online'],
    hasActivePromotions: false,
    currentPromotions: [],
    promoTypes: [],
    views: 1567,
    savedCount: 123
  },

  // ALAMEDA
  {
    id: '22',
    name: 'Eslava Alameda',
    image: 'https://images.pexels.com/photos/2323399/pexels-photo-2323399.jpeg',
    cuisineType: 'Tapas Modernas',
    establishmentType: 'Bar de tapas',
    priceRange: 3,
    latitude: 37.3994,
    longitude: -5.9906,
    isOpen: true,
    openUntil: '01:30',
    tags: ['Tapas modernas', 'Ambiente joven', 'Popular'],
    address: 'Alameda de Hércules 85, Alameda, Sevilla',
    phone: '+34 954 915 204',
    description: 'Sucursal del famoso Eslava en la Alameda, con tapas modernas y ambiente joven.',
    services: ['Terraza/Exterior', 'Para llevar'],
    hasActivePromotions: false,
    currentPromotions: [],
    promoTypes: [],
    views: 1876,
    savedCount: 145
  },

  // MACARENA NORTE
  {
    id: '23',
    name: 'Taberna Coloniales',
    image: 'https://images.pexels.com/photos/1484516/pexels-photo-1484516.jpeg',
    cuisineType: 'Andaluza',
    establishmentType: 'Taberna',
    priceRange: 2,
    latitude: 37.4050,
    longitude: -5.9800,
    isOpen: true,
    openUntil: '00:30',
    tags: ['Montaditos', 'Familiar', 'Tradicional'],
    address: 'Plaza Cristo de Burgos 19, Macarena, Sevilla',
    phone: '+34 954 915 921',
    description: 'Taberna familiar famosa por sus montaditos y ambiente tradicional sevillano.',
    services: ['Para llevar', 'Terraza/Exterior'],
    hasActivePromotions: true,
    currentPromotions: ['Montaditos especiales'],
    promoTypes: ['Menú del día'],
    views: 1234,
    savedCount: 98
  },

  // NERVIÓN COMERCIAL
  {
    id: '24',
    name: 'Bardot Nervión',
    image: 'https://images.pexels.com/photos/103566/pexels-photo-103566.jpeg',
    cuisineType: 'Internacional',
    establishmentType: 'Restaurante',
    priceRange: 3,
    latitude: 37.3850,
    longitude: -5.9600,
    isOpen: true,
    openUntil: '01:00',
    tags: ['Internacional', 'Moderno', 'Zona comercial'],
    address: 'Calle Luis Montoto 150, Nervión, Sevilla',
    phone: '+34 954 574 239',
    description: 'Restaurante internacional moderno en la zona comercial de Nervión.',
    services: ['Reservas online', 'Parking público cerca', 'Aire acondicionado'],
    hasActivePromotions: false,
    currentPromotions: [],
    promoTypes: [],
    views: 1456,
    savedCount: 112
  },

  // TRIANA CERAMICA
  {
    id: '25',
    name: 'Blanca Paloma',
    image: 'https://images.pexels.com/photos/1307658/pexels-photo-1307658.jpeg',
    cuisineType: 'Andaluza',
    establishmentType: 'Bar de tapas',
    priceRange: 2,
    latitude: 37.3875,
    longitude: -6.0044,
    isOpen: true,
    openUntil: '00:00',
    tags: ['Tapas tradicionales', 'Triana', 'Auténtico'],
    address: 'Calle Páginas del Corro 12, Triana, Sevilla',
    phone: '+34 954 333 640',
    description: 'Bar de tapas auténtico en el corazón de Triana con ambiente tradicional.',
    services: ['Para llevar', 'Terraza/Exterior'],
    hasActivePromotions: true,
    currentPromotions: ['Pescaíto frito especial'],
    promoTypes: ['Menú del día'],
    views: 1123,
    savedCount: 87
  },

  // CENTRO COMERCIAL
  {
    id: '26',
    name: 'Poncio',
    image: 'https://images.pexels.com/photos/262959/pexels-photo-262959.jpeg',
    cuisineType: 'Mediterránea',
    establishmentType: 'Restaurante',
    priceRange: 3,
    latitude: 37.3881,
    longitude: -5.9919,
    isOpen: true,
    openUntil: '23:30',
    tags: ['Mediterránea', 'Moderno', 'Saludable'],
    address: 'Calle Pastor y Landero 19, Centro, Sevilla',
    phone: '+34 954 213 773',
    description: 'Cocina mediterránea moderna con ingredientes frescos y presentación cuidada.',
    services: ['Reservas online', 'Opciones veganas', 'Terraza/Exterior'],
    hasActivePromotions: false,
    currentPromotions: [],
    promoTypes: [],
    views: 1678,
    savedCount: 134
  },

  // PLAZA ARMAS
  {
    id: '27',
    name: 'Sal Gorda',
    image: 'https://images.pexels.com/photos/4061522/pexels-photo-4061522.jpeg',
    cuisineType: 'Mariscos',
    establishmentType: 'Marisquería',
    priceRange: 3,
    latitude: 37.3906,
    longitude: -6.0019,
    isOpen: true,
    openUntil: '23:00',
    tags: ['Mariscos', 'Pescados', 'Fresco'],
    address: 'Calle Marqués de Paradas 28, Centro, Sevilla',
    phone: '+34 954 220 202',
    description: 'Marisquería especializada en pescados y mariscos frescos del día.',
    services: ['Para llevar', 'Reservas online'],
    hasActivePromotions: false,
    currentPromotions: [],
    promoTypes: [],
    views: 1345,
    savedCount: 109
  },

  // ENCARNACIÓN SETAS
  {
    id: '28',
    name: 'La Cacharrería',
    image: 'https://images.pexels.com/photos/2147491/pexels-photo-2147491.jpeg',
    cuisineType: 'Tapas Modernas',
    establishmentType: 'Bar de tapas',
    priceRange: 2,
    latitude: 37.3938,
    longitude: -5.9919,
    isOpen: true,
    openUntil: '01:00',
    tags: ['Tapas modernas', 'Informal', 'Creativo'],
    address: 'Calle Regina 2, Encarnación, Sevilla',
    phone: '+34 954 229 945',
    description: 'Bar de tapas modernas con ambiente informal y propuestas creativas.',
    services: ['Para llevar', 'Terraza/Exterior'],
    hasActivePromotions: true,
    currentPromotions: ['Tapas de temporada'],
    promoTypes: ['Menú del día'],
    views: 1567,
    savedCount: 123
  },

  // SANTA CATALINA MERCADO
  {
    id: '29',
    name: 'Mercado Gourmet',
    image: 'https://images.pexels.com/photos/1581384/pexels-photo-1581384.jpeg',
    cuisineType: 'Internacional',
    establishmentType: 'Food Market',
    priceRange: 2,
    latitude: 37.3944,
    longitude: -5.9900,
    isOpen: true,
    openUntil: '00:00',
    tags: ['Variado', 'Moderno', 'Food court'],
    address: 'Calle Regina 18, Santa Catalina, Sevilla',
    phone: '+34 954 501 920',
    description: 'Mercado gourmet con variedad de puestos de comida internacional.',
    services: ['Para llevar', 'Variedad de opciones', 'Ambiente moderno'],
    hasActivePromotions: false,
    currentPromotions: [],
    promoTypes: [],
    views: 1789,
    savedCount: 145
  },

  // PLAZA SALVADOR
  {
    id: '30',
    name: 'Casa Plácido',
    image: 'https://images.pexels.com/photos/2097090/pexels-photo-2097090.jpeg',
    cuisineType: 'Andaluza Tradicional',
    establishmentType: 'Restaurante',
    priceRange: 3,
    latitude: 37.3913,
    longitude: -5.9919,
    isOpen: true,
    openUntil: '23:00',
    tags: ['Tradicional', 'Familiar', 'Histórico'],
    address: 'Plaza del Salvador 6, Centro, Sevilla',
    phone: '+34 954 220 881',
    description: 'Restaurante familiar con cocina andaluza tradicional en la histórica Plaza del Salvador.',
    services: ['Reservas online', 'Terraza/Exterior', 'Menú infantil'],
    hasActivePromotions: false,
    currentPromotions: [],
    promoTypes: [],
    views: 1456,
    savedCount: 118
  }
];

export const mockDishes: Dish[] = [
  {
    id: '1',
    name: 'Paella Valenciana Tradicional',
    image: 'https://images.pexels.com/photos/1458694/pexels-photo-1458694.jpeg',
    price: 18.50,
    originalPrice: 22.00,
    description: 'Auténtica paella valenciana con pollo, conejo, judías verdes, garrofón, tomate, pimiento, azafrán y aceite de oliva virgen extra.',
    shortDescription: 'Paella tradicional con pollo, conejo y verduras de temporada',
    restaurant: mockRestaurants[1],
    distance: 500,
    spiceLevel: 0,
    dietTags: ['Sin gluten'],
    allergens: ['Puede contener trazas de mariscos'],
    promoTypes: ['Menú del día'],
    cartCount: 342
  },
  {
    id: '2',
    name: 'Pizza Margherita Artesanal',
    image: 'https://images.pexels.com/photos/315755/pexels-photo-315755.jpeg',
    price: 12.90,
    description: 'Pizza clásica con salsa de tomate San Marzano, mozzarella di bufala, albahaca fresca y aceite de oliva virgen extra.',
    shortDescription: 'Pizza clásica con mozzarella di bufala y albahaca fresca',
    restaurant: mockRestaurants[2],
    distance: 800,
    spiceLevel: 0,
    dietTags: ['Vegetariano'],
    allergens: ['Gluten', 'Lácteos'],
    promoTypes: ['2x1'],
    cartCount: 189
  },
  {
    id: '3',
    name: 'Hamburguesa BBQ Premium',
    image: 'https://images.pexels.com/photos/1639557/pexels-photo-1639557.jpeg',
    price: 14.95,
    description: 'Hamburguesa de ternera 200g con salsa BBQ, queso cheddar, cebolla caramelizada, bacon crujiente y patatas fritas.',
    shortDescription: 'Hamburguesa premium con salsa BBQ y bacon crujiente',
    restaurant: mockRestaurants[0],
    distance: 350,
    spiceLevel: 1,
    dietTags: [],
    allergens: ['Gluten', 'Lácteos'],
    promoTypes: ['Happy Hour'],
    cartCount: 567
  },
  {
    id: '4',
    name: 'Salmón a la Plancha con Verduras',
    image: 'https://images.pexels.com/photos/1516415/pexels-photo-1516415.jpeg',
    price: 16.90,
    originalPrice: 21.50,
    description: 'Filete de salmón fresco a la plancha acompañado de verduras de temporada salteadas y salsa de limón y eneldo.',
    shortDescription: 'Salmón fresco con verduras y salsa de eneldo',
    restaurant: mockRestaurants[0],
    distance: 350,
    spiceLevel: 0,
    dietTags: ['Sin gluten', 'Saludable'],
    allergens: ['Pescado'],
    promoTypes: ['Descuento estudiantes'],
    cartCount: 298
  },
  {
    id: '5',
    name: 'Risotto de Setas Trufado',
    image: 'https://images.pexels.com/photos/1438672/pexels-photo-1438672.jpeg',
    price: 19.50,
    originalPrice: 24.00,
    description: 'Cremoso risotto de arroz carnaroli con mezcla de setas silvestres, trufa negra, parmesano y un toque de vino blanco.',
    shortDescription: 'Risotto cremoso con setas y trufa negra',
    restaurant: mockRestaurants[2],
    distance: 800,
    spiceLevel: 0,
    dietTags: ['Vegetariano'],
    allergens: ['Lácteos', 'Puede contener sulfitos'],
    promoTypes: ['Primera consumición gratis'],
    cartCount: 145
  }
];

export const mockEvents: Event[] = [
  {
    id: '1',
    name: 'Real Betis vs Sevilla FC - Derbi Sevillano',
    image: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg',
    price: 0,
    description: 'Vive el derbi más emocionante de Sevilla en pantalla gigante con ambiente espectacular. Tapas especiales, cerveza fría y la mejor compañía para disfrutar del fútbol como se merece.',
    shortDescription: 'Derbi sevillano en pantalla gigante con tapas y ambiente',
    restaurant: mockRestaurants[1],
    distance: 500,
    likes: 342,
    eventType: 'Deportivo',
    date: '2025-01-25',
    time: '16:00',
    duration: '2h',
    views: 1247,
    requiresReservation: false,
    isFree: true,
    tags: ['Fútbol', 'Pantalla gigante', 'Tapas especiales', 'Ambiente'],
    includes: ['Retransmisión en HD', 'Tapas del derbi', 'Ambiente garantizado'],
    ageRestriction: 'Todos los públicos',
    dresscode: 'Casual deportivo'
  },
  {
    id: '2',
    name: 'Concierto Acústico - Manu Chao Tributo',
    image: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg',
    price: 15.00,
    description: 'Noche de música en vivo con el mejor tributo a Manu Chao. Versiones acústicas de sus grandes éxitos en un ambiente íntimo y acogedor. Incluye una consumición.',
    shortDescription: 'Tributo acústico a Manu Chao con consumición incluida',
    restaurant: mockRestaurants[4],
    distance: 1200,
    likes: 189,
    eventType: 'Música en vivo',
    date: '2025-01-22',
    time: '22:00',
    duration: '2h',
    views: 892,
    requiresReservation: true,
    isFree: false,
    tags: ['Acústico', 'Tributo', 'Ambiente íntimo', 'Consumición'],
    includes: ['Concierto completo', 'Una consumición', 'Ambiente único'],
    ageRestriction: '+18',
    dresscode: 'Casual'
  },
  {
    id: '3',
    name: 'Champions League - Real Madrid vs PSG',
    image: 'https://images.pexels.com/photos/1884574/pexels-photo-1884574.jpeg',
    price: 0,
    description: 'El partidazo de Champions League en nuestra pantalla de 75 pulgadas. Ambiente de estadio garantizado con cánticos, bufanda del Madrid de regalo y promociones especiales en bebidas.',
    shortDescription: 'Champions League con ambiente de estadio y regalos',
    restaurant: mockRestaurants[0],
    distance: 350,
    likes: 567,
    eventType: 'Deportivo',
    date: '2025-01-28',
    time: '21:00',
    duration: '2h 30min',
    views: 2134,
    requiresReservation: false,
    isFree: true,
    tags: ['Champions', 'Pantalla gigante', 'Regalos', 'Promociones'],
    includes: ['Retransmisión HD', 'Bufanda de regalo', 'Promociones bebidas'],
    ageRestriction: 'Todos los públicos'
  },
  {
    id: '4',
    name: 'Noche de Jazz - Quartet en Vivo',
    image: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg',
    price: 12.00,
    description: 'Sumérgete en los sonidos del jazz clásico con nuestro quartet residente. Una velada perfecta para los amantes de la buena música en un ambiente sofisticado y relajado.',
    shortDescription: 'Jazz en vivo con quartet profesional',
    restaurant: mockRestaurants[4],
    distance: 1200,
    likes: 145,
    eventType: 'Música en vivo',
    date: '2025-01-24',
    time: '20:30',
    duration: '2h',
    views: 987,
    requiresReservation: true,
    isFree: false,
    tags: ['Jazz', 'Quartet', 'Ambiente sofisticado', 'Música clásica'],
    includes: ['Concierto completo', 'Ambiente único', 'Música profesional'],
    ageRestriction: '+21',
    dresscode: 'Elegante casual'
  },
  {
    id: '5',
    name: 'Karaoke Night - Éxitos de los 80s y 90s',
    image: 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg',
    price: 0,
    description: 'Noche de karaoke temática con los mejores éxitos de los 80s y 90s. Ven a cantar tus canciones favoritas, habrá premios para las mejores actuaciones y ambiente de diversión garantizado.',
    shortDescription: 'Karaoke temático con premios y diversión garantizada',
    restaurant: mockRestaurants[1],
    distance: 500,
    likes: 298,
    eventType: 'Social',
    date: '2025-01-26',
    time: '22:00',
    duration: '3h',
    views: 1456,
    requiresReservation: false,
    isFree: true,
    tags: ['Karaoke', 'Años 80-90', 'Premios', 'Diversión'],
    includes: ['Karaoke libre', 'Premios sorpresa', 'Lista de éxitos'],
    ageRestriction: '+18'
  },
  {
    id: '6',
    name: 'Flamenco Fusion - Espectáculo Moderno',
    image: 'https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg',
    price: 25.00,
    description: 'Espectáculo de flamenco fusión que combina la tradición con toques modernos. Artistas jóvenes y talentosos reinterpretan los clásicos con una propuesta fresca y emocionante.',
    shortDescription: 'Flamenco moderno con artistas jóvenes y propuesta fresca',
    restaurant: mockRestaurants[3],
    distance: 600,
    likes: 234,
    eventType: 'Espectáculo',
    date: '2025-01-27',
    time: '21:30',
    duration: '1h 30min',
    views: 1123,
    requiresReservation: true,
    isFree: false,
    tags: ['Flamenco fusion', 'Artistas jóvenes', 'Moderno', 'Emocionante'],
    includes: ['Espectáculo completo', 'Bebida de bienvenida', 'Programa del show'],
    ageRestriction: 'Todos los públicos',
    dresscode: 'Elegante casual'
  },
  {
    id: '7',
    name: 'Liga Española - FC Barcelona vs Atlético',
    image: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg',
    price: 0,
    description: 'Partidazo de La Liga en directo. Ven a disfrutar del fútbol español con tapas especiales del día y promociones en cervezas durante todo el partido.',
    shortDescription: 'Fútbol español con tapas especiales y promociones',
    restaurant: mockRestaurants[2],
    distance: 800,
    likes: 423,
    eventType: 'Deportivo',
    date: '2025-01-29',
    time: '18:30',
    duration: '2h',
    views: 789,
    requiresReservation: false,
    isFree: true,
    tags: ['La Liga', 'Tapas especiales', 'Promociones', 'Ambiente'],
    includes: ['Retransmisión HD', 'Tapas del partido', 'Promociones cerveza'],
    ageRestriction: 'Todos los públicos'
  },
  {
    id: '8',
    name: 'Noche de Rock Español - Tributo a Héroes del Silencio',
    image: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg',
    price: 18.00,
    description: 'Revive los grandes éxitos del rock español con el mejor tributo a Héroes del Silencio. Una noche llena de energía, nostalgia y rock de calidad que no te puedes perder.',
    shortDescription: 'Tributo a Héroes del Silencio con rock español',
    restaurant: mockRestaurants[1],
    distance: 500,
    likes: 312,
    eventType: 'Música en vivo',
    date: '2025-01-30',
    time: '23:00',
    duration: '2h 30min',
    views: 654,
    requiresReservation: true,
    isFree: false,
    tags: ['Rock español', 'Tributo', 'Héroes del Silencio', 'Energía'],
    includes: ['Concierto completo', 'Grandes éxitos', 'Ambiente rockero'],
    ageRestriction: '+18',
    dresscode: 'Rockero casual'
  }
];

export const getFilteredData = (
  data: (Restaurant | Dish | Event)[],
  query: string,
  filters: any
) => {
  let filtered = data;

  // Apply search query
  if (query.length >= 2) {
    filtered = filtered.filter(item =>
      item.name.toLowerCase().includes(query.toLowerCase()) ||
      (item as any).restaurant?.name?.toLowerCase().includes(query.toLowerCase()) ||
      (item as any).cuisineType?.toLowerCase().includes(query.toLowerCase()) ||
      (item as any).eventType?.toLowerCase().includes(query.toLowerCase())
    );
  }

  // Apply distance filter only if radius is set and not the default unlimited value
  if (filters.location?.radius && filters.location.radius < 999999) {
    filtered = filtered.filter(item => item.distance <= filters.location.radius);
  }

  // Apply promotion filter
  if (filters.hasPromotions) {
    filtered = filtered.filter(item => {
      if ('originalPrice' in item && 'restaurant' in item) {
        // For dishes: check if they have a discount
        return item.originalPrice && item.originalPrice > item.price;
      } else if ('hasActivePromotions' in item) {
        // For restaurants: check if they have active promotions
        return item.hasActivePromotions;
      }
      return false;
    });
  }

  // Apply specific promotion type filters
  if (filters.promoType && filters.promoType.length > 0) {
    filtered = filtered.filter(item => {
      if ('promoTypes' in item) {
        return filters.promoType.some((promo: string) =>
          item.promoTypes?.includes(promo)
        );
      }
      return true;
    });
  }

  // Apply event-specific filters
  if (filters.eventType && filters.eventType.length > 0) {
    filtered = filtered.filter(item => {
      if ('eventType' in item) {
        return filters.eventType.includes(item.eventType);
      }
      return true;
    });
  }

  if (filters.requiresReservation !== null) {
    filtered = filtered.filter(item => {
      if ('requiresReservation' in item) {
        return item.requiresReservation === filters.requiresReservation;
      }
      return true;
    });
  }

  if (filters.isFree !== null) {
    filtered = filtered.filter(item => {
      if ('isFree' in item) {
        return item.isFree === filters.isFree;
      }
      return true;
    });
  }
  // Apply allergen filters
  if (filters.allergens && filters.allergens.length > 0) {
    filtered = filtered.filter(item => {
      if ('allergens' in item) {
        return !filters.allergens.some((allergen: string) => 
          item.allergens.some((itemAllergen: string) => 
            itemAllergen.toLowerCase().includes(allergen.toLowerCase())
          )
        );
      }
      return true;
    });
  }

  // Apply diet filters
  if (filters.diets && filters.diets.length > 0) {
    filtered = filtered.filter(item => {
      if ('dietTags' in item) {
        return filters.diets.some((diet: string) => 
          item.dietTags.includes(diet)
        );
      }
      return true;
    });
  }

  // Sort by distance (closest first) when location is available
  filtered.sort((a, b) => a.distance - b.distance);
  return filtered;
};

export const mockReservations: Reservation[] = [
  {
    id: 'res-1',
    restaurantId: '1',
    restaurantName: 'Abantal',
    restaurantImage: 'https://images.pexels.com/photos/260922/pexels-photo-260922.jpeg',
    date: '2025-01-28',
    time: '20:30',
    guests: 2,
    status: 'confirmed',
    specialRequests: 'Mesa junto a la ventana',
    createdAt: '2025-01-20T10:30:00Z',
    confirmationCode: 'AB2025-001',
    restaurantPhone: '+34 954 540 000',
    restaurantAddress: 'Calle Alcalde Abades 13, Centro, Sevilla'
  },
  {
    id: 'res-2',
    restaurantId: '4',
    restaurantName: 'Casa Cuesta',
    restaurantImage: 'https://images.pexels.com/photos/1058277/pexels-photo-1058277.jpeg',
    date: '2025-01-25',
    time: '14:00',
    guests: 4,
    status: 'pending',
    specialRequests: 'Celebración de cumpleaños',
    createdAt: '2025-01-22T16:45:00Z',
    confirmationCode: 'CC2025-002',
    restaurantPhone: '+34 954 333 335',
    restaurantAddress: 'Calle Castilla 1, Triana, Sevilla'
  },
  {
    id: 'res-3',
    restaurantId: '8',
    restaurantName: 'Cañabota',
    restaurantImage: 'https://images.pexels.com/photos/1484516/pexels-photo-1484516.jpeg',
    date: '2025-01-15',
    time: '21:00',
    guests: 2,
    status: 'completed',
    createdAt: '2025-01-10T12:20:00Z',
    confirmationCode: 'CN2025-003',
    restaurantPhone: '+34 954 616 412',
    restaurantAddress: 'Avenida Luis de Morales 11, Nervión, Sevilla'
  },
  {
    id: 'res-4',
    restaurantId: '14',
    restaurantName: 'La Brunilda',
    restaurantImage: 'https://images.pexels.com/photos/2097090/pexels-photo-2097090.jpeg',
    date: '2025-01-30',
    time: '19:00',
    guests: 6,
    status: 'confirmed',
    specialRequests: 'Mesa para grupo grande',
    createdAt: '2025-01-18T09:15:00Z',
    confirmationCode: 'LB2025-004',
    restaurantPhone: '+34 954 220 049',
    restaurantAddress: 'Calle Galera 5, Alfalfa, Sevilla'
  },
  {
    id: 'res-5',
    restaurantId: '2',
    restaurantName: 'El Rinconcillo',
    restaurantImage: 'https://images.pexels.com/photos/776538/pexels-photo-776538.jpeg',
    date: '2025-01-20',
    time: '13:30',
    guests: 3,
    status: 'cancelled',
    createdAt: '2025-01-15T14:30:00Z',
    confirmationCode: 'ER2025-005',
    restaurantPhone: '+34 954 223 183',
    restaurantAddress: 'Calle Gerona 40, Alfalfa, Sevilla'
  },
  {
    id: 'res-6',
    restaurantId: '18',
    restaurantName: 'Abades Triana',
    restaurantImage: 'https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg',
    date: '2025-02-05',
    time: '21:00',
    guests: 2,
    status: 'confirmed',
    specialRequests: 'Mesa con vistas al río',
    createdAt: '2025-01-22T11:30:00Z',
    confirmationCode: 'AT2025-006',
    restaurantPhone: '+34 954 286 459',
    restaurantAddress: 'Calle Betis 69, Triana, Sevilla'
  },
  {
    id: 'res-7',
    restaurantId: '6',
    restaurantName: 'Duo Tapas',
    restaurantImage: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg',
    date: '2025-01-26',
    time: '22:30',
    guests: 4,
    status: 'pending',
    specialRequests: 'Zona tranquila para conversación',
    createdAt: '2025-01-23T14:20:00Z',
    confirmationCode: 'DT2025-007',
    restaurantPhone: '+34 954 906 656',
    restaurantAddress: 'Alameda de Hércules 31, Alameda, Sevilla'
  },
  {
    id: 'res-8',
    restaurantId: '10',
    restaurantName: 'La Azotea',
    restaurantImage: 'https://images.pexels.com/photos/103566/pexels-photo-103566.jpeg',
    date: '2025-02-01',
    time: '13:30',
    guests: 3,
    status: 'confirmed',
    specialRequests: 'Menú vegetariano disponible',
    createdAt: '2025-01-20T16:45:00Z',
    confirmationCode: 'LA2025-008',
    restaurantPhone: '+34 954 916 748',
    restaurantAddress: 'Calle Feria 136, Macarena, Sevilla'
  },
  {
    id: 'res-9',
    restaurantId: '13',
    restaurantName: 'Modesto',
    restaurantImage: 'https://images.pexels.com/photos/4061522/pexels-photo-4061522.jpeg',
    date: '2025-01-18',
    time: '20:00',
    guests: 5,
    status: 'completed',
    specialRequests: 'Mesa redonda para grupo',
    createdAt: '2025-01-12T10:15:00Z',
    confirmationCode: 'MD2025-009',
    restaurantPhone: '+34 954 416 811',
    restaurantAddress: 'Calle Cano y Cueto 5, Arenal, Sevilla'
  },
  {
    id: 'res-10',
    restaurantId: '17',
    restaurantName: 'Vineria San Telmo',
    restaurantImage: 'https://images.pexels.com/photos/776538/pexels-photo-776538.jpeg',
    date: '2025-02-08',
    time: '19:30',
    guests: 2,
    status: 'confirmed',
    specialRequests: 'Cata de vinos incluida',
    createdAt: '2025-01-24T09:30:00Z',
    confirmationCode: 'VS2025-010',
    restaurantPhone: '+34 954 410 600',
    restaurantAddress: 'Pasaje Catalina de Ribera 4, Santa Cruz, Sevilla'
  },
  {
    id: 'res-11',
    restaurantId: '7',
    restaurantName: 'Habanilla',
    restaurantImage: 'https://images.pexels.com/photos/2323399/pexels-photo-2323399.jpeg',
    date: '2025-01-22',
    time: '21:30',
    guests: 6,
    status: 'cancelled',
    specialRequests: 'Celebración de aniversario',
    createdAt: '2025-01-16T13:45:00Z',
    confirmationCode: 'HB2025-011',
    restaurantPhone: '+34 954 907 204',
    restaurantAddress: 'Alameda de Hércules 63, Alameda, Sevilla'
  },
  // Más reservas de restaurantes
  {
    id: 'res-12',
    type: 'restaurant' as const,
    restaurantId: '19',
    restaurantName: 'Corral del Agua',
    restaurantImage: 'https://images.pexels.com/photos/2097090/pexels-photo-2097090.jpeg',
    date: '2025-02-03',
    time: '20:30',
    guests: 2,
    status: 'confirmed' as const,
    specialRequests: 'Cena romántica',
    createdAt: '2025-01-25T15:30:00Z',
    confirmationCode: 'CDA2025-012',
    restaurantPhone: '+34 954 224 841',
    restaurantAddress: 'Callejón del Agua 6, Santa Cruz, Sevilla'
  },
  {
    id: 'res-13',
    type: 'restaurant' as const,
    restaurantId: '26',
    restaurantName: 'Poncio',
    restaurantImage: 'https://images.pexels.com/photos/262959/pexels-photo-262959.jpeg',
    date: '2025-01-31',
    time: '14:00',
    guests: 4,
    status: 'pending' as const,
    specialRequests: 'Menú mediterráneo',
    createdAt: '2025-01-24T12:15:00Z',
    confirmationCode: 'PN2025-013',
    restaurantPhone: '+34 954 213 773',
    restaurantAddress: 'Calle Pastor y Landero 19, Centro, Sevilla'
  },
  // Event Reservations
  {
    id: 'event-res-1',
    type: 'event' as const,
    restaurantId: '1',
    restaurantName: 'Abantal',
    restaurantImage: 'https://images.pexels.com/photos/260922/pexels-photo-260922.jpeg',
    date: '2025-01-25',
    time: '16:00',
    guests: 2,
    status: 'confirmed' as const,
    specialRequests: 'Asientos preferentes',
    createdAt: '2025-01-20T14:30:00Z',
    confirmationCode: 'EVT2025-001',
    restaurantPhone: '+34 954 540 000',
    restaurantAddress: 'Calle Alcalde Abades 13, Centro, Sevilla',
    eventId: '1',
    eventName: 'Real Betis vs Sevilla FC - Derbi Sevillano',
    eventType: 'Deportivo',
    eventPrice: 0,
    eventDuration: '2h',
    ticketCount: 2
  },
  {
    id: 'event-res-2',
    type: 'event' as const,
    restaurantId: '4',
    restaurantName: 'Casa Cuesta',
    restaurantImage: 'https://images.pexels.com/photos/1058277/pexels-photo-1058277.jpeg',
    date: '2025-01-22',
    time: '22:00',
    guests: 4,
    status: 'confirmed' as const,
    specialRequests: 'Mesa cerca del escenario',
    createdAt: '2025-01-18T16:20:00Z',
    confirmationCode: 'EVT2025-002',
    restaurantPhone: '+34 954 333 335',
    restaurantAddress: 'Calle Castilla 1, Triana, Sevilla',
    eventId: '2',
    eventName: 'Concierto Acústico - Manu Chao Tributo',
    eventType: 'Música en vivo',
    eventPrice: 15.00,
    eventDuration: '2h',
    ticketCount: 4
  },
  {
    id: 'event-res-3',
    type: 'event' as const,
    restaurantId: '3',
    restaurantName: 'Eslava',
    restaurantImage: 'https://images.pexels.com/photos/1395964/pexels-photo-1395964.jpeg',
    date: '2025-01-27',
    time: '21:30',
    guests: 2,
    status: 'pending' as const,
    specialRequests: 'Cena incluida',
    createdAt: '2025-01-22T11:15:00Z',
    confirmationCode: 'EVT2025-003',
    restaurantPhone: '+34 954 906 568',
    restaurantAddress: 'Calle Eslava 3, Santa Cruz, Sevilla',
    eventId: '6',
    eventName: 'Flamenco Fusion - Espectáculo Moderno',
    eventType: 'Espectáculo',
    eventPrice: 25.00,
    eventDuration: '1h 30min',
    ticketCount: 2
  },
  {
    id: 'event-res-4',
    type: 'event' as const,
    restaurantId: '1',
    restaurantName: 'Abantal',
    restaurantImage: 'https://images.pexels.com/photos/260922/pexels-photo-260922.jpeg',
    date: '2025-01-26',
    time: '22:00',
    guests: 6,
    status: 'confirmed' as const,
    specialRequests: 'Reserva para grupo',
    createdAt: '2025-01-20T09:45:00Z',
    confirmationCode: 'EVT2025-004',
    restaurantPhone: '+34 954 540 000',
    restaurantAddress: 'Calle Alcalde Abades 13, Centro, Sevilla',
    eventId: '5',
    eventName: 'Karaoke Night - Éxitos de los 80s y 90s',
    eventType: 'Social',
    eventPrice: 0,
    eventDuration: '3h',
    ticketCount: 6
  },
  {
    id: 'event-res-5',
    type: 'event' as const,
    restaurantId: '1',
    restaurantName: 'Abantal',
    restaurantImage: 'https://images.pexels.com/photos/260922/pexels-photo-260922.jpeg',
    date: '2025-01-19',
    time: '23:00',
    guests: 2,
    status: 'completed' as const,
    createdAt: '2025-01-15T13:30:00Z',
    confirmationCode: 'EVT2025-005',
    restaurantPhone: '+34 954 540 000',
    restaurantAddress: 'Calle Alcalde Abades 13, Centro, Sevilla',
    eventId: '8',
    eventName: 'Noche de Rock Español - Tributo a Héroes del Silencio',
    eventType: 'Música en vivo',
    eventPrice: 18.00,
    eventDuration: '2h 30min',
    ticketCount: 2
  }
];