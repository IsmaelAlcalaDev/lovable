/**
 * Radar API Service
 * Servicio optimizado para geolocalización y geocodificación usando Radar API
 * Incluye cache local, manejo de errores y optimizaciones de coste
 */

// Configuración de Radar API
const RADAR_CONFIG = {
  API_KEY: 'prj_test_pk_3245581ac63cb038843f347723604bbfc2412a83',
  BASE_URL: 'https://api.radar.io/v1',
  CACHE_DURATION: 5 * 60 * 1000, // 5 minutos en millisegundos
  REQUEST_TIMEOUT: 10000, // 10 segundos
  MAX_RETRIES: 2
};

// Tipos de datos
export interface RadarLocation {
  latitude: number;
  longitude: number;
  accuracy?: number;
  address: string;
  formattedAddress: string;
  components: {
    street?: string;
    number?: string;
    neighborhood?: string;
    city?: string;
    state?: string;
    country?: string;
    postalCode?: string;
  };
  confidence?: string;
  source: 'gps' | 'wifi' | 'cell' | 'ip';
}

export interface RadarError {
  code: 'PERMISSION_DENIED' | 'POSITION_UNAVAILABLE' | 'TIMEOUT' | 'API_ERROR' | 'NETWORK_ERROR';
  message: string;
  details?: any;
}

// Cache local para optimizar peticiones
class RadarCache {
  private cache = new Map<string, { data: any; timestamp: number }>();

  set(key: string, data: any): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now()
    });
  }

  get(key: string): any | null {
    const cached = this.cache.get(key);
    if (!cached) return null;

    // Verificar si el cache ha expirado
    if (Date.now() - cached.timestamp > RADAR_CONFIG.CACHE_DURATION) {
      this.cache.delete(key);
      return null;
    }

    return cached.data;
  }

  clear(): void {
    this.cache.clear();
  }

  // Limpiar cache expirado automáticamente
  cleanup(): void {
    const now = Date.now();
    for (const [key, value] of this.cache.entries()) {
      if (now - value.timestamp > RADAR_CONFIG.CACHE_DURATION) {
        this.cache.delete(key);
      }
    }
  }
}

const cache = new RadarCache();

// Limpiar cache cada 10 minutos
setInterval(() => cache.cleanup(), 10 * 60 * 1000);

/**
 * Realiza petición HTTP con reintentos y timeout
 */
async function fetchWithRetry(url: string, options: RequestInit, retries = RADAR_CONFIG.MAX_RETRIES): Promise<Response> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), RADAR_CONFIG.REQUEST_TIMEOUT);

  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    return response;
  } catch (error) {
    clearTimeout(timeoutId);

    if (retries > 0 && error.name !== 'AbortError') {
      console.warn(`Reintentando petición a Radar API. Intentos restantes: ${retries}`);
      await new Promise(resolve => setTimeout(resolve, 1000)); // Esperar 1 segundo
      return fetchWithRetry(url, options, retries - 1);
    }

    throw error;
  }
}

/**
 * Obtiene la ubicación actual del usuario con alta precisión
 */
export function getCurrentPosition(): Promise<GeolocationPosition> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject({
        code: 'POSITION_UNAVAILABLE',
        message: 'La geolocalización no está soportada en este navegador. Por favor, usa la búsqueda manual de direcciones.'
      });
      return;
    }

    console.log('🛰️ Solicitando ubicación GPS del navegador...');

    navigator.geolocation.getCurrentPosition(
      (position) => {
        console.log('✅ Coordenadas GPS obtenidas:', {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: `${position.coords.accuracy}m`
        });
        resolve(position);
      },
      (error) => {
        console.error('❌ Error de geolocalización del navegador:', error);
        let radarError: RadarError;
        
        switch (error.code) {
          case error.PERMISSION_DENIED:
            radarError = {
              code: 'PERMISSION_DENIED',
              message: 'Permisos de ubicación denegados. Por favor, permite el acceso a tu ubicación en la configuración del navegador o usa la búsqueda manual.'
            };
            break;
          case error.POSITION_UNAVAILABLE:
            radarError = {
              code: 'POSITION_UNAVAILABLE',
              message: 'No se pudo determinar tu ubicación. Verifica que el GPS esté activado o usa la búsqueda manual de direcciones.'
            };
            break;
          case error.TIMEOUT:
            radarError = {
              code: 'TIMEOUT',
              message: 'Tiempo de espera agotado al obtener la ubicación. Inténtalo de nuevo o usa la búsqueda manual.'
            };
            break;
          default:
            radarError = {
              code: 'POSITION_UNAVAILABLE',
              message: 'Error desconocido al obtener la ubicación. Usa la búsqueda manual de direcciones.'
            };
        }
        
        reject(radarError);
      },
      {
        enableHighAccuracy: true,   // 🛰️ Pide al dispositivo usar GPS si está disponible
        timeout: 15000,             // ⏱️ 15 segundos para obtener ubicación (GPS necesita más tiempo)
        maximumAge: 0               // 🚫 No usar ubicación cacheada, siempre obtener nueva posición
      }
    );
  });
}

/**
 * Convierte coordenadas en dirección usando Radar API Reverse Geocoding
 */
export async function reverseGeocode(latitude: number, longitude: number): Promise<RadarLocation> {
  // Crear clave de cache basada en coordenadas (redondeadas para optimizar)
  const cacheKey = `reverse_${latitude.toFixed(6)}_${longitude.toFixed(6)}`;
  
  // Verificar cache primero
  const cached = cache.get(cacheKey);
  if (cached) {
    console.log('📦 Usando resultado cacheado para reverse geocoding:', cached.formattedAddress);
    return cached;
  }

  console.log('🔍 Realizando reverse geocoding con Radar API para:', `${latitude}, ${longitude}`);

  try {
    const url = `${RADAR_CONFIG.BASE_URL}/geocode/reverse?coordinates=${latitude},${longitude}&layers=address,place`;
    
    const response = await fetchWithRetry(url, {
      method: 'GET',
      headers: {
        'Authorization': RADAR_CONFIG.API_KEY,
        'Content-Type': 'application/json'
      }
    });

    const data = await response.json();

    if (!data.addresses || data.addresses.length === 0) {
      throw new Error('No se encontró información de dirección para estas coordenadas');
    }

    const address = data.addresses[0];
    
    // Construir objeto de ubicación optimizado
    const location: RadarLocation = {
      latitude,
      longitude,
      accuracy: address.confidence === 'exact' ? 10 : address.confidence === 'interpolated' ? 50 : 100,
      address: address.formattedAddress || 'Dirección no disponible',
      formattedAddress: address.formattedAddress || 'Dirección no disponible',
      components: {
        street: address.street,
        number: address.number,
        neighborhood: address.neighborhood,
        city: address.city,
        state: address.state,
        country: address.country,
        postalCode: address.postalCode
      },
      confidence: address.confidence,
      source: 'gps' // Asumimos GPS ya que viene de getCurrentPosition
    };

    // Guardar en cache
    cache.set(cacheKey, location);
    
    console.log('✅ Reverse geocoding exitoso con Radar API:', location.formattedAddress);
    return location;

  } catch (error) {
    console.error('❌ Error en reverse geocoding:', error);
    
    const radarError: RadarError = {
      code: 'API_ERROR',
      message: 'Error al obtener la dirección. Inténtalo de nuevo.',
      details: error
    };
    
    throw radarError;
  }
}

/**
 * Autocompletado de direcciones usando Radar API Forward Geocoding
 * Optimizado para reducir peticiones con debounce
 */
export async function searchAddresses(query: string, limit = 5): Promise<RadarLocation[]> {
  if (!query || query.length < 3) {
    return [];
  }

  console.log('🔍 Buscando direcciones con Radar API:', query);

  // Crear clave de cache
  const cacheKey = `search_${query.toLowerCase()}_${limit}`;
  
  // Verificar cache
  const cached = cache.get(cacheKey);
  if (cached) {
    console.log('📦 Usando resultados cacheados para búsqueda:', `${cached.length} resultados`);
    return cached;
  }

  try {
    const url = `${RADAR_CONFIG.BASE_URL}/geocode/forward?query=${encodeURIComponent(query)}&limit=${limit}&layers=address,place`;
    
    const response = await fetchWithRetry(url, {
      method: 'GET',
      headers: {
        'Authorization': RADAR_CONFIG.API_KEY,
        'Content-Type': 'application/json'
      }
    });

    const data = await response.json();

    if (!data.addresses || data.addresses.length === 0) {
      return [];
    }

    const locations: RadarLocation[] = data.addresses.map((address: any) => ({
      latitude: address.latitude,
      longitude: address.longitude,
      accuracy: address.confidence === 'exact' ? 10 : address.confidence === 'interpolated' ? 50 : 100,
      address: address.formattedAddress || 'Dirección no disponible',
      formattedAddress: address.formattedAddress || 'Dirección no disponible',
      components: {
        street: address.street,
        number: address.number,
        neighborhood: address.neighborhood,
        city: address.city,
        state: address.state,
        country: address.country,
        postalCode: address.postalCode
      },
      confidence: address.confidence,
      source: 'wifi' // Búsqueda manual
    }));

    // Guardar en cache
    cache.set(cacheKey, locations);
    
    console.log(`✅ Búsqueda exitosa con Radar API: ${locations.length} resultados para "${query}"`);
    return locations;

  } catch (error) {
    console.error('❌ Error en búsqueda de direcciones:', error);
    return [];
  }
}

/**
 * Función principal: Obtiene ubicación actual y la convierte a dirección
 */
export async function getCurrentLocationWithAddress(): Promise<RadarLocation> {
  try {
    console.log('🔍 Iniciando proceso de geolocalización completo con Radar API...');
    
    // Paso 1: Obtener coordenadas del navegador
    const position = await getCurrentPosition();
    const { latitude, longitude, accuracy } = position.coords;
    
    console.log(`📍 Coordenadas GPS obtenidas del navegador: ${latitude}, ${longitude} (precisión: ${accuracy}m)`);
    
    // Paso 2: Convertir coordenadas a dirección usando Radar API
    const location = await reverseGeocode(latitude, longitude);
    
    // Actualizar con datos reales de precisión del GPS
    location.accuracy = accuracy || location.accuracy;
    
    console.log('🎯 Proceso de geolocalización completado exitosamente:', {
      address: location.formattedAddress,
      coordinates: `${location.latitude}, ${location.longitude}`,
      accuracy: `${location.accuracy}m`,
      source: location.source
    });
    
    return location;
    
  } catch (error) {
    console.error('❌ Error completo en geolocalización con Radar API:', error);
    throw error;
  }
}

/**
 * Utilidad para formatear direcciones de manera consistente
 */
export function formatAddress(location: RadarLocation, style: 'short' | 'full' = 'full'): string {
  const { components } = location;
  
  if (style === 'short') {
    const parts = [];
    if (components.street) parts.push(components.street);
    if (components.number) parts[parts.length - 1] += ` ${components.number}`;
    if (components.city) parts.push(components.city);
    return parts.join(', ') || location.address;
  }
  
  // Formato completo
  return location.formattedAddress || location.address;
}

/**
 * Limpiar cache manualmente (útil para testing o reset)
 */
export function clearCache(): void {
  cache.clear();
  console.log('🧹 Cache de Radar API limpiado');
}

/**
 * Obtener estadísticas de cache (útil para debugging)
 */
export function getCacheStats(): { size: number; keys: string[] } {
  return {
    size: cache['cache'].size,
    keys: Array.from(cache['cache'].keys())
  };
}