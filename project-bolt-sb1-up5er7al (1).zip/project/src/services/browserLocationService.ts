/**
 * Browser-only Geolocation Service
 * Sistema de geolocalización usando solo la API del navegador
 * Más rápido pero menos preciso que Radar API
 */

export interface BrowserLocation {
  latitude: number;
  longitude: number;
  accuracy: number;
  address: string; // Dirección geocodificada
  formattedAddress: string; // Dirección completa formateada
  source: 'browser-gps';
  timestamp: number;
}

export interface BrowserLocationError {
  code: 'PERMISSION_DENIED' | 'POSITION_UNAVAILABLE' | 'TIMEOUT' | 'NOT_SUPPORTED';
  message: string;
}

/**
 * Geocodificación inversa usando Nominatim (OpenStreetMap)
 */
async function reverseGeocode(latitude: number, longitude: number): Promise<string> {
  try {
    console.log('🌐 Iniciando geocodificación inversa para:', `${latitude}, ${longitude}`);
    
    const response = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=18&addressdetails=1`,
      {
        headers: {
          'User-Agent': 'LaCartica-App/1.0'
        }
      }
    );

    if (!response.ok) {
      throw new Error('Geocoding failed');
    }

    const data = await response.json();
    console.log('📍 Respuesta de geocodificación:', data);
    
    if (data && data.address) {
      const addr = data.address;
      const parts = [];
      
      // Construir dirección de forma inteligente
      if (addr.road && addr.house_number) {
        parts.push(`${addr.road} ${addr.house_number}`);
      } else if (addr.road) {
        parts.push(addr.road);
      } else if (addr.pedestrian) {
        parts.push(addr.pedestrian);
      }
      
      if (addr.neighbourhood) {
        parts.push(addr.neighbourhood);
      } else if (addr.suburb) {
        parts.push(addr.suburb);
      } else if (addr.quarter) {
        parts.push(addr.quarter);
      }
      
      if (addr.city) {
        parts.push(addr.city);
      } else if (addr.town) {
        parts.push(addr.town);
      } else if (addr.village) {
        parts.push(addr.village);
      }
      
      if (addr.state) {
        parts.push(addr.state);
      }
      
      const formattedAddress = parts.length > 0 ? parts.join(', ') : data.display_name;
      console.log('✅ Dirección formateada:', formattedAddress);
      return formattedAddress;
    }
    
    console.log('⚠️ Sin datos de dirección, usando display_name:', data.display_name);
    return data.display_name || `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
  } catch (error) {
    console.warn('Geocoding failed:', error);
    return `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
  }
}

/**
 * Obtiene la ubicación usando solo la Geolocation API del navegador
 */
export async function getBrowserLocation(): Promise<BrowserLocation> {
  return new Promise((resolve, reject) => {
    // Verificar soporte
    if (!navigator.geolocation) {
      reject({
        code: 'NOT_SUPPORTED',
        message: 'La geolocalización no está soportada en este navegador'
      });
      return;
    }

    console.log('🌐 Obteniendo ubicación con API del navegador...');

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude, accuracy } = position.coords;
        
        console.log('📍 Coordenadas obtenidas, geocodificando dirección...');
        
        try {
          // Obtener dirección real mediante geocodificación
          const geocodedAddress = await reverseGeocode(latitude, longitude);
          
          const location: BrowserLocation = {
            latitude,
            longitude,
            accuracy: accuracy || 100,
            address: geocodedAddress,
            formattedAddress: geocodedAddress,
            source: 'browser-gps',
            timestamp: Date.now()
          };

          console.log('✅ Ubicación y dirección obtenidas:', {
            coordinates: `${latitude}, ${longitude}`,
            address: geocodedAddress,
            accuracy: `${accuracy}m`
          });

          resolve(location);
        } catch (geocodeError) {
          // Si falla la geocodificación, usar coordenadas como fallback
          const fallbackAddress = `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
          
          const location: BrowserLocation = {
            latitude,
            longitude,
            accuracy: accuracy || 100,
            address: fallbackAddress,
            formattedAddress: fallbackAddress,
            source: 'browser-gps',
            timestamp: Date.now()
          };

          console.log('⚠️ Geocodificación falló, usando coordenadas:', {
            coordinates: `${latitude}, ${longitude}`,
            accuracy: `${accuracy}m`
          });

          resolve(location);
        }
      },
      (error) => {
        console.error('❌ Error de geolocalización del navegador:', error);
        
        let browserError: BrowserLocationError;
        
        switch (error.code) {
          case error.PERMISSION_DENIED:
            browserError = {
              code: 'PERMISSION_DENIED',
              message: 'Permisos de ubicación denegados. Permite el acceso en la configuración del navegador.'
            };
            break;
          case error.POSITION_UNAVAILABLE:
            browserError = {
              code: 'POSITION_UNAVAILABLE',
              message: 'No se pudo determinar tu ubicación. Verifica que el GPS esté activado.'
            };
            break;
          case error.TIMEOUT:
            browserError = {
              code: 'TIMEOUT',
              message: 'Tiempo de espera agotado. Inténtalo de nuevo.'
            };
            break;
          default:
            browserError = {
              code: 'POSITION_UNAVAILABLE',
              message: 'Error desconocido al obtener la ubicación.'
            };
        }
        
        reject(browserError);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000, // 10 segundos (más rápido que Radar)
        maximumAge: 60000 // Cache por 1 minuto
      }
    );
  });
}

/**
 * Formatea la ubicación del navegador para mostrar
 */
export function formatBrowserLocation(location: BrowserLocation): string {
  return location.formattedAddress;
}

/**
 * Verifica si el navegador soporta geolocalización
 */
export function isBrowserGeolocationSupported(): boolean {
  return 'geolocation' in navigator;
}

/**
 * Obtiene información sobre las capacidades de geolocalización del navegador
 */
export function getBrowserGeolocationInfo(): {
  supported: boolean;
  secure: boolean;
  permissions: boolean;
} {
  return {
    supported: 'geolocation' in navigator,
    secure: location.protocol === 'https:' || location.hostname === 'localhost',
    permissions: 'permissions' in navigator
  };
}