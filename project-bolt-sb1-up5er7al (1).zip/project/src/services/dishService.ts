import { supabase } from '../lib/supabase';
import { Dish } from '../types';

// Calculate distance between two points
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371e3;
  const φ1 = lat1 * Math.PI / 180;
  const φ2 = lat2 * Math.PI / 180;
  const Δφ = (lat2 - lat1) * Math.PI / 180;
  const Δλ = (lon2 - lon1) * Math.PI / 180;

  const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
            Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c;
}

export async function getDishes(
  userLat?: number,
  userLng?: number,
  maxDistance?: number,
  searchQuery?: string,
  filters?: any
): Promise<Dish[]> {
  try {
    let query = supabase
      .from('dishes')
      .select(`
        *,
        restaurants!inner(
          id,
          name,
          slug,
          address,
          latitude,
          longitude,
          phone,
          price_range,
          establishment_types(name),
          restaurant_cuisines(cuisine_types(name))
        ),
        dish_categories(name),
        menu_sections(name)
      `)
      .eq('is_active', true)
      .is('deleted_at', null)
      .eq('restaurants.is_active', true)
      .eq('restaurants.is_published', true);

    // Apply search query
    if (searchQuery && searchQuery.length >= 2) {
      query = query.or(`name.ilike.%${searchQuery}%,description.ilike.%${searchQuery}%`);
    }

    // Apply diet filters
    if (filters?.diets?.length > 0) {
      const dietConditions = [];
      if (filters.diets.includes('Vegetariano')) dietConditions.push('is_vegetarian.eq.true');
      if (filters.diets.includes('Vegano')) dietConditions.push('is_vegan.eq.true');
      if (filters.diets.includes('Sin gluten')) dietConditions.push('is_gluten_free.eq.true');
      if (filters.diets.includes('Sin lactosa')) dietConditions.push('is_lactose_free.eq.true');
      if (filters.diets.includes('Saludable')) dietConditions.push('is_healthy.eq.true');
      
      if (dietConditions.length > 0) {
        query = query.or(dietConditions.join(','));
      }
    }

    // Apply category filters
    if (filters?.categories?.length > 0) {
      const categoryIds = await getCategoryIds(filters.categories);
      if (categoryIds.length > 0) {
        query = query.in('category_id', categoryIds);
      }
    }

    const { data, error } = await query.order('favorites_count', { ascending: false });

    if (error) {
      console.error('Error fetching dishes:', error);
      return [];
    }

    // Transform data to match our Dish interface
    const dishes: Dish[] = (data || []).map((dish: any) => {
      const restaurant = dish.restaurants;
      const distance = userLat && userLng 
        ? calculateDistance(userLat, userLng, restaurant.latitude, restaurant.longitude)
        : 999999;

      // Convert price range
      const priceRange = restaurant.price_range === 'EUR' ? 1 :
                        restaurant.price_range === 'EUR_EUR' ? 2 :
                        restaurant.price_range === 'EUR_EUR_EUR' ? 3 : 4;

      return {
        id: dish.id.toString(),
        name: dish.name,
        image: dish.image_url || undefined,
        price: dish.base_price,
        description: dish.description || '',
        shortDescription: dish.description?.substring(0, 100) + '...' || '',
        restaurant: {
          id: restaurant.id.toString(),
          name: restaurant.name,
          cuisineType: restaurant.restaurant_cuisines?.[0]?.cuisine_types?.name || 'Restaurante',
          establishmentType: restaurant.establishment_types?.name || 'Restaurante',
          priceRange,
          distance,
          latitude: restaurant.latitude,
          longitude: restaurant.longitude,
          isOpen: true, // TODO: Calculate based on schedule
          tags: [],
          address: restaurant.address,
          phone: restaurant.phone || '',
          services: [],
          hasActivePromotions: false,
          currentPromotions: [],
          promoTypes: [],
          views: 0,
          savedCount: 0
        },
        distance,
        spiceLevel: dish.spice_level || 0,
        dietTags: getDietTags(dish),
        allergens: dish.allergens || [],
        cartCount: Math.floor(Math.random() * 500) + 50 // Mock for now
      };
    });

    // Filter by distance if specified
    if (maxDistance && userLat && userLng) {
      return dishes.filter(dish => dish.distance <= maxDistance);
    }

    // Sort by distance if user location is available
    if (userLat && userLng) {
      dishes.sort((a, b) => a.distance - b.distance);
    }

    return dishes;

  } catch (error) {
    console.error('Error in getDishes:', error);
    return [];
  }
}

// Helper function to get diet tags
function getDietTags(dish: any): string[] {
  const tags = [];
  if (dish.is_vegetarian) tags.push('Vegetariano');
  if (dish.is_vegan) tags.push('Vegano');
  if (dish.is_gluten_free) tags.push('Sin gluten');
  if (dish.is_lactose_free) tags.push('Sin lactosa');
  if (dish.is_healthy) tags.push('Saludable');
  return tags;
}

// Helper function to get category IDs
async function getCategoryIds(names: string[]): Promise<number[]> {
  const { data } = await supabase
    .from('dish_categories')
    .select('id')
    .in('name', names);
  
  return data?.map(item => item.id) || [];
}