import { supabase } from '../lib/supabase';
import { Event } from '../types';

// Calculate distance between two points
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371e3;
  const φ1 = lat1 * Math.PI / 180;
  const φ2 = lat2 * Math.PI / 180;
  const Δφ = (lat2 - lat1) * Math.PI / 180;
  const Δλ = (lon2 - lon1) * Math.PI / 180;

  const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
            Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c;
}

export async function getEvents(
  userLat?: number,
  userLng?: number,
  maxDistance?: number,
  searchQuery?: string,
  filters?: any
): Promise<Event[]> {
  try {
    let query = supabase
      .from('events')
      .select(`
        *,
        restaurants!inner(
          id,
          name,
          slug,
          address,
          latitude,
          longitude,
          phone,
          price_range,
          establishment_types(name),
          restaurant_cuisines(cuisine_types(name))
        )
      `)
      .eq('is_active', true)
      .is('deleted_at', null)
      .eq('restaurants.is_active', true)
      .eq('restaurants.is_published', true)
      .gte('event_date', new Date().toISOString().split('T')[0]); // Only future events

    // Apply search query
    if (searchQuery && searchQuery.length >= 2) {
      query = query.or(`name.ilike.%${searchQuery}%,description.ilike.%${searchQuery}%,category.ilike.%${searchQuery}%`);
    }

    // Apply event type filters
    if (filters?.eventType?.length > 0) {
      query = query.in('category', filters.eventType);
    }

    // Apply free/paid filter
    if (filters?.isFree === true) {
      query = query.eq('is_free', true);
    } else if (filters?.isFree === false) {
      query = query.eq('is_free', false);
    }

    // Apply reservation filter
    if (filters?.requiresReservation === true) {
      query = query.eq('requires_reservation', true);
    } else if (filters?.requiresReservation === false) {
      query = query.eq('requires_reservation', false);
    }

    const { data, error } = await query.order('event_date', { ascending: true });

    if (error) {
      console.error('Error fetching events:', error);
      return [];
    }

    // Transform data to match our Event interface
    const events: Event[] = (data || []).map((event: any) => {
      const restaurant = event.restaurants;
      const distance = userLat && userLng 
        ? calculateDistance(userLat, userLng, restaurant.latitude, restaurant.longitude)
        : 999999;

      // Convert price range
      const priceRange = restaurant.price_range === 'EUR' ? 1 :
                        restaurant.price_range === 'EUR_EUR' ? 2 :
                        restaurant.price_range === 'EUR_EUR_EUR' ? 3 : 4;

      // Calculate duration
      const startTime = new Date(`2000-01-01T${event.start_time}`);
      const endTime = event.end_time ? new Date(`2000-01-01T${event.end_time}`) : new Date(startTime.getTime() + 2 * 60 * 60 * 1000);
      const durationMs = endTime.getTime() - startTime.getTime();
      const durationHours = Math.floor(durationMs / (1000 * 60 * 60));
      const durationMinutes = Math.floor((durationMs % (1000 * 60 * 60)) / (1000 * 60));
      const duration = durationHours > 0 ? `${durationHours}h${durationMinutes > 0 ? ` ${durationMinutes}min` : ''}` : `${durationMinutes}min`;

      return {
        id: event.id.toString(),
        name: event.name,
        image: event.image_url || undefined,
        price: event.entry_price || 0,
        description: event.description,
        shortDescription: event.description.substring(0, 100) + '...',
        restaurant: {
          id: restaurant.id.toString(),
          name: restaurant.name,
          cuisineType: restaurant.restaurant_cuisines?.[0]?.cuisine_types?.name || 'Restaurante',
          establishmentType: restaurant.establishment_types?.name || 'Restaurante',
          priceRange,
          distance,
          latitude: restaurant.latitude,
          longitude: restaurant.longitude,
          isOpen: true,
          tags: [],
          address: restaurant.address,
          phone: restaurant.phone || '',
          services: [],
          hasActivePromotions: false,
          currentPromotions: [],
          promoTypes: [],
          views: 0,
          savedCount: 0
        },
        distance,
        likes: event.favorites_count || 0,
        eventType: event.category,
        date: event.event_date,
        time: event.start_time,
        duration,
        views: Math.floor(Math.random() * 2000) + 100,
        requiresReservation: event.requires_reservation,
        isFree: event.is_free,
        tags: event.tags || [],
        includes: [], // TODO: Parse from description or separate field
        ageRestriction: event.age_restriction,
        dresscode: event.dress_code,
        availableSpots: event.available_seats
      };
    });

    // Filter by distance if specified
    if (maxDistance && userLat && userLng) {
      return events.filter(event => event.distance <= maxDistance);
    }

    // Sort by date and distance
    if (userLat && userLng) {
      events.sort((a, b) => {
        const dateA = new Date(a.date).getTime();
        const dateB = new Date(b.date).getTime();
        if (dateA !== dateB) return dateA - dateB;
        return a.distance - b.distance;
      });
    }

    return events;

  } catch (error) {
    console.error('Error in getEvents:', error);
    return [];
  }
}