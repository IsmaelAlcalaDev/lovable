import { supabase } from '../lib/supabase';
import { Restaurant } from '../types';

// Calculate distance between two points using Haversine formula
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371e3; // Earth's radius in metres
  const φ1 = lat1 * Math.PI / 180;
  const φ2 = lat2 * Math.PI / 180;
  const Δφ = (lat2 - lat1) * Math.PI / 180;
  const Δλ = (lon2 - lon1) * Math.PI / 180;

  const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
            Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c; // in metres
}

// Convert price range enum to number
function convertPriceRange(priceRange: string): number {
  switch (priceRange) {
    case 'EUR': return 1;
    case 'EUR_EUR': return 2;
    case 'EUR_EUR_EUR': return 3;
    case 'EUR_EUR_EUR_EUR': return 4;
    default: return 2;
  }
}

// Get restaurants with location filtering
export async function getRestaurants(
  userLat?: number,
  userLng?: number,
  maxDistance?: number,
  searchQuery?: string,
  filters?: any
): Promise<Restaurant[]> {
  try {
    let query = supabase
      .from('restaurants')
      .select(`
        *,
        establishment_types(name),
        cities(name),
        districts(name),
        restaurant_cuisines(cuisine_types(name)),
        restaurant_services(services(name)),
        restaurant_schedules(*)
      `)
      .eq('is_active', true)
      .eq('is_published', true)
      .is('deleted_at', null);

    // Apply search query
    if (searchQuery && searchQuery.length >= 2) {
      query = query.or(`name.ilike.%${searchQuery}%,description.ilike.%${searchQuery}%`);
    }

    // Apply filters
    if (filters?.establishmentType?.length > 0) {
      const establishmentTypeIds = await getEstablishmentTypeIds(filters.establishmentType);
      query = query.in('establishment_type_id', establishmentTypeIds);
    }

    if (filters?.price?.length > 0) {
      const priceRanges = filters.price.map((p: number) => {
        switch (p) {
          case 1: return 'EUR';
          case 2: return 'EUR_EUR';
          case 3: return 'EUR_EUR_EUR';
          case 4: return 'EUR_EUR_EUR_EUR';
          default: return 'EUR_EUR';
        }
      });
      query = query.in('price_range', priceRanges);
    }

    const { data, error } = await query.order('favorites_count', { ascending: false });

    if (error) {
      console.error('Error fetching restaurants:', error);
      return [];
    }

    // Transform data to match our Restaurant interface
    const restaurants: Restaurant[] = (data || []).map((restaurant: any) => {
      const distance = userLat && userLng 
        ? calculateDistance(userLat, userLng, restaurant.latitude, restaurant.longitude)
        : 999999;

      // Check if restaurant is currently open
      const now = new Date();
      const currentDay = now.getDay(); // 0 = Sunday, 1 = Monday, etc.
      const currentTime = now.toTimeString().slice(0, 5); // HH:MM format
      
      const todaySchedule = restaurant.restaurant_schedules?.find(
        (schedule: any) => schedule.day_of_week === (currentDay === 0 ? 7 : currentDay)
      );
      
      const isOpen = todaySchedule && !todaySchedule.is_closed && 
        currentTime >= todaySchedule.opening_time && 
        currentTime <= todaySchedule.closing_time;

      return {
        id: restaurant.id.toString(),
        name: restaurant.name,
        image: restaurant.cover_image_url || undefined,
        cuisineType: restaurant.restaurant_cuisines?.[0]?.cuisine_types?.name || 'Restaurante',
        establishmentType: restaurant.establishment_types?.name || 'Restaurante',
        priceRange: convertPriceRange(restaurant.price_range),
        distance,
        latitude: restaurant.latitude,
        longitude: restaurant.longitude,
        isOpen: isOpen || false,
        openUntil: todaySchedule?.closing_time || '23:00',
        opensAt: todaySchedule?.opening_time || '12:00',
        tags: restaurant.custom_tags || [],
        address: restaurant.address,
        phone: restaurant.phone || '',
        description: restaurant.description || undefined,
        services: restaurant.restaurant_services?.map((rs: any) => rs.services?.name).filter(Boolean) || [],
        hasActivePromotions: false, // TODO: Check promotions table
        currentPromotions: [],
        promoTypes: [],
        views: Math.floor(Math.random() * 3000) + 500, // Mock for now
        savedCount: restaurant.favorites_count || 0
      };
    });

    // Filter by distance if specified
    if (maxDistance && userLat && userLng) {
      return restaurants.filter(restaurant => restaurant.distance <= maxDistance);
    }

    // Sort by distance if user location is available
    if (userLat && userLng) {
      restaurants.sort((a, b) => a.distance - b.distance);
    }

    return restaurants;

  } catch (error) {
    console.error('Error in getRestaurants:', error);
    return [];
  }
}

// Helper function to get establishment type IDs
async function getEstablishmentTypeIds(names: string[]): Promise<number[]> {
  const { data } = await supabase
    .from('establishment_types')
    .select('id')
    .in('name', names);
  
  return data?.map(item => item.id) || [];
}

// Get filter options from database
export async function getFilterOptions() {
  try {
    const [
      { data: establishmentTypes },
      { data: cuisineTypes },
      { data: services },
      { data: dishCategories }
    ] = await Promise.all([
      supabase.from('establishment_types').select('*').order('name'),
      supabase.from('cuisine_types').select('*').order('name'),
      supabase.from('services').select('*').order('name'),
      supabase.from('dish_categories').select('*').order('display_order')
    ]);

    return {
      establishmentTypes: establishmentTypes || [],
      cuisineTypes: cuisineTypes || [],
      services: services || [],
      dishCategories: dishCategories || []
    };
  } catch (error) {
    console.error('Error fetching filter options:', error);
    return {
      establishmentTypes: [],
      cuisineTypes: [],
      services: [],
      dishCategories: []
    };
  }
}