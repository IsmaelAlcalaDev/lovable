import { supabase } from '../lib/supabase';

export interface LocationOption {
  id: number;
  name: string;
  type: 'city' | 'district' | 'municipality';
  latitude: number;
  longitude: number;
  population?: number;
  parent?: string;
  restaurantCount?: number;
}

// Get cities for location search
export async function getCities(searchQuery?: string): Promise<LocationOption[]> {
  try {
    let query = supabase
      .from('cities')
      .select(`
        *,
        provinces(name),
        districts(id, name, latitude, longitude)
      `)
      .order('population', { ascending: false });

    if (searchQuery && searchQuery.length >= 2) {
      query = query.ilike('name', `%${searchQuery}%`);
    }

    const { data, error } = await query.limit(20);

    if (error) {
      console.error('Error fetching cities:', error);
      return [];
    }

    const locations: LocationOption[] = [];

    // Add cities
    (data || []).forEach((city: any) => {
      locations.push({
        id: city.id,
        name: city.name,
        type: 'city',
        latitude: city.latitude,
        longitude: city.longitude,
        population: city.population,
        parent: city.provinces?.name
      });

      // Add districts for each city
      (city.districts || []).forEach((district: any) => {
        locations.push({
          id: district.id + 10000, // Offset to avoid ID conflicts
          name: district.name,
          type: 'district',
          latitude: district.latitude,
          longitude: district.longitude,
          parent: city.name
        });
      });
    });

    return locations;

  } catch (error) {
    console.error('Error in getCities:', error);
    return [];
  }
}

// Get municipalities
export async function getMunicipalities(searchQuery?: string): Promise<LocationOption[]> {
  try {
    let query = supabase
      .from('municipalities')
      .select(`
        *,
        provinces(name)
      `)
      .order('population', { ascending: false });

    if (searchQuery && searchQuery.length >= 2) {
      query = query.ilike('name', `%${searchQuery}%`);
    }

    const { data, error } = await query.limit(10);

    if (error) {
      console.error('Error fetching municipalities:', error);
      return [];
    }

    return (data || []).map((municipality: any) => ({
      id: municipality.id + 20000, // Offset to avoid ID conflicts
      name: municipality.name,
      type: 'municipality' as const,
      latitude: municipality.latitude,
      longitude: municipality.longitude,
      population: municipality.population,
      parent: municipality.provinces?.name
    }));

  } catch (error) {
    console.error('Error in getMunicipalities:', error);
    return [];
  }
}

// Combined location search
export async function searchLocations(searchQuery: string): Promise<LocationOption[]> {
  if (!searchQuery || searchQuery.length < 2) return [];

  try {
    const [cities, municipalities] = await Promise.all([
      getCities(searchQuery),
      getMunicipalities(searchQuery)
    ]);

    // Combine and sort by relevance
    const allLocations = [...cities, ...municipalities];
    
    // Sort by name match relevance
    return allLocations.sort((a, b) => {
      const aStartsWith = a.name.toLowerCase().startsWith(searchQuery.toLowerCase());
      const bStartsWith = b.name.toLowerCase().startsWith(searchQuery.toLowerCase());
      
      if (aStartsWith && !bStartsWith) return -1;
      if (!aStartsWith && bStartsWith) return 1;
      
      // Then by population (if available)
      const aPopulation = a.population || 0;
      const bPopulation = b.population || 0;
      return bPopulation - aPopulation;
    });

  } catch (error) {
    console.error('Error in searchLocations:', error);
    return [];
  }
}

// Get restaurant count for a location
export async function getRestaurantCountForLocation(
  latitude: number, 
  longitude: number, 
  radiusKm: number = 5
): Promise<number> {
  try {
    // This is a simplified version - in production you'd use PostGIS for proper distance calculation
    const { count, error } = await supabase
      .from('restaurants')
      .select('*', { count: 'exact', head: true })
      .eq('is_active', true)
      .eq('is_published', true)
      .gte('latitude', latitude - (radiusKm / 111)) // Rough approximation
      .lte('latitude', latitude + (radiusKm / 111))
      .gte('longitude', longitude - (radiusKm / (111 * Math.cos(latitude * Math.PI / 180))))
      .lte('longitude', longitude + (radiusKm / (111 * Math.cos(latitude * Math.PI / 180))));

    if (error) {
      console.error('Error counting restaurants:', error);
      return 0;
    }

    return count || 0;

  } catch (error) {
    console.error('Error in getRestaurantCountForLocation:', error);
    return 0;
  }
}