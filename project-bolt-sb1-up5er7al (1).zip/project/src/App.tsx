import React, { useState, useEffect } from 'react';
import { Filter } from 'lucide-react';
import Header from './components/Header';
import Hero from './components/Hero';
import RestaurantCard from './components/cards/RestaurantCard';
import DishCard from './components/cards/DishCard';
import EventCard from './components/cards/EventCard';
import FiltersModal from './components/modals/FiltersModal';
import EventModal from './components/modals/EventModal';
import SaveEventModal from './components/modals/SaveEventModal';
import DishModal from './components/modals/DishModal'; // Keep this import
import RestaurantProfileModal from './components/modals/RestaurantProfileModal';
import RestaurantRegistrationModal from './components/modals/RestaurantRegistrationModal';
import Footer from './components/Footer';
import { useGeolocation } from './hooks/useGeolocation';
import { useSearch } from './hooks/useSearch';
import { useAuth } from './hooks/useAuth';
import { useSupabaseData } from './hooks/useSupabaseData';
import { SearchTab, Filters } from './types';

function App() {
  const { location, updateLocation } = useGeolocation();
  const { activeTab, setActiveTab, query, setQuery, placeholder, suggestions } = useSearch();
  const { 
    user, 
    saveEvent, 
    unsaveEvent, 
    isEventSaved,
    saveRestaurant,
    unsaveRestaurant,
    isRestaurantSaved,
    saveDish,
    unsaveDish,
    isDishSaved
  } = useAuth();
  
  const { data, isLoading, error, filterOptions } = useSupabaseData(activeTab, query, filters, location);
  const [showFilters, setShowFilters] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [showEventModal, setShowEventModal] = useState(false);
  const [showSaveEventModal, setShowSaveEventModal] = useState(false);
  const [eventToSave, setEventToSave] = useState(null);
  const [selectedDish, setSelectedDish] = useState(null);
  const [showDishModal, setShowDishModal] = useState(false);
  const [selectedRestaurant, setSelectedRestaurant] = useState(null);
  const [showRestaurantModal, setShowRestaurantModal] = useState(false);
  const [showClaimModal, setShowClaimModal] = useState(false);
  const [restaurantToClaim, setRestaurantToClaim] = useState(null);
  const [quickFilters, setQuickFilters] = useState({
    nearMe: false,
    openNow: false,
    economic: false,
    topRated: false
  });
  
  const [filters, setFilters] = useState<Filters>({
    location: { radius: 2000 },
    price: [],
    schedule: [],
    rating: 0,
    establishmentType: [],
    cuisineType: [],
    services: [],
    categories: [],
    diets: [],
    allergens: [],
    spiceLevel: [],
    occasion: [],
    scheduleHours: [],
    hasPromotions: false,
    promoType: [],
    eventType: [],
    requiresReservation: null,
    isFree: null,
    dateRange: [],
    timeSlots: []
  });

  const handleQuickFilterChange = (filter: keyof typeof quickFilters) => {
    setQuickFilters(prev => ({
      ...prev,
      [filter]: !prev[filter]
    }));
  };

  // Convert quick filters to proper filters format and merge with existing filters
  const getAppliedFilters = () => {
    return {
      ...filters,
      location: { 
        ...filters.location,
        radius: quickFilters.nearMe ? 1000 : filters.location.radius
      },
      price: quickFilters.economic ? [1, 2] : [], // Only € and €€ if "Económico" is active
      schedule: quickFilters.openNow ? ['Abierto ahora'] : [],
      rating: quickFilters.topRated ? 4 : 0, // 4+ stars if "Mejor valorados" is active
      isFree: quickFilters.openNow && activeTab === 'events' ? true : null, // For events, "openNow" means free events
    };
  };

  // Update filters when quick filters change
  useEffect(() => {
    const appliedFilters = getAppliedFilters();
    setFilters(appliedFilters);
  }, [quickFilters]);

  const renderCard = (item: any, index: number) => {
    switch (activeTab) {
      case 'restaurants':
        return (
          <RestaurantCard
            key={item.id}
            restaurant={item}
            onClick={() => {
              setSelectedRestaurant(item);
              setShowRestaurantModal(true);
            }}
            isSaved={user ? isRestaurantSaved(item.id) : false}
            onSave={user ? (restaurant) => saveRestaurant(restaurant.id) : undefined}
            onUnsave={user ? unsaveRestaurant : undefined}
          />
        );
      case 'dishes':
        return (
          <DishCard
            key={item.id}
            dish={item}
            onClick={() => {
              setSelectedDish(item);
              setShowDishModal(true);
            }}
            isSaved={user ? isDishSaved(item.id) : false}
            onSave={user ? (dish) => saveDish(dish.id) : undefined}
            onUnsave={user ? unsaveDish : undefined}
          />
        );
      case 'events':
        return (
          <EventCard
            key={item.id}
            event={item}
            onClick={() => {
              setSelectedEvent(item);
              setShowEventModal(true);
            }}
          />
        );
      default:
        return null;
    }
  };

  const getEmptyStateMessage = () => {
    if (query.length >= 2) {
      return `No encontramos '${query}' en ${location?.address || 'tu zona'}. Prueba con otros términos o amplía el área de búsqueda.`;
    }
    return `No hay ${
      activeTab === 'restaurants' ? 'restaurantes' : 
      activeTab === 'dishes' ? 'platos' : 'eventos'
    } disponibles en tu zona.`;
  };

  const handleSaveEvent = (event: any) => {
    if (user) {
      setEventToSave(event);
      setShowSaveEventModal(true);
    } else {
      // Could show auth modal here
      alert('Inicia sesión para guardar eventos');
    }
  };

  const handleSaveEventWithReminder = (eventId: string, reminderType: 'notification' | 'calendar' | 'both', reminderTime: string) => {
    saveEvent(eventId, reminderType);
    setShowSaveEventModal(false);
    setEventToSave(null);
  };

  const handleClaimRestaurant = (restaurant: any) => {
    setRestaurantToClaim(restaurant);
    setShowClaimModal(true);
    setShowRestaurantModal(false);
  };
  return (
    <>
      <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header 
        location={location} 
        onLocationChange={updateLocation}
        onViewEvent={(event) => {
          setSelectedEvent(event);
          setShowEventModal(true);
        }}
      />
      
      <Hero
        activeTab={activeTab}
        onTabChange={setActiveTab}
        query={query}
        onQueryChange={setQuery}
        placeholder={placeholder}
        suggestions={suggestions}
        quickFilters={quickFilters}
        onQuickFilterChange={handleQuickFilterChange}
        onOpenFilters={() => setShowFilters(true)}
      />

      <main className="flex-1">
        <div className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-6 py-3 sm:py-4">
          {/* Results Header */}
          <div className="flex items-center justify-between mb-2 sm:mb-3">
            <div className="flex-1">
              {isLoading && (
                <div className="flex items-center gap-2 text-orange-600 text-sm font-medium mb-2">
                  <div className="w-4 h-4 border-2 border-orange-600 border-t-transparent rounded-full animate-spin"></div>
                  <span>Cargando...</span>
                </div>
              )}
              
              <h2 className="text-base sm:text-lg md:text-xl font-semibold text-gray-900">
                {activeTab === 'restaurants' && '🏪 Restaurantes'}
                {activeTab === 'dishes' && '🍽️ Platos'}
                {activeTab === 'events' && '🎪 Eventos'}
              </h2>
            </div>
          </div>

          {/* Results Grid */}
          {error && (
            <div className="text-center py-8">
              <div className="text-red-600 text-sm bg-red-50 px-4 py-2 rounded-lg border border-red-200 inline-block">
                {error}
              </div>
            </div>
          )}
          
          {!isLoading && !error && (
          {data.length > 0 ? (
            <div className="space-y-2 sm:space-y-3">
              {data.map((item, index) => renderCard(item, index))}
            </div>
          ) : (
            <div className="text-center py-12 sm:py-16">
              <div className="text-6xl mb-4">
                {activeTab === 'restaurants' && '🏪'}
                {activeTab === 'dishes' && '🍽️'}
                {activeTab === 'events' && '🎪'}
              </div>
              <h3 className="text-xl font-medium text-gray-900 mb-2">
                Sin resultados
              </h3>
              <p className="text-gray-600 max-w-md mx-auto">
                {getEmptyStateMessage()}
              </p>
              <button
                onClick={() => setQuery('')}
                className="mt-4 px-4 sm:px-6 py-2 sm:py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors text-sm sm:text-base"
              >
                Limpiar búsqueda
              </button>
            </div>
          )}
          )}

          {/* Load More Button */}
          {data.length > 0 && data.length >= 9 && (
            <div className="text-center mt-6 sm:mt-8">
              <button className="px-6 sm:px-8 py-2.5 sm:py-3 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium text-sm sm:text-base">
                Cargar más resultados
              </button>
            </div>
          )}
        </div>
      </main>

      <Footer />

      <FiltersModal
        isOpen={showFilters}
        onClose={() => setShowFilters(false)}
        activeTab={activeTab}
        filters={filters}
        onFiltersChange={setFilters}
        filterOptions={filterOptions}
      />
      </div>

      <EventModal
        isOpen={showEventModal}
        onClose={() => setShowEventModal(false)}
        event={selectedEvent}
        isEventSaved={selectedEvent ? isEventSaved(selectedEvent.id) : false}
        onSaveEvent={handleSaveEvent}
        onUnsaveEvent={unsaveEvent}
        onShare={(event) => {
          // Handle sharing functionality
          console.log('Share event:', event);
        }}
        onViewRestaurant={(restaurantId) => {
          console.log('View restaurant:', restaurantId);
          setShowEventModal(false);
        }}
      />

      <SaveEventModal
        isOpen={showSaveEventModal}
        onClose={() => {
          setShowSaveEventModal(false);
          setEventToSave(null);
        }}
        event={eventToSave}
        onSave={handleSaveEventWithReminder}
      />

      <DishModal
        isOpen={showDishModal}
        onClose={() => setShowDishModal(false)}
        dish={selectedDish}
        isDishSaved={selectedDish ? isDishSaved(selectedDish.id) : false}
        onSaveDish={user ? (dish) => saveDish(dish.id) : undefined}
        onUnsaveDish={user ? unsaveDish : undefined}
        onShare={(dish) => {
          console.log('Share dish:', dish);
        }}
        onViewRestaurant={(restaurantId) => {
          console.log('View restaurant:', restaurantId);
          setShowDishModal(false);
        }}
      />

      <RestaurantProfileModal
        isOpen={showRestaurantModal}
        onClose={() => setShowRestaurantModal(false)}
        restaurant={selectedRestaurant}
        onClaimRestaurant={handleClaimRestaurant}
      />

      <RestaurantRegistrationModal
        isOpen={showClaimModal}
        onClose={() => {
          setShowClaimModal(false);
          setRestaurantToClaim(null);
        }}
        mode="claim"
        restaurantData={restaurantToClaim}
      />
    </>
  );
}

export default App;