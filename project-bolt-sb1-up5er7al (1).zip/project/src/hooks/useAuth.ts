import { useState, useEffect } from 'react';
import { User } from '../types';

export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for saved user session
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      // Mock login - in real app this would call an API
      const mockUser: User = {
        id: '1',
        email,
        name: email.split('@')[0],
        preferences: {
          dietaryRestrictions: [],
          allergens: [],
          priceRange: []
        },
        savedEvents: [],
        savedRestaurants: [],
        savedDishes: [],
        reservations: ['res-1', 'res-2', 'res-3', 'res-4', 'res-5', 'res-6', 'res-7', 'res-8', 'res-9', 'res-10', 'res-11', 'res-12', 'res-13', 'event-res-1', 'event-res-2', 'event-res-3', 'event-res-4', 'event-res-5'],
        notifications: {
          email: true,
          push: true,
          calendar: false
        }
      };
      
      setUser(mockUser);
      localStorage.setItem('user', JSON.stringify(mockUser));
      return true;
    } catch (error) {
      return false;
    }
  };

  const register = async (email: string, password: string, name: string): Promise<boolean> => {
    try {
      // Mock registration - in real app this would call an API
      const newUser: User = {
        id: Date.now().toString(),
        email,
        name,
        preferences: {
          dietaryRestrictions: [],
          allergens: [],
          priceRange: []
        },
        savedEvents: [],
        savedRestaurants: [],
        savedDishes: [],
        reservations: ['res-1', 'res-2', 'res-3', 'res-4', 'res-5', 'res-6', 'res-7', 'res-8', 'res-9', 'res-10', 'res-11', 'res-12', 'res-13', 'event-res-1', 'event-res-2', 'event-res-3', 'event-res-4', 'event-res-5'],
        notifications: {
          email: true,
          push: true,
          calendar: false
        }
      };
      
      setUser(newUser);
      localStorage.setItem('user', JSON.stringify(newUser));
      return true;
    } catch (error) {
      return false;
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  const updateUser = (updates: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...updates };
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
    }
  };

  const saveEvent = (eventId: string, reminderType: 'notification' | 'calendar' | 'both' = 'notification') => {
    if (user && !user.savedEvents.includes(eventId)) {
      const updatedUser = {
        ...user,
        savedEvents: [...user.savedEvents, eventId]
      };
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
      
      // Here you would also save the reminder preferences
      const savedEvent = {
        eventId,
        savedAt: new Date().toISOString(),
        reminderType,
        reminderTime: '1 hour before'
      };
      
      const savedEvents = JSON.parse(localStorage.getItem('savedEventDetails') || '[]');
      savedEvents.push(savedEvent);
      localStorage.setItem('savedEventDetails', JSON.stringify(savedEvents));
    }
  };

  const unsaveEvent = (eventId: string) => {
    if (user) {
      const updatedUser = {
        ...user,
        savedEvents: user.savedEvents.filter(id => id !== eventId)
      };
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
      
      // Remove from saved event details
      const savedEvents = JSON.parse(localStorage.getItem('savedEventDetails') || '[]');
      const filteredEvents = savedEvents.filter((event: any) => event.eventId !== eventId);
      localStorage.setItem('savedEventDetails', JSON.stringify(filteredEvents));
    }
  };

  const isEventSaved = (eventId: string): boolean => {
    return user?.savedEvents.includes(eventId) || false;
  };

  const saveRestaurant = (restaurantId: string) => {
    if (user && !user.savedRestaurants.includes(restaurantId)) {
      const updatedUser = {
        ...user,
        savedRestaurants: [...user.savedRestaurants, restaurantId]
      };
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
    }
  };

  const unsaveRestaurant = (restaurantId: string) => {
    if (user) {
      const updatedUser = {
        ...user,
        savedRestaurants: user.savedRestaurants.filter(id => id !== restaurantId)
      };
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
    }
  };

  const isRestaurantSaved = (restaurantId: string): boolean => {
    return user?.savedRestaurants.includes(restaurantId) || false;
  };

  const saveDish = (dishId: string) => {
    if (user && !user.savedDishes.includes(dishId)) {
      const updatedUser = {
        ...user,
        savedDishes: [...user.savedDishes, dishId]
      };
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
    }
  };

  const unsaveDish = (dishId: string) => {
    if (user) {
      const updatedUser = {
        ...user,
        savedDishes: user.savedDishes.filter(id => id !== dishId)
      };
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
    }
  };

  const isDishSaved = (dishId: string): boolean => {
    return user?.savedDishes.includes(dishId) || false;
  };

  const makeReservation = (reservationId: string) => {
    if (user && !user.reservations.includes(reservationId)) {
      const updatedUser = {
        ...user,
        reservations: [...user.reservations, reservationId]
      };
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
    }
  };

  const cancelReservation = (reservationId: string) => {
    if (user) {
      const updatedUser = {
        ...user,
        reservations: user.reservations.filter(id => id !== reservationId)
      };
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
    }
  };

  return {
    user,
    isLoading,
    login,
    register,
    logout,
    updateUser,
    saveEvent,
    unsaveEvent,
    isEventSaved,
    saveRestaurant,
    unsaveRestaurant,
    isRestaurantSaved,
    saveDish,
    unsaveDish,
    isDishSaved,
    makeReservation,
    cancelReservation
  };
};