import { useState, useEffect, useMemo } from 'react';
import { SearchTab } from '../types';

export const useSearch = () => {
  const [query, setQuery] = useState('');
  const [activeTab, setActiveTab] = useState<SearchTab>('restaurants');
  const [debouncedQuery, setDebouncedQuery] = useState('');

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(query);
    }, 300);

    return () => clearTimeout(timer);
  }, [query]);

  const placeholders = {
    restaurants: "¿Dónde quieres comer hoy?",
    dishes: "¿Qué plato buscas?",
    events: "¿Qué evento te interesa?"
  };

  const suggestions = useMemo(() => {
    if (debouncedQuery.length < 2) return [];
    
    // Mock suggestions based on active tab
    const mockSuggestions = {
      restaurants: [
        { type: 'restaurant', name: 'La Parrilla de Juan', subtitle: 'Asador', distance: '350m' },
        { type: 'restaurant', name: 'Casa Pepe', subtitle: 'Tapas', distance: '500m' },
        { type: 'restaurant', name: 'Pizzería Napoli', subtitle: 'Italiana', distance: '800m' }
      ],
      dishes: [
        { type: 'dish', name: 'Paella Valenciana', subtitle: 'Casa Pepe', distance: '500m' },
        { type: 'dish', name: 'Pizza Margherita', subtitle: 'Pizzería Napoli', distance: '800m' },
        { type: 'dish', name: 'Hamburguesa BBQ', subtitle: 'Burger King', distance: '1.2km' }
      ],
      events: [
        { type: 'event', name: 'Noche de Flamenco', subtitle: 'El Rincón Flamenco', distance: '600m', date: 'Hoy' },
        { type: 'event', name: 'Cata de Vinos', subtitle: 'Casa Pepe', distance: '500m', date: 'Mañana' },
        { type: 'event', name: 'Sunset Cocktails', subtitle: 'Azotea Skybar', distance: '1.2km', date: 'Sábado' }
      ]
    };

    return mockSuggestions[activeTab].filter(item => 
      item.name.toLowerCase().includes(debouncedQuery.toLowerCase())
    );
  }, [debouncedQuery, activeTab]);

  return {
    query,
    setQuery,
    activeTab,
    setActiveTab,
    debouncedQuery,
    suggestions,
    placeholder: placeholders[activeTab]
  };
};