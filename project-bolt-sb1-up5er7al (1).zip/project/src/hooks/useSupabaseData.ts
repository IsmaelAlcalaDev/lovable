import { useState, useEffect } from 'react';
import { getRestaurants, getFilterOptions } from '../services/restaurantService';
import { getDishes } from '../services/dishService';
import { getEvents } from '../services/eventService';
import { searchLocations } from '../services/locationService';
import { Restaurant, Dish, Event, SearchTab, Filters, Location } from '../types';

export const useSupabaseData = (
  activeTab: SearchTab,
  query: string,
  filters: Filters,
  location: Location | null
) => {
  const [data, setData] = useState<(Restaurant | Dish | Event)[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [filterOptions, setFilterOptions] = useState({
    establishmentTypes: [],
    cuisineTypes: [],
    services: [],
    dishCategories: []
  });

  // Load filter options on mount
  useEffect(() => {
    const loadFilterOptions = async () => {
      try {
        const options = await getFilterOptions();
        setFilterOptions(options);
      } catch (err) {
        console.error('Error loading filter options:', err);
      }
    };

    loadFilterOptions();
  }, []);

  // Load data when dependencies change
  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      setError(null);

      try {
        const userLat = location?.latitude;
        const userLng = location?.longitude;
        const maxDistance = filters.location.radius < 999999 ? filters.location.radius : undefined;

        let result: (Restaurant | Dish | Event)[] = [];

        switch (activeTab) {
          case 'restaurants':
            result = await getRestaurants(userLat, userLng, maxDistance, query, filters);
            break;
          case 'dishes':
            result = await getDishes(userLat, userLng, maxDistance, query, filters);
            break;
          case 'events':
            result = await getEvents(userLat, userLng, maxDistance, query, filters);
            break;
        }

        setData(result);
      } catch (err) {
        console.error('Error loading data:', err);
        setError('Error al cargar los datos. Inténtalo de nuevo.');
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, [activeTab, query, filters, location]);

  return {
    data,
    isLoading,
    error,
    filterOptions
  };
};

// Hook for location search
export const useLocationSearch = () => {
  const [locations, setLocations] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const searchLocationOptions = async (query: string) => {
    if (!query || query.length < 2) {
      setLocations([]);
      return;
    }

    setIsSearching(true);
    try {
      const results = await searchLocations(query);
      setLocations(results);
    } catch (error) {
      console.error('Error searching locations:', error);
      setLocations([]);
    } finally {
      setIsSearching(false);
    }
  };

  return {
    locations,
    isSearching,
    searchLocationOptions
  };
};