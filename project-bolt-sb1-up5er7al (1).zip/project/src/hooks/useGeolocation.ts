import { useState, useEffect } from 'react';
import { Location } from '../types';
import { getCurrentLocationWithAddress, RadarLocation } from '../services/radarService';

export const useGeolocation = () => {
  const [location, setLocation] = useState<Location | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const defaultLocation: Location = {
    latitude: 37.3431,
    longitude: -6.0679,
    address: "Mairena del Aljarafe, Sevilla",
    name: "Ubicación por defecto"
  };

  const getCurrentLocation = async () => {
    setIsLoading(true);
    setError(null);

    try {
      console.log('🔍 Iniciando detección automática de ubicación...');
      const radarLocation: RadarLocation = await getCurrentLocationWithAddress();
      
      const newLocation: Location = {
        latitude: radarLocation.latitude,
        longitude: radarLocation.longitude,
        address: radarLocation.formattedAddress,
        name: "Mi ubicación actual"
      };

      setLocation(newLocation);
      localStorage.setItem('userLocation', JSON.stringify(newLocation));
      
      console.log('✅ Ubicación detectada automáticamente:', {
        address: newLocation.address,
        coordinates: `${newLocation.latitude}, ${newLocation.longitude}`
      });

    } catch (err: any) {
      console.error('❌ Error en detección automática:', err);
      setError(err.message || 'No se pudo obtener la ubicación');
      
      // Fallback a ubicación por defecto
      setLocation(defaultLocation);
      localStorage.setItem('userLocation', JSON.stringify(defaultLocation));
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const savedLocation = localStorage.getItem('userLocation');
    if (savedLocation) {
      try {
        const parsedLocation = JSON.parse(savedLocation);
        setLocation(parsedLocation);
        console.log('📦 Ubicación previa cargada:', parsedLocation.address);
      } catch (err) {
        console.error('Error al cargar ubicación previa:', err);
        getCurrentLocation();
      }
    } else {
      console.log('🚀 Primera vez - iniciando detección automática...');
      getCurrentLocation();
    }
  }, []);

  const updateLocation = (newLocation: Location) => {
    setLocation(newLocation);
    localStorage.setItem('userLocation', JSON.stringify(newLocation));
    console.log('📍 Ubicación actualizada:', {
      address: newLocation.address,
      coordinates: `${newLocation.latitude}, ${newLocation.longitude}`
    });
  };

  return {
    location,
    error,
    isLoading,
    getCurrentLocation,
    updateLocation
  };
};