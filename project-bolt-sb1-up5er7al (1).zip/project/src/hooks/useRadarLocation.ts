/**
 * Hook personalizado para geolocalización con Radar API
 * Proporciona una interfaz React optimizada para obtener ubicación
 */

import { useState, useCallback, useRef } from 'react';
import { 
  getCurrentLocationWithAddress, 
  searchAddresses, 
  RadarLocation, 
  RadarError,
  formatAddress 
} from '../services/radarService';

interface UseRadarLocationReturn {
  // Estado
  location: RadarLocation | null;
  isLoading: boolean;
  error: RadarError | null;
  
  // Funciones
  getCurrentLocation: () => Promise<void>;
  searchLocation: (query: string) => Promise<RadarLocation[]>;
  clearError: () => void;
  
  // Utilidades
  formatLocationAddress: (style?: 'short' | 'full') => string;
}

export const useRadarLocation = (): UseRadarLocationReturn => {
  const [location, setLocation] = useState<RadarLocation | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<RadarError | null>(null);
  
  // Ref para cancelar búsquedas en progreso
  const searchTimeoutRef = useRef<NodeJS.Timeout>();

  /**
   * Obtiene la ubicación actual del usuario
   */
  const getCurrentLocation = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const currentLocation = await getCurrentLocationWithAddress();
      setLocation(currentLocation);
      
      console.log('✅ Ubicación obtenida exitosamente:', {
        address: currentLocation.formattedAddress,
        coordinates: `${currentLocation.latitude}, ${currentLocation.longitude}`,
        accuracy: `${currentLocation.accuracy}m`,
        source: currentLocation.source
      });
      
    } catch (err) {
      const radarError = err as RadarError;
      setError(radarError);
      console.error('❌ Error al obtener ubicación:', radarError);
    } finally {
      setIsLoading(false);
    }
  }, []);

  /**
   * Busca direcciones con debounce para optimizar peticiones
   */
  const searchLocation = useCallback(async (query: string): Promise<RadarLocation[]> => {
    // Cancelar búsqueda anterior si existe
    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current);
    }
    
    // Si la query es muy corta, no buscar
    if (!query || query.length < 3) {
      return [];
    }
    
    return new Promise((resolve) => {
      searchTimeoutRef.current = setTimeout(async () => {
        try {
          const results = await searchAddresses(query, 5);
          resolve(results);
        } catch (error) {
          console.error('Error en búsqueda:', error);
          resolve([]);
        }
      }, 300); // Debounce de 300ms
    });
  }, []);

  /**
   * Limpia el error actual
   */
  const clearError = useCallback(() => {
    setError(null);
  }, []);

  /**
   * Formatea la dirección actual
   */
  const formatLocationAddress = useCallback((style: 'short' | 'full' = 'full') => {
    if (!location) return '';
    return formatAddress(location, style);
  }, [location]);

  return {
    // Estado
    location,
    isLoading,
    error,
    
    // Funciones
    getCurrentLocation,
    searchLocation,
    clearError,
    
    // Utilidades
    formatLocationAddress
  };
};