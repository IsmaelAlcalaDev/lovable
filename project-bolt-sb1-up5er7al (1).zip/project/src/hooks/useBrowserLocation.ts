/**
 * Hook para geolocalización usando solo el navegador
 * Alternativa más rápida al sistema Radar
 */

import { useState, useCallback } from 'react';
import { 
  getBrowserLocation, 
  BrowserLocation, 
  BrowserLocationError,
  formatBrowserLocation,
  isBrowserGeolocationSupported
} from '../services/browserLocationService';

interface UseBrowserLocationReturn {
  // Estado
  location: BrowserLocation | null;
  isLoading: boolean;
  error: BrowserLocationError | null;
  
  // Funciones
  getCurrentLocation: () => Promise<void>;
  clearError: () => void;
  
  // Utilidades
  formatLocationAddress: () => string;
  isSupported: boolean;
}

export const useBrowserLocation = (): UseBrowserLocationReturn => {
  const [location, setLocation] = useState<BrowserLocation | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<BrowserLocationError | null>(null);

  /**
   * Obtiene la ubicación actual usando solo el navegador
   */
  const getCurrentLocation = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const currentLocation = await getBrowserLocation();
      setLocation(currentLocation);
      
      console.log('✅ Ubicación obtenida con navegador:', {
        coordinates: `${currentLocation.latitude}, ${currentLocation.longitude}`,
        accuracy: `${currentLocation.accuracy}m`,
        source: currentLocation.source
      });
      
    } catch (err) {
      const browserError = err as BrowserLocationError;
      setError(browserError);
      console.error('❌ Error al obtener ubicación con navegador:', browserError);
    } finally {
      setIsLoading(false);
    }
  }, []);

  /**
   * Limpia el error actual
   */
  const clearError = useCallback(() => {
    setError(null);
  }, []);

  /**
   * Formatea la dirección de la ubicación actual
   */
  const formatLocationAddress = useCallback(() => {
    if (!location) return '';
    return location.address; // Usar directamente la dirección geocodificada
  }, [location]);

  return {
    // Estado
    location,
    isLoading,
    error,
    
    // Funciones
    getCurrentLocation,
    clearError,
    
    // Utilidades
    formatLocationAddress,
    isSupported: isBrowserGeolocationSupported()
  };
};