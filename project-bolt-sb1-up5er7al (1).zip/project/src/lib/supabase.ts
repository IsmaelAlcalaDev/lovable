import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database types
export interface Database {
  public: {
    Tables: {
      restaurants: {
        Row: {
          id: number;
          name: string;
          slug: string;
          description: string | null;
          establishment_type_id: number;
          price_range: 'EUR' | 'EUR_EUR' | 'EUR_EUR_EUR' | 'EUR_EUR_EUR_EUR';
          email: string | null;
          phone: string | null;
          website: string | null;
          address: string;
          city_id: number;
          district_id: number | null;
          latitude: number;
          longitude: number;
          google_rating: number | null;
          google_rating_count: number;
          is_verified: boolean;
          is_claimed: boolean;
          logo_url: string | null;
          cover_image_url: string | null;
          gallery_urls: any;
          is_active: boolean;
          is_published: boolean;
          created_at: string;
          updated_at: string;
          favorites_count: number;
          favorites_count_week: number;
          favorites_count_month: number;
        };
      };
      dishes: {
        Row: {
          id: number;
          restaurant_id: number;
          section_id: number;
          category_id: number;
          name: string;
          description: string | null;
          base_price: number;
          spice_level: number;
          preparation_time_minutes: number | null;
          image_url: string | null;
          custom_tags: any;
          allergens: any;
          diet_types: any;
          is_active: boolean;
          is_featured: boolean;
          is_vegetarian: boolean;
          is_vegan: boolean;
          is_gluten_free: boolean;
          is_lactose_free: boolean;
          is_healthy: boolean;
          favorites_count: number;
          favorites_count_week: number;
          created_at: string;
          updated_at: string;
        };
      };
      events: {
        Row: {
          id: number;
          restaurant_id: number;
          name: string;
          description: string;
          category: string;
          event_date: string;
          start_time: string;
          end_time: string | null;
          venue: string | null;
          image_url: string | null;
          tags: any;
          is_free: boolean;
          entry_price: number | null;
          requires_reservation: boolean;
          available_seats: number | null;
          age_restriction: string;
          dress_code: string;
          is_active: boolean;
          favorites_count: number;
          favorites_count_week: number;
          created_at: string;
          updated_at: string;
        };
      };
      cities: {
        Row: {
          id: number;
          province_id: number;
          name: string;
          latitude: number;
          longitude: number;
          population: number | null;
          created_at: string;
        };
      };
      districts: {
        Row: {
          id: number;
          city_id: number;
          name: string;
          latitude: number;
          longitude: number;
          created_at: string;
        };
      };
      establishment_types: {
        Row: {
          id: number;
          name: string;
          slug: string;
          icon: string | null;
          created_at: string;
        };
      };
      cuisine_types: {
        Row: {
          id: number;
          name: string;
          slug: string;
          icon: string | null;
          created_at: string;
        };
      };
      dish_categories: {
        Row: {
          id: number;
          name: string;
          slug: string;
          icon: string | null;
          display_order: number;
          created_at: string;
        };
      };
    };
  };
}