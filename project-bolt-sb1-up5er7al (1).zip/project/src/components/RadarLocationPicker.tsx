/**
 * Componente de selección de ubicación usando Radar API
 * Interfaz completa con botón de ubicación actual y autocompletado
 */

import React, { useState, useEffect, useRef } from 'react';
import { Navigation, MapPin, Search, X, AlertCircle, CheckCircle, Loader } from 'lucide-react';
import { useRadarLocation } from '../hooks/useRadarLocation';
import { RadarLocation } from '../services/radarService';

interface RadarLocationPickerProps {
  onLocationSelect: (location: RadarLocation) => void;
  placeholder?: string;
  showCurrentLocationButton?: boolean;
  className?: string;
}

const RadarLocationPicker: React.FC<RadarLocationPickerProps> = ({
  onLocationSelect,
  placeholder = "Buscar dirección...",
  showCurrentLocationButton = true,
  className = ""
}) => {
  const {
    location,
    isLoading,
    error,
    getCurrentLocation,
    searchLocation,
    clearError,
    formatLocationAddress
  } = useRadarLocation();

  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<RadarLocation[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  
  const searchInputRef = useRef<HTMLInputElement>(null);
  const resultsRef = useRef<HTMLDivElement>(null);

  // Manejar búsqueda con debounce
  useEffect(() => {
    const performSearch = async () => {
      if (searchQuery.length >= 3) {
        setIsSearching(true);
        try {
          const results = await searchLocation(searchQuery);
          setSearchResults(results);
          setShowResults(true);
        } catch (error) {
          console.error('Error en búsqueda:', error);
          setSearchResults([]);
        } finally {
          setIsSearching(false);
        }
      } else {
        setSearchResults([]);
        setShowResults(false);
      }
    };

    performSearch();
  }, [searchQuery, searchLocation]);

  // Cerrar resultados al hacer clic fuera
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        resultsRef.current && 
        !resultsRef.current.contains(event.target as Node) &&
        !searchInputRef.current?.contains(event.target as Node)
      ) {
        setShowResults(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Manejar selección de ubicación actual
  const handleCurrentLocation = async () => {
    clearError();
    await getCurrentLocation();
  };

  // Manejar selección de resultado de búsqueda
  const handleResultSelect = (selectedLocation: RadarLocation) => {
    setSearchQuery(selectedLocation.formattedAddress);
    setShowResults(false);
    onLocationSelect(selectedLocation);
  };

  // Limpiar búsqueda
  const clearSearch = () => {
    setSearchQuery('');
    setSearchResults([]);
    setShowResults(false);
    searchInputRef.current?.focus();
  };

  // Efecto para notificar cuando se obtiene ubicación actual
  useEffect(() => {
    if (location && !error) {
      onLocationSelect(location);
    }
  }, [location, error, onLocationSelect]);

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Botón de ubicación actual */}
      {showCurrentLocationButton && (
        <div>
          <button
            onClick={handleCurrentLocation}
            disabled={isLoading}
            className={`
              w-full flex items-center justify-center gap-3 p-4 rounded-xl border-2 transition-all duration-200
              ${isLoading 
                ? 'border-orange-300 bg-orange-50 cursor-not-allowed' 
                : 'border-orange-200 bg-orange-50 hover:bg-orange-100 hover:border-orange-300'
              }
            `}
          >
            <Navigation className={`w-5 h-5 text-orange-600 ${isLoading ? 'animate-spin' : ''}`} />
            <div className="text-left">
              <div className="font-semibold text-gray-900">
                {isLoading ? 'Obteniendo ubicación...' : '📍 Usar mi ubicación actual'}
              </div>
              <div className="text-sm text-gray-600">
                {isLoading ? 'Detectando con GPS y WiFi...' : 'Precisión hasta 10m • GPS + WiFi'}
              </div>
            </div>
          </button>
        </div>
      )}

      {/* Buscador de direcciones */}
      <div className="relative">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            ref={searchInputRef}
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onFocus={() => searchResults.length > 0 && setShowResults(true)}
            placeholder={placeholder}
            className="w-full pl-12 pr-12 py-4 border-2 border-gray-200 rounded-xl focus:border-orange-500 focus:ring-2 focus:ring-orange-200 transition-all duration-200"
          />
          {searchQuery && (
            <button
              onClick={clearSearch}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 p-1 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="w-4 h-4 text-gray-400" />
            </button>
          )}
          {isSearching && (
            <div className="absolute right-4 top-1/2 transform -translate-y-1/2">
              <Loader className="w-4 h-4 text-orange-500 animate-spin" />
            </div>
          )}
        </div>

        {/* Resultados de búsqueda */}
        {showResults && searchResults.length > 0 && (
          <div
            ref={resultsRef}
            className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-200 rounded-xl shadow-lg z-50 max-h-64 overflow-y-auto"
          >
            {searchResults.map((result, index) => (
              <button
                key={index}
                onClick={() => handleResultSelect(result)}
                className="w-full flex items-start gap-3 p-4 hover:bg-gray-50 transition-colors text-left border-b border-gray-100 last:border-b-0"
              >
                <MapPin className="w-4 h-4 text-orange-500 mt-1 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-gray-900 truncate">
                    {result.formattedAddress}
                  </div>
                  <div className="text-sm text-gray-500 flex items-center gap-2">
                    <span>Precisión: {result.accuracy}m</span>
                    <span>•</span>
                    <span className="capitalize">{result.confidence}</span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}

        {/* Sin resultados */}
        {showResults && searchQuery.length >= 3 && searchResults.length === 0 && !isSearching && (
          <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-200 rounded-xl shadow-lg z-50 p-4 text-center text-gray-500">
            No se encontraron direcciones para "{searchQuery}"
          </div>
        )}
      </div>

      {/* Mostrar ubicación actual obtenida */}
      {location && !error && (
        <div className="p-4 bg-green-50 border border-green-200 rounded-xl">
          <div className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
            <div className="flex-1">
              <div className="font-medium text-green-900 mb-1">
                Ubicación detectada
              </div>
              <div className="text-sm text-green-700 mb-2">
                {formatLocationAddress('full')}
              </div>
              <div className="text-xs text-green-600 space-y-1">
                <div>📍 Coordenadas: {location.latitude.toFixed(6)}, {location.longitude.toFixed(6)}</div>
                <div>🎯 Precisión: {location.accuracy}m</div>
                <div>📡 Fuente: {location.source === 'gps' ? 'GPS + WiFi' : location.source.toUpperCase()}</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Mostrar errores */}
      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-xl">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
            <div className="flex-1">
              <div className="font-medium text-red-900 mb-1">
                Error de ubicación
              </div>
              <div className="text-sm text-red-700 mb-3">
                {error.message}
              </div>
              <button
                onClick={clearError}
                className="text-xs text-red-600 hover:text-red-700 font-medium"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default RadarLocationPicker;