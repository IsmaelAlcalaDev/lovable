import React from 'react';
import { Eye, MapPin, Calendar, Clock, Heart, Users } from 'lucide-react';
import { Event } from '../../types';

interface EventCardProps {
  event: Event;
  onClick: () => void;
}

const EventCard: React.FC<EventCardProps> = ({ event, onClick }) => {
  // Format distance display
  const formatDistance = (distance: number) => {
    if (distance < 1000) {
      return `${distance}m`;
    } else {
      return `${(distance / 1000).toFixed(1)}km`;
    }
  };

  // Format date display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    if (date.toDateString() === today.toDateString()) {
      return 'Hoy';
    } else if (date.toDateString() === tomorrow.toDateString()) {
      return 'Mañana';
    } else {
      return date.toLocaleDateString('es-ES', { 
        weekday: 'short', 
        day: 'numeric', 
        month: 'short' 
      });
    }
  };

  // Get predefined image based on event type
  const getEventImage = (type: string) => {
    switch (type.toLowerCase()) {
      case 'deportivo':
        return 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg'; // Football stadium
      case 'música en vivo':
        return 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg'; // Live music
      case 'espectáculo':
        return 'https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg'; // Theater/show
      case 'cata':
        return 'https://images.pexels.com/photos/1267697/pexels-photo-1267697.jpeg'; // Wine tasting
      case 'taller':
        return 'https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg'; // Workshop/cooking
      case 'social':
        return 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg'; // Social event/party
      case 'gastronómico':
        return 'https://images.pexels.com/photos/260922/pexels-photo-260922.jpeg'; // Food event
      default:
        return 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg'; // Default music/entertainment
    }
  };

  // Get event type icon
  const getEventTypeIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'deportivo': return '⚽';
      case 'música en vivo': return '🎵';
      case 'espectáculo': return '🎭';
      case 'cata': return '🍷';
      case 'taller': return '👨‍🍳';
      case 'social': return '🎉';
      case 'gastronómico': return '🍽️';
      default: return '🎪';
    }
  };

  return (
    <div
      onClick={onClick}
      className="bg-white rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-all duration-200 cursor-pointer overflow-hidden group"
    >
      {/* Mobile Layout */}
      <div className="block sm:hidden">
        <div className="flex gap-3 p-3">
          {/* Image */}
          <div className="relative w-16 h-16 bg-gray-100 overflow-hidden rounded-lg flex-shrink-0">
            <img
              src={getEventImage(event.eventType)}
              alt={event.name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
            />
            
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            {/* Title and price */}
            <div className="flex items-start justify-between gap-2 mb-1">
              <h3 className="font-semibold text-gray-900 text-sm flex-1 min-w-0 leading-tight line-clamp-2">
                {event.name}
              </h3>
              <div className="flex-shrink-0">
                {event.isFree ? (
                  <span className="text-sm font-bold text-green-600">GRATIS</span>
                ) : (
                  <span className="text-sm font-bold text-gray-900">€{event.price.toFixed(2)}</span>
                )}
              </div>
            </div>

            {/* Event type and restaurant */}
            <div className="flex items-center gap-1 mb-1.5 text-xs">
              <span className="text-purple-600 font-medium">
                {getEventTypeIcon(event.eventType)} {event.eventType}
              </span>
            </div>

            {/* Date and time */}
            <div className="flex items-center justify-between text-xs text-gray-500">
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-0.5">
                  <Calendar className="w-3 h-3" />
                  <span>{formatDate(event.date)}</span>
                </div>
                <div className="flex items-center gap-0.5">
                  <Clock className="w-3 h-3" />
                  <span>{event.time}</span>
                </div>
              </div>
              
              <div className="flex items-center gap-0.5">
                <MapPin className="w-3 h-3" />
                <span>{formatDistance(event.distance)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tablet and Desktop Layout */}
      <div className="hidden sm:block">
        <div className="flex gap-4 p-4">
          {/* Image */}
          <div className="relative w-20 h-20 md:w-24 md:h-24 bg-gray-100 overflow-hidden rounded-lg flex-shrink-0">
            <img
              src={getEventImage(event.eventType)}
              alt={event.name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
            />
            
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0 flex flex-col justify-between">
            {/* Top section */}
            <div className="mb-2">
              <div className="flex items-start justify-between gap-4 mb-1">
                <h3 className="font-semibold text-gray-900 text-sm md:text-base flex-1 min-w-0 leading-tight">
                  {event.name}
                </h3>
                <div className="flex items-center gap-1 flex-shrink-0">
                  {event.isFree ? (
                    <span className="text-sm md:text-base font-bold text-green-600">GRATIS</span>
                  ) : (
                    <span className="text-sm md:text-base font-bold text-gray-900">€{event.price.toFixed(2)}</span>
                  )}
                </div>
              </div>

              {/* Event type */}
              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs text-purple-600 font-medium">
                  {getEventTypeIcon(event.eventType)} {event.eventType}
                </span>
                <span className="text-xs text-gray-400">•</span>
                <button className="text-xs text-blue-600 hover:text-blue-800 font-medium truncate">
                  {event.restaurant.name}
                </button>
              </div>
            </div>

            {/* Bottom section */}
            <div className="flex items-center justify-between text-sm text-gray-500">
              {/* Date and time */}
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  <span>{formatDate(event.date)}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  <span>{event.time}</span>
                </div>
              </div>

              {/* Distance and availability */}
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  <span>{formatDistance(event.distance)}</span>
                </div>
                
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EventCard;