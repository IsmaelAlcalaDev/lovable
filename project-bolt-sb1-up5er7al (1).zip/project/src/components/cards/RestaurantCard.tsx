import React from 'react';
import { Wifi, Car, Users, MapPin, Heart, Eye, Bookmark, BookmarkCheck } from 'lucide-react';
import { Restaurant } from '../../types';

interface RestaurantCardProps {
  restaurant: Restaurant;
  onClick: () => void;
  isSaved?: boolean;
  onSave?: (restaurant: Restaurant) => void;
  onUnsave?: (restaurantId: string) => void;
}

const RestaurantCard: React.FC<RestaurantCardProps> = ({ 
  restaurant, 
  onClick, 
  isSaved = false, 
  onSave, 
  onUnsave 
}) => {
  const getPriceRange = (range: number) => {
    return '€'.repeat(range);
  };

  const getStatusColor = (isOpen: boolean) => {
    return isOpen ? 'text-green-600' : 'text-red-600';
  };

  const getStatusText = (restaurant: Restaurant) => {
    if (restaurant.isOpen) {
      return `🟢 Abierto hasta ${restaurant.openUntil}`;
    } else {
      return `🔴 Cerrado • Abre a las ${restaurant.opensAt}`;
    }
  };

  // Format distance display
  const formatDistance = (distance: number) => {
    if (distance < 1000) {
      return `${distance}m`;
    } else {
      return `${(distance / 1000).toFixed(1)}km`;
    }
  };

  const displayedTags = restaurant.tags.slice(0, 3);
  const hasMoreTags = restaurant.tags.length > 3;

  const handleSaveClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isSaved && onUnsave) {
      onUnsave(restaurant.id);
    } else if (!isSaved && onSave) {
      onSave(restaurant);
    }
  };

  return (
    <div
      onClick={onClick}
      className="bg-white rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-all duration-200 cursor-pointer overflow-hidden group flex gap-3 sm:gap-4 p-3 sm:p-4"
    >
      {/* Image */}
      <div className="relative w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 bg-gray-100 overflow-hidden rounded-lg flex-shrink-0">
        {restaurant.image ? (
          <img
            src={restaurant.image}
            alt={restaurant.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-orange-100 to-orange-200">
            <div className="text-center">
              <div className="text-xl sm:text-2xl">🍽️</div>
            </div>
          </div>
        )}
        
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0 flex flex-col justify-between">
        {/* Top section */}
        <div>
          {/* Name and Type */}
          <h3 className="font-semibold text-gray-900 text-sm sm:text-base mb-1 line-clamp-1">
            {restaurant.name}
          </h3>
          <p className="text-xs sm:text-sm text-gray-600 mb-2">{restaurant.cuisineType} • {restaurant.establishmentType}</p>

          {/* Price */}
          <div className="flex items-center gap-2 sm:gap-3 mb-2 text-xs sm:text-sm">
            <span className="font-medium text-gray-700">
              {getPriceRange(restaurant.priceRange)}
            </span>
          </div>
        </div>

        {/* Bottom section */}
        <div className="flex items-center justify-between">
          {/* Distance and status */}
          <div className="flex items-center gap-2 sm:gap-3 text-xs sm:text-sm">
            <div className="flex items-center gap-1 text-gray-600">
              <MapPin className="w-3 h-3 sm:w-4 sm:h-4" />
              <span>{formatDistance(restaurant.distance)}</span>
            </div>
            <div className={`${getStatusColor(restaurant.isOpen)} hidden sm:block`}>
              {restaurant.isOpen ? '🟢 Abierto' : '🔴 Cerrado'}
            </div>
          </div>

          {/* Metrics and save button */}
          <div className="flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm text-gray-500">
            <div className="flex items-center gap-1">
              <Eye className="w-3 h-3 sm:w-4 sm:h-4" />
              <span>{restaurant.views}</span>
            </div>
            <div className="flex items-center gap-1">
              <Heart className="w-3 h-3 sm:w-4 sm:h-4 text-red-500 fill-current" />
              <span>{restaurant.savedCount}</span>
            </div>
            {/* Save button */}
            {(onSave || onUnsave) && (
              <button onClick={handleSaveClick} className="p-1 hover:bg-gray-200 hover:scale-110 rounded-md transition-all">
                {isSaved ? (
                  <BookmarkCheck className="w-3 h-3 sm:w-4 sm:h-4 text-orange-600" />
                ) : (
                  <Bookmark className="w-3 h-3 sm:w-4 sm:h-4 text-gray-400 hover:text-gray-600" />
                )}
              </button>
            )}
          </div>

          {/* Tags */}
          <div className="hidden lg:flex gap-1">
            {displayedTags.slice(0, 1).map((tag, index) => (
              <span
                key={index}
                className="inline-flex items-center gap-1 px-2 py-0.5 bg-gray-100 text-xs text-gray-600 rounded-md hover:bg-gray-200 hover:text-gray-800 transition-colors"
              >
                {tag === 'Terraza' && <span>🌿</span>}
                {tag === 'WiFi' && <Wifi className="w-2 h-2" />}
                {tag === 'Parking' && <Car className="w-2 h-2" />}
                {tag === 'Familiar' && <Users className="w-2 h-2" />}
                {tag}
              </span>
            ))}
            {restaurant.tags.length > 1 && (
              <span className="inline-flex items-center px-2 py-0.5 bg-gray-100 text-xs text-gray-500 rounded-full">
                +{restaurant.tags.length - 1}
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RestaurantCard;