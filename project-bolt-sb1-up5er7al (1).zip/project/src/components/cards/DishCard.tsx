import React from 'react';
import { MapPin, Bookmark, BookmarkCheck, UtensilsCrossed } from 'lucide-react';
import { Dish } from '../../types';

interface DishCardProps {
  dish: Dish;
  onClick: () => void;
  isSaved?: boolean;
  onSave?: (dish: Dish) => void;
  onUnsave?: (dishId: string) => void;
}

const DishCard: React.FC<DishCardProps> = ({ 
  dish, 
  onClick, 
  isSaved = false, 
  onSave, 
  onUnsave 
}) => {
  const hasDiscount = dish.originalPrice && dish.originalPrice > dish.price;
  const discountPercentage = hasDiscount 
    ? Math.round(((dish.originalPrice! - dish.price) / dish.originalPrice!) * 100)
    : 0;

  const getSpiceLevel = (level: number) => {
    return '🌶️'.repeat(level);
  };

  // Format distance display
  const formatDistance = (distance: number) => {
    if (distance < 1000) {
      return `${distance}m`;
    } else {
      return `${(distance / 1000).toFixed(1)}km`;
    }
  };

  const handleSaveClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isSaved && onUnsave) {
      onUnsave(dish.id);
    } else if (!isSaved && onSave) {
      onSave(dish);
    }
  };

  return (
    <div
      onClick={onClick}
      className="bg-white rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-all duration-200 cursor-pointer overflow-hidden group flex gap-3 sm:gap-4 p-3 sm:p-4"
    >
      {/* Image */}
      <div className="relative w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 bg-gray-100 overflow-hidden rounded-lg flex-shrink-0">
        {dish.image ? (
          <img
            src={dish.image}
            alt={dish.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-100 to-blue-200">
            <div className="text-center">
              <div className="text-xl sm:text-2xl">🍽️</div>
            </div>
          </div>
        )}
        
        {hasDiscount && (
          <div className="absolute top-1 right-1">
            <span className="bg-red-600 text-white text-xs font-bold px-1.5 py-0.5 rounded">
              -{discountPercentage}%
            </span>
          </div>
        )}

      </div>

      {/* Content */}
      <div className="flex-1 min-w-0 flex flex-col justify-between">
        {/* Name and Price */}
        <div className="mb-1">
          <div className="flex items-start justify-between gap-2 mb-1">
            <h3 className="font-semibold text-gray-900 text-sm sm:text-base flex-1 min-w-0 leading-tight">
              {dish.name}
              {dish.spiceLevel > 0 && (
                <span className="text-xs sm:text-sm ml-1">{getSpiceLevel(dish.spiceLevel)}</span>
              )}
            </h3>
            <div className="flex items-center gap-1 flex-shrink-0">
              <span className="text-sm sm:text-base font-bold text-gray-900">€{dish.price.toFixed(2)}</span>
              {hasDiscount && (
                <span className="text-xs text-gray-500 line-through">
                  €{dish.originalPrice!.toFixed(2)}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Restaurant */}
        <div className="mb-2">
          <button className="text-xs sm:text-sm text-blue-600 hover:text-blue-800 font-medium truncate block">
            {dish.restaurant.name}
          </button>
        </div>

        {/* Time and Votes */}
        <div className="flex items-center justify-between">
          {/* Distance */}
          <div className="flex items-center gap-1 text-xs sm:text-sm text-gray-500">
            <MapPin className="w-3 h-3 sm:w-4 sm:h-4" />
            <span>{formatDistance(dish.distance)}</span>
          </div>

          {/* Metrics and save button */}
          <div className="flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm text-gray-500">
            <div className="flex items-center gap-1">
              <UtensilsCrossed className="w-3 h-3 sm:w-4 sm:h-4 text-blue-500" />
              <span>{dish.cartCount}</span>
            </div>
            {/* Save button */}
            {(onSave || onUnsave) && (
              <button
                onClick={handleSaveClick}
                className="p-1 hover:bg-gray-200 hover:scale-110 rounded-md transition-all"
              >
                {isSaved ? (
                  <BookmarkCheck className="w-3 h-3 sm:w-4 sm:h-4 text-orange-600" />
                ) : (
                  <Bookmark className="w-3 h-3 sm:w-4 sm:h-4 text-gray-400 hover:text-gray-700" />
                )}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DishCard;