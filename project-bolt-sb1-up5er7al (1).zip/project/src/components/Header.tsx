import React, { useState } from 'react';
import { MapPin, User, LogIn, Menu, X } from 'lucide-react';
import { Location } from '../types';
import LocationModal from './modals/LocationModal';
import AuthModal from './modals/AuthModal';
import ProfileModal from './modals/ProfileModal';
import RestaurantRegistrationModal from './modals/RestaurantRegistrationModal';
import { useAuth } from '../hooks/useAuth';

interface HeaderProps {
  location: Location | null;
  onLocationChange: (location: Location) => void;
  onViewEvent?: (event: any) => void;
}

const Header: React.FC<HeaderProps> = ({ location, onLocationChange, onViewEvent }) => {
  const [showLocationModal, setShowLocationModal] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [showRestaurantModal, setShowRestaurantModal] = useState(false);
  const { user, login, register, logout, updateUser } = useAuth();

  return (
    <>
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-6">
          <div className="flex items-center justify-between h-14 sm:h-16">
            {/* Logo */}
            <div className="flex-shrink-0">
              <h1 className="text-lg sm:text-xl md:text-2xl font-bold text-orange-600 flex items-center gap-1.5 sm:gap-2">
                <span className="text-xl sm:text-2xl">🍽️</span>
                <span className="hidden sm:inline bg-gradient-to-r from-orange-600 to-orange-500 bg-clip-text text-transparent">
                  LaCartica
                </span>
              </h1>
            </div>

            {/* Desktop Location */}
            <div className="hidden lg:flex items-center flex-1 justify-center max-w-sm mx-6">
              <button
                onClick={() => setShowLocationModal(true)}
                className="flex items-center gap-2 px-3 py-2 bg-gray-50 hover:bg-gray-100 rounded-lg transition-all duration-200 text-sm max-w-full group border border-gray-200 hover:border-gray-300 shadow-sm"
                title={location ? `Lat: ${location.latitude.toFixed(4)}, Lng: ${location.longitude.toFixed(4)}` : 'Seleccionar ubicación'}
              >
                <MapPin className="w-4 h-4 text-orange-600 group-hover:scale-110 transition-transform" />
                <span className="text-sm text-gray-700 truncate max-w-48 font-medium">
                  {location?.address || 'Detectar ubicación'}
                </span>
              </button>
            </div>

            {/* Desktop Actions */}
            <div className="hidden sm:flex items-center gap-2 sm:gap-3 flex-shrink-0">
              {/* User Authentication */}
              {user ? (
                <button
                  onClick={() => setShowProfileModal(true)}
                  className="flex items-center gap-2 px-3 py-2 bg-gray-50 hover:bg-gray-100 text-gray-700 hover:text-gray-900 rounded-lg transition-all duration-200 text-sm border border-gray-200 hover:border-gray-300 group"
                >
                  <div className="w-6 h-6 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform">
                    <User className="w-3 h-3 text-white" />
                  </div>
                  <span className="font-medium text-sm max-w-24 truncate">{user.name}</span>
                </button>
              ) : (
                <button
                  onClick={() => setShowAuthModal(true)}
                  className="flex items-center gap-2 px-3 py-2 bg-gray-50 hover:bg-gray-100 text-gray-700 hover:text-gray-900 rounded-lg transition-all duration-200 text-sm border border-gray-200 hover:border-gray-300 group"
                >
                  <LogIn className="w-4 h-4 group-hover:scale-110 transition-transform" />
                  <span className="font-medium">Iniciar sesión</span>
                </button>
              )}

              {/* Restaurant Access */}
              <button 
                onClick={() => setShowRestaurantModal(true)}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 text-white rounded-lg transition-all duration-200 text-sm shadow-md hover:shadow-lg group"
              >
                <User className="w-4 h-4 group-hover:scale-110 transition-transform" />
                <span className="font-medium">Restaurantes</span>
              </button>
            </div>

            {/* Mobile Menu Button */}
            <div className="sm:hidden">
              <button
                onClick={() => setShowMobileMenu(!showMobileMenu)}
                className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
              >
                {showMobileMenu ? (
                  <X className="w-5 h-5" />
                ) : (
                  <Menu className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>

          {/* Mobile Location Bar */}
          <div className="lg:hidden pb-3">
            <button
              onClick={() => setShowLocationModal(true)}
              className="flex items-center gap-2.5 px-3 py-2.5 bg-gray-50 hover:bg-gray-100 rounded-xl transition-all duration-200 w-full text-sm border border-gray-200 hover:border-gray-300 group"
              title={location ? `Lat: ${location.latitude.toFixed(4)}, Lng: ${location.longitude.toFixed(4)}` : 'Seleccionar ubicación'}
            >
              <MapPin className="w-4 h-4 text-orange-600 group-hover:scale-110 transition-transform" />
              <span className="text-sm text-gray-700 truncate font-medium">
                {location?.address || 'Detectar ubicación'}
              </span>
            </button>
          </div>

          {/* Mobile Menu */}
          {showMobileMenu && (
            <div className="sm:hidden border-t border-gray-200 py-3 space-y-2">
              {/* User Authentication */}
              {user ? (
                <button
                  onClick={() => {
                    setShowProfileModal(true);
                    setShowMobileMenu(false);
                  }}
                  className="flex items-center gap-3 px-3 py-2.5 bg-gray-50 hover:bg-gray-100 text-gray-700 rounded-lg transition-all duration-200 text-sm w-full border border-gray-200 group"
                >
                  <div className="w-6 h-6 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform">
                    <User className="w-3 h-3 text-white" />
                  </div>
                  <span className="font-medium">{user.name}</span>
                </button>
              ) : (
                <button
                  onClick={() => {
                    setShowAuthModal(true);
                    setShowMobileMenu(false);
                  }}
                  className="flex items-center gap-3 px-3 py-2.5 bg-gray-50 hover:bg-gray-100 text-gray-700 rounded-lg transition-all duration-200 text-sm w-full border border-gray-200 group"
                >
                  <LogIn className="w-4 h-4 group-hover:scale-110 transition-transform" />
                  <span className="font-medium">Iniciar sesión</span>
                </button>
              )}

              {/* Restaurant Access */}
              <button 
                onClick={() => {
                  setShowRestaurantModal(true);
                  setShowMobileMenu(false);
                }}
                className="flex items-center gap-3 px-3 py-2.5 bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 text-white rounded-lg transition-all duration-200 text-sm w-full shadow-md group"
              >
                <User className="w-4 h-4 group-hover:scale-110 transition-transform" />
                <span className="font-medium">Panel Restaurantes</span>
              </button>
            </div>
          )}
        </div>
      </header>

      <LocationModal
        isOpen={showLocationModal}
        onClose={() => setShowLocationModal(false)}
        currentLocation={location}
        onLocationSelect={onLocationChange}
        key={showLocationModal ? 'open' : 'closed'}
      />

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onLogin={login}
        onRegister={register}
      />

      {user && (
        <ProfileModal
          isOpen={showProfileModal}
          onClose={() => setShowProfileModal(false)}
          user={user}
          onUpdateUser={updateUser}
          onLogout={() => {
            logout();
            setShowProfileModal(false);
          }}
          onViewEvent={onViewEvent || (() => {})}
          onViewRestaurant={(restaurant) => {
            console.log('View restaurant from profile:', restaurant.id);
            setShowProfileModal(false);
          }}
          onViewDish={(dish) => {
            console.log('View dish from profile:', dish.id);
            setShowProfileModal(false);
          }}
        />
      )}

      <RestaurantRegistrationModal
        isOpen={showRestaurantModal}
        onClose={() => setShowRestaurantModal(false)}
        mode="register"
      />
    </>
  );
};

export default Header;