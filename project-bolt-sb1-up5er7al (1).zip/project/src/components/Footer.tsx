import React from 'react';
import { Facebook, Instagram, Twitter, Linkedin } from 'lucide-react';

const Footer: React.FC = () => {
  const footerSections = [
    {
      title: 'Sobre nosotros',
      links: [
        'Qué es LaCartica',
        'Cómo funciona',
        'Contacto',
        'Prensa',
        'Trabaja con nosotros'
      ]
    },
    {
      title: 'Para restaurantes',
      links: [
        'Planes y precios',
        'Registrar mi restaurante',
        'Acceso panel',
        'Centro de ayuda',
        'Recursos'
      ]
    },
    {
      title: 'Legal',
      links: [
        'Términos y condiciones',
        'Política de privacidad',
        'Cookies',
        'Aviso legal',
        'RGPD'
      ]
    }
  ];

  const socialLinks = [
    { icon: Facebook, label: 'Facebook', href: '#' },
    { icon: Instagram, label: 'Instagram', href: '#' },
    { icon: Twitter, label: 'Twitter', href: '#' },
    { icon: Linkedin, label: 'LinkedIn', href: '#' }
  ];

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {/* Company Sections */}
          {footerSections.map((section, index) => (
            <div key={index}>
              <h3 className="text-base sm:text-lg font-semibold mb-3 sm:mb-4">{section.title}</h3>
              <ul className="space-y-1.5 sm:space-y-2">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a
                      href="#"
                      className="text-gray-300 hover:text-white transition-colors text-sm"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {/* Social & Newsletter */}
          <div>
            <h3 className="text-base sm:text-lg font-semibold mb-3 sm:mb-4">Síguenos</h3>
            <div className="flex gap-3 sm:gap-4 mb-4 sm:mb-6">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  className="p-2 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors"
                  aria-label={social.label}
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
            
            <div className="space-y-2 sm:space-y-3">
              <div>
                <a
                  href="#"
                  className="text-gray-300 hover:text-white transition-colors text-sm block"
                >
                  Newsletter
                </a>
              </div>
              <div>
                <a
                  href="#"
                  className="text-gray-300 hover:text-white transition-colors text-sm block"
                >
                  Blog
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-800 mt-8 sm:mt-12 pt-6 sm:pt-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center gap-2 mb-3 sm:mb-4 md:mb-0">
              <span className="text-xl sm:text-2xl">🍽️</span>
              <span className="text-lg sm:text-xl font-bold text-orange-500">LaCartica</span>
            </div>
            <div className="text-sm text-gray-400 text-center md:text-right">
              <p>&copy; 2025 LaCartica. Todos los derechos reservados.</p>
              <p className="mt-1 text-xs sm:text-sm">Descubre los mejores sabores cerca de ti</p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;