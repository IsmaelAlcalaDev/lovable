import React from 'react';
import { Search, MapPin, Clock, Euro, Star, Filter } from 'lucide-react';
import { SearchTab } from '../types';

interface HeroProps {
  activeTab: SearchTab;
  onTabChange: (tab: SearchTab) => void;
  query: string;
  onQueryChange: (query: string) => void;
  placeholder: string;
  suggestions: any[];
  quickFilters: {
    nearMe: boolean;
    openNow: boolean;
    economic: boolean;
    topRated: boolean;
  };
  onQuickFilterChange: (filter: keyof HeroProps['quickFilters']) => void;
  onOpenFilters: () => void;
}

const Hero: React.FC<HeroProps> = ({
  activeTab,
  onTabChange,
  query,
  onQueryChange,
  placeholder,
  suggestions,
  quickFilters,
  onQuickFilterChange,
  onOpenFilters
}) => {
  const tabs = [
    { id: 'restaurants' as const, label: 'Restaurantes', icon: '🏪', shortLabel: 'Rest.' },
    { id: 'dishes' as const, label: 'Platos', icon: '🍽️', shortLabel: 'Platos' },
    { id: 'events' as const, label: 'Eventos', icon: '🎪', shortLabel: 'Event.' }
  ];

  return (
    <div className="bg-gradient-to-br from-orange-50/80 via-white to-blue-50/80">
      {/* Container with perfect responsive padding */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Responsive vertical spacing */}
        <div className="py-4 sm:py-6 lg:py-8 xl:py-10">
          
          {/* Hero Text - Perfect typography scaling */}
          <div className="text-center mb-4 sm:mb-6 lg:mb-8">
            <h2 className="text-2xl sm:text-3xl lg:text-4xl xl:text-5xl font-bold text-gray-900 mb-3 sm:mb-4 lg:mb-6 leading-tight tracking-tight">
              Descubre sabores únicos cerca de ti
            </h2>
            <p className="text-base sm:text-lg lg:text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
              Los mejores restaurantes, platos y promociones en tu zona
            </p>
          </div>

          {/* Main Search Container - Perfect centering */}
          <div className="max-w-4xl mx-auto space-y-4 sm:space-y-6">
            
            {/* Search Tabs - Flawless responsive behavior */}
            <div className="flex justify-center">
              {/* Mobile Tabs - Optimized for touch */}
              <div className="block sm:hidden w-full max-w-sm">
                <div className="flex gap-0.5 p-0.5 bg-white/90 backdrop-blur-sm rounded-xl shadow-lg border border-gray-200/60">
                  {tabs.map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => onTabChange(tab.id)}
                      className={`flex-1 flex items-center justify-center gap-1 px-2 py-2.5 rounded-lg text-xs font-semibold transition-all duration-300 ${
                        activeTab === tab.id
                          ? 'bg-gradient-to-r from-orange-600 to-orange-500 text-white shadow-lg shadow-orange-200/50 scale-105'
                          : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50/80'
                      }`}
                    >
                      <span className="text-base">{tab.icon}</span>
                      <span className="text-xs font-bold">{tab.shortLabel}</span>
                    </button>
                  ))}
                </div>
              </div>
              
              {/* Tablet Tabs - Medium screens */}
              <div className="hidden sm:block lg:hidden">
                <div className="flex gap-1 p-1 bg-white/90 backdrop-blur-sm rounded-xl shadow-lg border border-gray-200/60">
                  {tabs.map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => onTabChange(tab.id)}
                      className={`flex items-center gap-1.5 px-4 py-2.5 rounded-lg text-sm font-semibold transition-all duration-300 ${
                        activeTab === tab.id
                          ? 'bg-gradient-to-r from-orange-600 to-orange-500 text-white shadow-lg shadow-orange-200/50 transform scale-105'
                          : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50/80 hover:scale-102'
                      }`}
                    >
                      <span className="text-lg">{tab.icon}</span>
                      <span>{tab.label}</span>
                    </button>
                  ))}
                </div>
              </div>
              
              {/* Desktop Tabs - Large screens */}
              <div className="hidden lg:block">
                <div className="flex gap-1.5 p-1.5 bg-white/90 backdrop-blur-sm rounded-xl shadow-lg border border-gray-200/60">
                  {tabs.map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => onTabChange(tab.id)}
                      className={`flex items-center gap-2.5 px-6 py-3 rounded-lg text-base font-semibold transition-all duration-300 ${
                        activeTab === tab.id
                          ? 'bg-gradient-to-r from-orange-600 to-orange-500 text-white shadow-lg shadow-orange-200/50 transform scale-105'
                          : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50/80 hover:scale-102'
                      }`}
                    >
                      <span className="text-xl">{tab.icon}</span>
                      <span>{tab.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Search Bar - Perfect responsive scaling */}
            <div className="relative">
              <div className="relative group">
                {/* Gradient background effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-orange-200/20 to-blue-200/20 rounded-xl blur-lg group-focus-within:blur-xl transition-all duration-300"></div>
                
                {/* Main search container */}
                <div className="relative bg-white/95 backdrop-blur-sm rounded-xl shadow-lg border border-gray-200/60 group-focus-within:shadow-xl group-focus-within:border-orange-300/60 transition-all duration-300">
                  <div className="flex items-center">
                    {/* Search icon - responsive sizing */}
                    <div className="pl-3 sm:pl-4 lg:pl-5">
                      <Search className="w-5 h-5 sm:w-6 sm:h-6 text-gray-400 group-focus-within:text-orange-500 transition-colors duration-300" />
                    </div>
                    
                    {/* Input field - perfect responsive behavior */}
                    <input
                      type="text"
                      value={query}
                      onChange={(e) => onQueryChange(e.target.value)}
                      placeholder={placeholder}
                      className="flex-1 px-3 sm:px-4 lg:px-6 py-4 sm:py-5 lg:py-6 text-base sm:text-lg lg:text-xl bg-transparent border-0 focus:outline-none focus:ring-0 placeholder-gray-500 text-gray-900 font-medium rounded-xl"
                    />
                    
                    {/* Filter button - responsive sizing */}
                    <div className="pr-3 sm:pr-4 lg:pr-5">
                      <button
                        onClick={onOpenFilters}
                        className="p-1.5 sm:p-2 lg:p-2.5 text-gray-400 hover:text-orange-600 hover:bg-orange-50 rounded-lg transition-all duration-200 group"
                      >
                        <Filter className="w-5 h-5 sm:w-6 sm:h-6 group-hover:scale-110 transition-transform" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Search Suggestions - Perfect positioning */}
              {suggestions.length > 0 && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-white/95 backdrop-blur-sm border border-gray-200/60 rounded-xl shadow-xl z-20 max-h-64 overflow-y-auto">
                  {suggestions.map((suggestion, index) => (
                    <button
                      key={index}
                      className="w-full px-3 sm:px-4 lg:px-5 py-2.5 sm:py-3 text-left hover:bg-gradient-to-r hover:from-orange-50 hover:to-blue-50 border-b border-gray-100/50 last:border-b-0 flex items-center gap-2.5 sm:gap-3 transition-all duration-200 group"
                      onClick={() => onQueryChange(suggestion.name)}
                    >
                      {/* Suggestion icon */}
                      <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-gray-100 to-gray-200 rounded-xl flex items-center justify-center group-hover:scale-105 transition-transform">
                        <span className="text-lg sm:text-xl">
                          {suggestion.type === 'restaurant' ? '🏪' : 
                           suggestion.type === 'dish' ? '🍽️' : '🎯'}
                        </span>
                      </div>
                      
                      {/* Suggestion content */}
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-gray-900 text-sm sm:text-base truncate group-hover:text-orange-700 transition-colors">
                          {suggestion.name}
                        </div>
                        <div className="text-xs sm:text-sm text-gray-500 truncate">{suggestion.subtitle}</div>
                      </div>
                      
                      {/* Distance badge */}
                      <div className="text-xs sm:text-sm text-gray-400 font-medium bg-gray-100 px-2 py-1 rounded-lg">
                        {suggestion.distance}
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Quick Filters - Perfect responsive layout */}
            <div className="flex justify-center">
              <div className="w-full max-w-4xl">
                {/* Mobile filters - Horizontal scroll */}
                <div className="flex sm:hidden gap-1.5 overflow-x-auto pb-2 scrollbar-hide px-1">
                  {[
                    { key: 'nearMe', icon: MapPin, label: 'Cerca', color: 'orange' },
                    ...(activeTab !== 'events' ? [{ key: 'openNow', icon: Clock, label: 'Abierto', color: 'green' }] : []),
                    { key: 'economic', icon: Euro, label: '€€', color: 'blue' },
                    { key: 'topRated', icon: Star, label: '⭐', color: 'yellow' },
                    ...(activeTab === 'events' ? [{ key: 'openNow', icon: () => <span className="text-sm">🆓</span>, label: 'Gratis', color: 'green' }] : [])
                  ].map((filter) => (
                    <button
                      key={filter.key}
                      onClick={() => onQuickFilterChange(filter.key as any)}
                      className={`flex items-center gap-1 px-3 py-2 rounded-lg text-xs font-semibold transition-all duration-300 whitespace-nowrap flex-shrink-0 shadow-sm ${
                        quickFilters[filter.key as keyof typeof quickFilters]
                          ? `${filter.color === 'orange' ? 'bg-orange-600' : 
                              filter.color === 'green' ? 'bg-green-600' : 
                              filter.color === 'blue' ? 'bg-blue-600' : 
                              'bg-yellow-600'} text-white shadow-lg scale-105`
                          : 'bg-white/90 backdrop-blur-sm border border-gray-200/60 text-gray-700 hover:bg-gray-100 hover:text-gray-900 hover:scale-105 hover:shadow-md hover:border-gray-300'
                      }`}
                    >
                      {typeof filter.icon === 'function' ? filter.icon() : <filter.icon className="w-4 h-4" />}
                      <span>{filter.label}</span>
                    </button>
                  ))}
                </div>

                {/* Tablet filters - Wrapped layout */}
                <div className="hidden sm:flex lg:hidden flex-wrap justify-center gap-2">
                  {[
                    { key: 'nearMe', icon: MapPin, label: 'Cerca de mí', color: 'orange' },
                    ...(activeTab !== 'events' ? [{ key: 'openNow', icon: Clock, label: 'Abierto ahora', color: 'green' }] : []),
                    { key: 'economic', icon: Euro, label: 'Económico', color: 'blue' },
                    { key: 'topRated', icon: Star, label: activeTab === 'events' ? 'Populares' : 'Mejor valorados', color: 'yellow' },
                    ...(activeTab === 'events' ? [{ key: 'openNow', icon: () => <span className="text-sm">🆓</span>, label: 'Gratis', color: 'green' }] : [])
                  ].map((filter) => (
                    <button
                      key={filter.key}
                      onClick={() => onQuickFilterChange(filter.key as any)}
                      className={`flex items-center gap-1.5 px-4 py-2.5 rounded-lg text-sm font-semibold transition-all duration-300 shadow-sm ${
                        quickFilters[filter.key as keyof typeof quickFilters]
                          ? `${filter.color === 'orange' ? 'bg-orange-600' : 
                              filter.color === 'green' ? 'bg-green-600' : 
                              filter.color === 'blue' ? 'bg-blue-600' : 
                              'bg-yellow-600'} text-white shadow-lg scale-105`
                          : 'bg-white/90 backdrop-blur-sm border border-gray-200/60 text-gray-700 hover:bg-gray-100 hover:text-gray-900 hover:scale-105 hover:shadow-md hover:border-gray-300'
                      }`}
                    >
                      {typeof filter.icon === 'function' ? filter.icon() : <filter.icon className="w-4 h-4" />}
                      <span>{filter.label}</span>
                    </button>
                  ))}
                </div>

                {/* Desktop filters - Centered layout */}
                <div className="hidden lg:flex justify-center gap-3">
                  {[
                    { key: 'nearMe', icon: MapPin, label: 'Cerca de mí', color: 'orange' },
                    ...(activeTab !== 'events' ? [{ key: 'openNow', icon: Clock, label: 'Abierto ahora', color: 'green' }] : []),
                    { key: 'economic', icon: Euro, label: 'Económico', color: 'blue' },
                    { key: 'topRated', icon: Star, label: activeTab === 'events' ? 'Más populares' : 'Mejor valorados', color: 'yellow' },
                    ...(activeTab === 'events' ? [{ key: 'openNow', icon: () => <span className="text-base">🆓</span>, label: 'Eventos gratuitos', color: 'green' }] : [])
                  ].map((filter) => (
                    <button
                      key={filter.key}
                      onClick={() => onQuickFilterChange(filter.key as any)}
                      className={`flex items-center gap-2 px-5 py-3 rounded-lg text-base font-semibold transition-all duration-300 shadow-sm ${
                        quickFilters[filter.key as keyof typeof quickFilters]
                          ? `${filter.color === 'orange' ? 'bg-orange-600' : 
                              filter.color === 'green' ? 'bg-green-600' : 
                              filter.color === 'blue' ? 'bg-blue-600' : 
                              'bg-yellow-600'} text-white shadow-lg scale-105`
                          : 'bg-white/90 backdrop-blur-sm border border-gray-200/60 text-gray-700 hover:bg-gray-100 hover:text-gray-900 hover:scale-105 hover:shadow-md hover:border-gray-300'
                      }`}
                    >
                      {typeof filter.icon === 'function' ? filter.icon() : <filter.icon className="w-5 h-5" />}
                      <span>{filter.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;