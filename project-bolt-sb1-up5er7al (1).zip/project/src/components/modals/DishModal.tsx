import React from 'react';
import { X, MapPin, Heart, Share2, Phone, ExternalLink, Bookmark, BookmarkCheck, Euro, Users, UtensilsCrossed } from 'lucide-react';
import { Dish } from '../../types';

interface DishModalProps {
  isOpen: boolean;
  onClose: () => void;
  dish: Dish | null;
  onViewRestaurant: (restaurantId: string) => void;
  isDishSaved?: boolean;
  onSaveDish?: (dish: Dish) => void;
  onUnsaveDish?: (dishId: string) => void;
  onShare?: (dish: Dish) => void;
}

const DishModal: React.FC<DishModalProps> = ({
  isOpen,
  onClose,
  dish,
  onViewRestaurant,
  isDishSaved = false,
  onSaveDish,
  onUnsaveDish,
  onShare
}) => {
  if (!isOpen || !dish) return null;

  const hasDiscount = dish.originalPrice && dish.originalPrice > dish.price;
  const discountPercentage = hasDiscount 
    ? Math.round(((dish.originalPrice! - dish.price) / dish.originalPrice!) * 100)
    : 0;

  // Format distance display
  const formatDistance = (distance: number) => {
    if (distance < 1000) {
      return `${distance}m`;
    } else {
      return `${(distance / 1000).toFixed(1)}km`;
    }
  };

  const getSpiceLevel = (level: number) => {
    return '🌶️'.repeat(level);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: dish.name,
        text: `${dish.name} en ${dish.restaurant.name} - €${dish.price.toFixed(2)}`,
        url: window.location.href
      }).catch(() => {
        // If share fails or is cancelled, fall back to clipboard
        const shareText = `🍽️ ${dish.name}\n📍 ${dish.restaurant.name}\n💰 €${dish.price.toFixed(2)}\n\n${dish.description}\n\n¡Descúbrelo en LaCartica!`;
        navigator.clipboard.writeText(shareText).then(() => {
          alert('¡Enlace copiado al portapapeles!');
        });
      });
    } else {
      // Fallback: copy to clipboard
      const shareText = `🍽️ ${dish.name}\n📍 ${dish.restaurant.name}\n💰 €${dish.price.toFixed(2)}\n\n${dish.description}\n\n¡Descúbrelo en LaCartica!`;
      navigator.clipboard.writeText(shareText).then(() => {
        alert('¡Enlace copiado al portapapeles!');
      });
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-hidden shadow-2xl">
        {/* Header with image */}
        <div className="relative h-48 md:h-64">
          {dish.image ? (
            <img
              src={dish.image}
              alt={dish.name}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-orange-100 to-orange-200">
              <div className="text-center">
                <div className="text-6xl mb-2">🍽️</div>
                <div className="text-lg font-medium text-gray-700">Plato delicioso</div>
              </div>
            </div>
          )}
          
          {/* Overlay badges */}
          <div className="absolute top-4 left-4 flex gap-2">
            {hasDiscount && (
              <span className="bg-red-600 text-white text-sm font-bold px-3 py-1 rounded-full">
                -{discountPercentage}% OFF
              </span>
            )}
            {dish.dietTags.map((tag, index) => (
              <span key={index} className="bg-green-600 text-white text-sm font-bold px-3 py-1 rounded-full">
                {tag}
              </span>
            ))}
          </div>

          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 bg-white bg-opacity-90 hover:bg-opacity-100 rounded-full transition-all shadow-sm"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>

          {/* Action buttons */}
          <div className="absolute bottom-4 right-4 flex gap-2">
            {onSaveDish && onUnsaveDish && (
              <button 
                onClick={() => isDishSaved ? onUnsaveDish(dish.id) : onSaveDish(dish)}
                className="p-2 bg-white bg-opacity-90 hover:bg-opacity-100 rounded-full transition-all shadow-sm"
              >
                {isDishSaved ? (
                  <BookmarkCheck className="w-5 h-5 text-orange-600" />
                ) : (
                  <Bookmark className="w-5 h-5 text-gray-600" />
                )}
              </button>
            )}
            <button 
              onClick={handleShare}
              className="p-2 bg-white bg-opacity-90 hover:bg-opacity-100 rounded-full transition-all shadow-sm"
            >
              <Share2 className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </div>

        <div className="overflow-y-auto max-h-[calc(90vh-200px)]">
          {/* Content */}
          <div className="p-6">
            {/* Title and price */}
            <div className="flex items-start justify-between gap-4 mb-4">
              <div className="flex-1">
                <h1 className="text-2xl font-bold text-gray-900 mb-2">
                  {dish.name}
                  {dish.spiceLevel > 0 && (
                    <span className="text-lg ml-2">{getSpiceLevel(dish.spiceLevel)}</span>
                  )}
                </h1>
                <div className="flex items-center gap-2 mb-3">
                  <button 
                    onClick={() => onViewRestaurant(dish.restaurant.id)}
                    className="text-blue-600 hover:text-blue-800 font-medium flex items-center gap-1"
                  >
                    {dish.restaurant.name}
                    <ExternalLink className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-gray-900">€{dish.price.toFixed(2)}</div>
                {hasDiscount && (
                  <div className="text-lg text-gray-500 line-through">
                    €{dish.originalPrice!.toFixed(2)}
                  </div>
                )}
              </div>
            </div>

            {/* Dish details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
              <div className="text-center">
                <MapPin className="w-5 h-5 text-gray-600 mx-auto mb-1" />
                <div className="text-sm font-medium text-gray-900">{formatDistance(dish.distance)}</div>
                <div className="text-xs text-gray-500">de distancia</div>
              </div>
              <div className="text-center">
                <UtensilsCrossed className="w-5 h-5 text-blue-500 mx-auto mb-1" />
                <div className="text-sm font-medium text-gray-900">{dish.cartCount}</div>
                <div className="text-xs text-gray-500">pedidos</div>
              </div>
            </div>

            {/* Description */}
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Descripción</h3>
              <p className="text-gray-700 leading-relaxed">{dish.description}</p>
            </div>

            {/* Ingredients */}
            {/* Diet tags and allergens */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              {dish.dietTags.length > 0 && (
                <div className="p-3 bg-green-50 rounded-lg">
                  <div className="text-sm font-medium text-green-900 mb-2">Apto para</div>
                  <div className="flex flex-wrap gap-1">
                    {dish.dietTags.map((tag, index) => (
                      <span key={index} className="text-xs bg-green-200 text-green-800 px-2 py-1 rounded">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}
              {dish.allergens.length > 0 && (
                <div className="p-3 bg-red-50 rounded-lg">
                  <div className="text-sm font-medium text-red-900 mb-2">Contiene alérgenos</div>
                  <div className="flex flex-wrap gap-1">
                    {dish.allergens.map((allergen, index) => (
                      <span key={index} className="text-xs bg-red-200 text-red-800 px-2 py-1 rounded">
                        {allergen}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Restaurant info */}
            <div className="border-t pt-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Información del restaurante</h3>
              <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                  <span className="text-xl">🏪</span>
                </div>
                <div className="flex-1">
                  <div className="font-medium text-gray-900">{dish.restaurant.name}</div>
                  <div className="text-sm text-gray-600">{dish.restaurant.address}</div>
                  <div className="text-sm text-gray-600">{dish.restaurant.cuisineType}</div>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-sm text-gray-600">{'€'.repeat(dish.restaurant.priceRange)}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button className="p-2 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                    <Phone className="w-4 h-4 text-gray-600" />
                  </button>
                  <button 
                    onClick={() => onViewRestaurant(dish.restaurant.id)}
                    className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
                  >
                    Ver perfil
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DishModal;