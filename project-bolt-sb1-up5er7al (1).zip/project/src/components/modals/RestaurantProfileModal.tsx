import React, { useState } from 'react';
import { X, Building, MapPin, Phone, Globe, Users, Shield, AlertTriangle, Clock } from 'lucide-react';
import { Restaurant } from '../../types';

interface RestaurantProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  restaurant: Restaurant;
  onClaimRestaurant: (restaurant: Restaurant) => void;
}

const RestaurantProfileModal: React.FC<RestaurantProfileModalProps> = ({
  isOpen,
  onClose,
  restaurant,
  onClaimRestaurant
}) => {
  const [showClaimConfirmation, setShowClaimConfirmation] = useState(false);

  if (!isOpen) return null;

  const getPriceRange = (range: number) => {
    return '€'.repeat(range);
  };

  const formatDistance = (distance: number) => {
    if (distance < 1000) {
      return `${distance}m`;
    } else {
      return `${(distance / 1000).toFixed(1)}km`;
    }
  };

  const getStatusColor = (isOpen: boolean) => {
    return isOpen ? 'text-green-600' : 'text-red-600';
  };

  const handleClaimClick = () => {
    setShowClaimConfirmation(true);
  };

  const handleConfirmClaim = () => {
    onClaimRestaurant(restaurant);
    setShowClaimConfirmation(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[95vh] overflow-hidden shadow-2xl">
        {/* Header with image */}
        <div className="relative h-48 md:h-64">
          {restaurant.image ? (
            <img
              src={restaurant.image}
              alt={restaurant.name}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-orange-100 to-orange-200">
              <div className="text-center">
                <div className="text-6xl mb-2">🏪</div>
                <div className="text-lg font-medium text-gray-700">Restaurante</div>
              </div>
            </div>
          )}
          
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 bg-white bg-opacity-90 hover:bg-opacity-100 rounded-full transition-all shadow-sm"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>

          {/* Claim button */}
          <div className="absolute bottom-4 right-4">
            <button
              onClick={handleClaimClick}
              className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors font-medium shadow-lg"
            >
              <Shield className="w-4 h-4" />
              ¿Eres el propietario?
            </button>
          </div>
        </div>

        <div className="overflow-y-auto max-h-[calc(95vh-200px)]">
          {/* Content */}
          <div className="p-6">
            {/* Title and basic info */}
            <div className="mb-6">
              <h1 className="text-2xl font-bold text-gray-900 mb-2">{restaurant.name}</h1>
              <div className="flex items-center gap-4 mb-3">
                <span className="font-medium text-gray-700">
                  {getPriceRange(restaurant.priceRange)}
                </span>
                <div className={`${getStatusColor(restaurant.isOpen)}`}>
                  {restaurant.isOpen ? '🟢 Abierto' : '🔴 Cerrado'}
                </div>
              </div>
              <p className="text-gray-600">{restaurant.cuisineType} • {restaurant.establishmentType}</p>
            </div>

            {/* Restaurant details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
              <div className="text-center">
                <MapPin className="w-5 h-5 text-gray-600 mx-auto mb-1" />
                <div className="text-sm font-medium text-gray-900">{formatDistance(restaurant.distance)}</div>
                <div className="text-xs text-gray-500">de distancia</div>
              </div>
              <div className="text-center">
                <Users className="w-5 h-5 text-gray-600 mx-auto mb-1" />
                <div className="text-sm font-medium text-gray-900">{restaurant.views}</div>
                <div className="text-xs text-gray-500">visualizaciones</div>
              </div>
            </div>

            {/* Description */}
            {restaurant.description && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Descripción</h3>
                <p className="text-gray-700 leading-relaxed">{restaurant.description}</p>
              </div>
            )}

            {/* Services */}
            {restaurant.services.length > 0 && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Servicios</h3>
                <div className="flex flex-wrap gap-2">
                  {restaurant.services.map((service, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm"
                    >
                      {service}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Tags */}
            {restaurant.tags.length > 0 && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Características</h3>
                <div className="flex flex-wrap gap-2">
                  {restaurant.tags.map((tag, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Promotions */}
            {restaurant.hasActivePromotions && restaurant.currentPromotions.length > 0 && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Promociones activas</h3>
                <div className="space-y-2">
                  {restaurant.currentPromotions.map((promo, index) => (
                    <div key={index} className="p-3 bg-red-50 border border-red-200 rounded-lg">
                      <div className="flex items-center gap-2">
                        <span className="text-red-600 font-bold">🎯</span>
                        <span className="text-red-800 font-medium">{promo}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Contact info */}
            <div className="border-t pt-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Información de contacto</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-gray-600" />
                  <span className="text-gray-700">{restaurant.address}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-gray-600" />
                  <span className="text-gray-700">{restaurant.phone}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-gray-600" />
                  <span className="text-gray-700">
                    {restaurant.isOpen 
                      ? `Abierto hasta las ${restaurant.openUntil}`
                      : `Cerrado • Abre a las ${restaurant.opensAt}`
                    }
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Claim confirmation modal */}
          {showClaimConfirmation && (
            <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-xl max-w-md w-full p-6">
                <div className="text-center mb-6">
                  <AlertTriangle className="w-12 h-12 text-orange-600 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    ¿Eres el propietario de este restaurante?
                  </h3>
                  <p className="text-gray-600 text-sm">
                    Al reclamar este perfil, iniciarás un proceso de verificación donde deberás 
                    demostrar que eres el propietario o tienes autorización para gestionar este negocio.
                  </p>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                  <h4 className="font-medium text-blue-900 mb-2">Proceso de verificación:</h4>
                  <ul className="text-sm text-blue-700 space-y-1">
                    <li>• Verificación de identidad</li>
                    <li>• Documentos de propiedad/gestión</li>
                    <li>• Confirmación en 24-48 horas</li>
                  </ul>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setShowClaimConfirmation(false)}
                    className="flex-1 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
                  >
                    Cancelar
                  </button>
                  <button
                    onClick={handleConfirmClaim}
                    className="flex-1 py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors font-medium"
                  >
                    Sí, reclamar
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default RestaurantProfileModal;