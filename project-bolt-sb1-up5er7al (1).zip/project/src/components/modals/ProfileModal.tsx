import React, { useState } from 'react';
import { X, User, Mail, Phone, MapPin, Bell, Heart, Calendar, Settings, Euro, Clock, Users, CheckCircle, AlertCircle, XCircle } from 'lucide-react';
import { User as UserType, Event, Restaurant, Dish } from '../../types';
import { mockEvents, mockRestaurants, mockDishes, mockReservations } from '../../data/mockData';
import ReservationModal from './ReservationModal';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserType;
  onUpdateUser: (updates: Partial<UserType>) => void;
  onLogout: () => void;
  onViewEvent: (event: Event) => void;
  onViewRestaurant?: (restaurant: Restaurant) => void;
  onViewDish?: (dish: Dish) => void;
}

const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  user,
  onUpdateUser,
  onLogout,
  onViewEvent,
  onViewRestaurant,
  onViewDish
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'saved' | 'reservations' | 'settings'>('profile');
  const [savedTab, setSavedTab] = useState<'events' | 'restaurants' | 'dishes'>('events');
  const [isEditing, setIsEditing] = useState(false);
  const [selectedReservation, setSelectedReservation] = useState(null);
  const [showReservationModal, setShowReservationModal] = useState(false);
  const [editForm, setEditForm] = useState({
    name: user.name,
    phone: user.phone || '',
    dietaryRestrictions: user.preferences.dietaryRestrictions,
    allergens: user.preferences.allergens
  });

  if (!isOpen) return null;

  const handleSave = () => {
    onUpdateUser({
      name: editForm.name,
      phone: editForm.phone,
      preferences: {
        ...user.preferences,
        dietaryRestrictions: editForm.dietaryRestrictions,
        allergens: editForm.allergens
      }
    });
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditForm({
      name: user.name,
      phone: user.phone || '',
      dietaryRestrictions: user.preferences.dietaryRestrictions,
      allergens: user.preferences.allergens
    });
    setIsEditing(false);
  };

  const savedEvents = mockEvents.filter(event => user.savedEvents.includes(event.id));
  const savedRestaurants = mockRestaurants.filter(restaurant => user.savedRestaurants.includes(restaurant.id));
  const savedDishes = mockDishes.filter(dish => user.savedDishes.includes(dish.id));
  const userReservations = mockReservations.filter(reservation => user.reservations.includes(reservation.id));
  
  const restaurantReservations = userReservations.filter(reservation => reservation.type === 'restaurant');
  const eventReservations = userReservations.filter(reservation => reservation.type === 'event');
  
  console.log('User reservations IDs:', user.reservations);
  console.log('Available mock reservations:', mockReservations.map(r => r.id));
  console.log('Filtered user reservations:', userReservations);

  const totalSavedItems = user.savedEvents.length + user.savedRestaurants.length + user.savedDishes.length;

  const tabs = [
    { id: 'profile' as const, label: 'Perfil', icon: User },
    { id: 'saved' as const, label: 'Guardados', icon: Heart },
    { id: 'reservations' as const, label: 'Reservas', icon: Calendar },
    { id: 'settings' as const, label: 'Configuración', icon: Settings }
  ];

  const savedTabs = [
    { id: 'events' as const, label: 'Eventos', count: user.savedEvents.length, icon: '🎪' },
    { id: 'restaurants' as const, label: 'Restaurantes', count: user.savedRestaurants.length, icon: '🏪' },
    { id: 'dishes' as const, label: 'Platos', count: user.savedDishes.length, icon: '🍽️' }
  ];

  const toggleArrayItem = (array: string[], item: string) => {
    return array.includes(item) 
      ? array.filter(i => i !== item)
      : [...array, item];
  };

  const formatDistance = (distance: number) => {
    if (distance < 1000) {
      return `${distance}m`;
    } else {
      return `${(distance / 1000).toFixed(1)}km`;
    }
  };

  const getPriceRange = (range: number) => {
    return '€'.repeat(range);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'confirmed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'pending':
        return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'cancelled':
        return <XCircle className="w-4 h-4 text-red-500" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-blue-500" />;
      default:
        return <AlertCircle className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'Confirmada';
      case 'pending':
        return 'Pendiente';
      case 'cancelled':
        return 'Cancelada';
      case 'completed':
        return 'Completada';
      default:
        return status;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'text-green-600 bg-green-50';
      case 'pending':
        return 'text-yellow-600 bg-yellow-50';
      case 'cancelled':
        return 'text-red-600 bg-red-50';
      case 'completed':
        return 'text-blue-600 bg-blue-50';
      default:
        return 'text-gray-600 bg-gray-50';
    }
  };

  const handleModifyReservation = (reservationId: string, newData: any) => {
    // In a real app, this would call an API
    console.log('Modifying reservation:', reservationId, newData);
    // Update the reservation in the mock data
    const reservationIndex = mockReservations.findIndex(r => r.id === reservationId);
    if (reservationIndex !== -1) {
      mockReservations[reservationIndex] = {
        ...mockReservations[reservationIndex],
        ...newData
      };
    }
    setShowReservationModal(false);
  };

  const handleCancelReservation = (reservationId: string) => {
    // In a real app, this would call an API
    console.log('Cancelling reservation:', reservationId);
    // Update the reservation status in the mock data
    const reservationIndex = mockReservations.findIndex(r => r.id === reservationId);
    if (reservationIndex !== -1) {
      mockReservations[reservationIndex].status = 'cancelled';
    }
    setShowReservationModal(false);
  };

  return (
    <>
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-xl sm:max-w-2xl w-full max-h-[95vh] overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-6 border-b bg-gradient-to-r from-orange-50 to-blue-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 sm:w-12 sm:h-12 bg-orange-600 rounded-full flex items-center justify-center">
              <User className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-semibold text-gray-900">{user.name}</h2>
              <p className="text-xs sm:text-sm text-gray-600">{user.email}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 sm:p-2 hover:bg-white hover:bg-opacity-50 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 sm:w-6 sm:h-6 text-gray-600" />
          </button>
        </div>

        {/* Tabs */}
        <div className="border-b">
          <div className="flex">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 sm:px-6 py-3 sm:py-4 text-xs sm:text-sm font-medium transition-colors ${
                  activeTab === tab.id
                    ? 'text-orange-600 border-b-2 border-orange-600 bg-orange-50'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                }`}
              >
                <tab.icon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                {tab.label}
                {tab.id === 'saved' && totalSavedItems > 0 && (
                  <span className="bg-orange-600 text-white text-xs font-bold px-1.5 py-0.5 rounded-full">
                    {totalSavedItems}
                  </span>
                )}
                {tab.id === 'reservations' && userReservations.length > 0 && (
                  <span className="bg-blue-600 text-white text-xs font-bold px-1.5 py-0.5 rounded-full">
                    {userReservations.length}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-y-auto max-h-[calc(95vh-160px)] sm:max-h-[calc(95vh-200px)]">
          {/* Profile Tab */}
          {activeTab === 'profile' && (
            <div className="p-4 sm:p-6 space-y-4 sm:space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-base sm:text-lg font-semibold text-gray-900">Información personal</h3>
                {!isEditing ? (
                  <button
                    onClick={() => setIsEditing(true)}
                    className="px-3 sm:px-4 py-1.5 sm:py-2 text-orange-600 hover:text-orange-700 font-medium text-xs sm:text-sm"
                  >
                    Editar
                  </button>
                ) : (
                  <div className="flex gap-2">
                    <button
                      onClick={handleCancel}
                      className="px-3 sm:px-4 py-1.5 sm:py-2 text-gray-600 hover:text-gray-700 font-medium text-xs sm:text-sm"
                    >
                      Cancelar
                    </button>
                    <button
                      onClick={handleSave}
                      className="px-3 sm:px-4 py-1.5 sm:py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 font-medium text-xs sm:text-sm"
                    >
                      Guardar
                    </button>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-2">
                    Nombre completo
                  </label>
                  {isEditing ? (
                    <input
                      type="text"
                      value={editForm.name}
                      onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                      className="w-full px-2.5 sm:px-3 py-1.5 sm:py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm sm:text-base"
                    />
                  ) : (
                    <p className="text-sm sm:text-base text-gray-900">{user.name}</p>
                  )}
                </div>

                <div>
                  <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-2">
                    Email
                  </label>
                  <p className="text-sm sm:text-base text-gray-900">{user.email}</p>
                </div>

                <div>
                  <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-2">
                    Teléfono
                  </label>
                  {isEditing ? (
                    <input
                      type="tel"
                      value={editForm.phone}
                      onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                      className="w-full px-2.5 sm:px-3 py-1.5 sm:py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm sm:text-base"
                      placeholder="Opcional"
                    />
                  ) : (
                    <p className="text-sm sm:text-base text-gray-900">{user.phone || 'No especificado'}</p>
                  )}
                </div>
              </div>

              {/* Dietary Preferences */}
              <div>
                <h4 className="text-sm sm:text-base font-semibold text-gray-900 mb-3">Preferencias dietéticas</h4>
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-2">
                      Restricciones dietéticas
                    </label>
                    {isEditing ? (
                      <div className="grid grid-cols-2 gap-1.5 sm:gap-2">
                        {['Vegetariano', 'Vegano', 'Sin gluten', 'Sin lactosa', 'Halal', 'Kosher'].map(diet => (
                          <label key={diet} className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              checked={editForm.dietaryRestrictions.includes(diet)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setEditForm({
                                    ...editForm,
                                    dietaryRestrictions: [...editForm.dietaryRestrictions, diet]
                                  });
                                } else {
                                  setEditForm({
                                    ...editForm,
                                    dietaryRestrictions: editForm.dietaryRestrictions.filter(d => d !== diet)
                                  });
                                }
                              }}
                              className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-orange-600 border-gray-300 rounded focus:ring-orange-500"
                            />
                            <span className="text-xs sm:text-sm text-gray-700">{diet}</span>
                          </label>
                        ))}
                      </div>
                    ) : (
                      <div className="flex flex-wrap gap-2">
                        {user.preferences.dietaryRestrictions.length > 0 ? (
                          user.preferences.dietaryRestrictions.map(diet => (
                            <span key={diet} className="px-2 py-0.5 bg-green-100 text-green-700 rounded-full text-xs">
                              {diet}
                            </span>
                          ))
                        ) : (
                          <p className="text-gray-500 text-sm">Ninguna especificada</p>
                        )}
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-2">
                      Alérgenos a evitar
                    </label>
                    {isEditing ? (
                      <div className="grid grid-cols-2 gap-1.5 sm:gap-2">
                        {['Gluten', 'Lácteos', 'Frutos secos', 'Mariscos', 'Huevos', 'Soja'].map(allergen => (
                          <label key={allergen} className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              checked={editForm.allergens.includes(allergen)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setEditForm({
                                    ...editForm,
                                    allergens: [...editForm.allergens, allergen]
                                  });
                                } else {
                                  setEditForm({
                                    ...editForm,
                                    allergens: editForm.allergens.filter(a => a !== allergen)
                                  });
                                }
                              }}
                              className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-orange-600 border-gray-300 rounded focus:ring-orange-500"
                            />
                            <span className="text-xs sm:text-sm text-gray-700">{allergen}</span>
                          </label>
                        ))}
                      </div>
                    ) : (
                      <div className="flex flex-wrap gap-2">
                        {user.preferences.allergens.length > 0 ? (
                          user.preferences.allergens.map(allergen => (
                            <span key={allergen} className="px-2 py-0.5 bg-red-100 text-red-700 rounded-full text-xs">
                              {allergen}
                            </span>
                          ))
                        ) : (
                          <p className="text-gray-500 text-sm">Ninguno especificado</p>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Saved Tab */}
          {activeTab === 'saved' && (
            <div className="p-4 sm:p-6">
              {/* Saved Sub-tabs */}
              <div className="flex border-b mb-4 sm:mb-6">
                {savedTabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setSavedTab(tab.id)}
                    className={`flex items-center gap-2 px-3 sm:px-4 py-2 sm:py-3 text-xs sm:text-sm font-medium transition-colors ${
                      savedTab === tab.id
                        ? 'text-orange-600 border-b-2 border-orange-600'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    <span className="w-3.5 h-3.5 sm:w-4 sm:h-4">{tab.icon}</span>
                    {tab.label}
                    {tab.count > 0 && (
                      <span className="bg-gray-200 text-gray-700 text-xs font-bold px-1.5 py-0.5 rounded-full">
                        {tab.count}
                      </span>
                    )}
                  </button>
                ))}
              </div>

              {/* Events */}
              {savedTab === 'events' && (
                savedEvents.length > 0 ? (
                  <div className="space-y-3">
                    {savedEvents.map(event => (
                      <div key={event.id} className="border border-gray-200 rounded-lg p-3 sm:p-4 hover:bg-gray-50 transition-colors">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h4 className="font-semibold text-gray-900 text-sm sm:text-base mb-1">{event.name}</h4>
                            <p className="text-xs sm:text-sm text-gray-600 mb-2">{event.restaurant.name}</p>
                            <div className="flex items-center gap-4 text-xxs sm:text-xs text-gray-500">
                              <span className="flex items-center gap-1">
                                <Calendar className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                                {new Date(event.date).toLocaleDateString('es-ES')}
                              </span>
                              <span>{event.time}</span>
                              <span className="flex items-center gap-1">
                                <MapPin className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                                {formatDistance(event.distance)}
                              </span>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <button
                              onClick={() => onViewEvent(event)}
                              className="px-2.5 py-1.5 text-xs bg-orange-600 text-white rounded hover:bg-orange-700 transition-colors"
                            >
                              Ver detalles
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <span className="text-5xl sm:text-6xl mb-4 block">🎪</span>
                    <h4 className="text-base sm:text-lg font-medium text-gray-900 mb-2">No tienes eventos guardados</h4>
                    <p className="text-sm sm:text-base text-gray-600">Guarda eventos que te interesen para acceder a ellos fácilmente</p>
                  </div>
                )
              )}

              {/* Restaurants */}
              {savedTab === 'restaurants' && (
                savedRestaurants.length > 0 ? (
                  <div className="space-y-3">
                    {savedRestaurants.map(restaurant => (
                      <div key={restaurant.id} className="border border-gray-200 rounded-lg p-3 sm:p-4 hover:bg-gray-50 transition-colors">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h4 className="font-semibold text-gray-900 text-sm sm:text-base mb-1">{restaurant.name}</h4>
                            <p className="text-xs sm:text-sm text-gray-600 mb-2">{restaurant.cuisineType} • {restaurant.establishmentType}</p>
                            <div className="flex items-center gap-4 text-xxs sm:text-xs text-gray-500">
                              <span>{getPriceRange(restaurant.priceRange)}</span>
                              <span className="flex items-center gap-1">
                                <MapPin className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                                {formatDistance(restaurant.distance)}
                              </span>
                              <span className={restaurant.isOpen ? 'text-green-600' : 'text-red-600'}>
                                {restaurant.isOpen ? '🟢 Abierto' : '🔴 Cerrado'}
                              </span>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            {onViewRestaurant && (
                              <button
                                onClick={() => onViewRestaurant(restaurant)}
                                className="px-2.5 py-1.5 text-xs bg-orange-600 text-white rounded hover:bg-orange-700 transition-colors"
                              >
                                Ver detalles
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <span className="text-5xl sm:text-6xl mb-4 block">🏪</span>
                    <h4 className="text-base sm:text-lg font-medium text-gray-900 mb-2">No tienes restaurantes guardados</h4>
                    <p className="text-sm sm:text-base text-gray-600">Guarda restaurantes que te gusten para encontrarlos fácilmente</p>
                  </div>
                )
              )}

              {/* Dishes */}
              {savedTab === 'dishes' && (
                savedDishes.length > 0 ? (
                  <div className="space-y-3">
                    {savedDishes.map(dish => (
                      <div key={dish.id} className="border border-gray-200 rounded-lg p-3 sm:p-4 hover:bg-gray-50 transition-colors">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h4 className="font-semibold text-gray-900 text-sm sm:text-base mb-1">
                              {dish.name}
                              {dish.spiceLevel > 0 && (
                                <span className="text-sm ml-1">{'🌶️'.repeat(dish.spiceLevel)}</span>
                              )}
                            </h4>
                            <p className="text-xs sm:text-sm text-gray-600 mb-2">{dish.restaurant.name}</p>
                            <div className="flex items-center gap-4 text-xxs sm:text-xs text-gray-500">
                              <span className="font-medium text-gray-900">€{dish.price.toFixed(2)}</span>
                              {dish.originalPrice && (
                                <span className="line-through">€{dish.originalPrice.toFixed(2)}</span>
                              )}
                              <span className="flex items-center gap-1">
                                <MapPin className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                                {formatDistance(dish.distance)}
                              </span>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            {onViewDish && (
                              <button
                                onClick={() => onViewDish(dish)}
                                className="px-2.5 py-1.5 text-xs bg-orange-600 text-white rounded hover:bg-orange-700 transition-colors"
                              >
                                Ver detalles
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <span className="text-5xl sm:text-6xl mb-4 block">🍽️</span>
                    <h4 className="text-base sm:text-lg font-medium text-gray-900 mb-2">No tienes platos guardados</h4>
                    <p className="text-sm sm:text-base text-gray-600">Guarda platos que te apetezcan para pedirlos más tarde</p>
                  </div>
                )
              )}
            </div>
          )}

          {/* Reservations Tab */}
          {activeTab === 'reservations' && (
            <div className="p-4 sm:p-6">
              <div className="mb-4 sm:mb-6">
                <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-2">Mis Reservas</h3>
                <p className="text-sm text-gray-600">Gestiona tus reservas de restaurantes</p>
                <div className="flex gap-4 mt-2 text-xs text-gray-500">
                  <span>🍽️ {restaurantReservations.length} restaurantes</span>
                  <span>🎪 {eventReservations.length} eventos</span>
                  <span>📋 {userReservations.length} total</span>
                </div>
              </div>

              {userReservations.length > 0 ? (
                <div className="space-y-3">
                  {userReservations.map(reservation => (
                    <div key={reservation.id} className="border border-gray-200 rounded-xl p-4 hover:shadow-md transition-all duration-200 bg-white">
                      <div className="flex items-start gap-3">
                        {/* Type indicator */}
                        <div className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center bg-gray-100 text-sm">
                          {reservation.type === 'restaurant' ? '🍽️' : '🎪'}
                        </div>

                        {/* Restaurant Image */}
                        <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                          {reservation.restaurantImage ? (
                            <img
                              src={reservation.restaurantImage}
                              alt={reservation.restaurantName}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center bg-orange-100">
                              <span className="text-lg">🏪</span>
                            </div>
                          )}
                        </div>

                        {/* Reservation Details */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <h4 className="font-semibold text-gray-900 text-sm sm:text-base truncate">
                                {reservation.type === 'event' ? reservation.eventName : reservation.restaurantName}
                              </h4>
                              {reservation.type === 'event' && (
                                <p className="text-xs text-purple-600 font-medium mb-1">
                                  {reservation.eventType} • {reservation.restaurantName}
                                </p>
                              )}
                              <p className="text-xs sm:text-sm text-gray-600 mb-1">
                                Código: {reservation.confirmationCode}
                              </p>
                            </div>
                            <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(reservation.status)}`}>
                              {getStatusIcon(reservation.status)}
                              <span>{getStatusText(reservation.status)}</span>
                            </div>
                          </div>

                          {/* Date, Time, Guests */}
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mb-2 text-xs sm:text-sm text-gray-500">
                            <div className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              <span>{new Date(reservation.date).toLocaleDateString('es-ES', { 
                                weekday: 'short', 
                                day: 'numeric', 
                                month: 'short' 
                              })}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              <span>{reservation.time}</span>
                              {reservation.type === 'event' && reservation.eventDuration && (
                                <span className="text-gray-400">({reservation.eventDuration})</span>
                              )}
                            </div>
                            <div className="flex items-center gap-1">
                              {reservation.type === 'event' ? (
                                <>
                                  <span className="text-xs">🎫</span>
                                  <span>{reservation.ticketCount || reservation.guests} ticket{(reservation.ticketCount || reservation.guests) !== 1 ? 's' : ''}</span>
                                </>
                              ) : (
                                <>
                                  <Users className="w-3 h-3" />
                                  <span>{reservation.guests} persona{reservation.guests !== 1 ? 's' : ''}</span>
                                </>
                              )}
                            </div>
                          </div>

                          {/* Event Price */}
                          {reservation.type === 'event' && reservation.eventPrice !== undefined && (
                            <div className="mb-2">
                              <span className="text-xs font-medium text-gray-900">
                                {reservation.eventPrice === 0 ? (
                                  <span className="text-green-600">✨ Evento Gratuito</span>
                                ) : (
                                  <span>💰 €{reservation.eventPrice.toFixed(2)} por persona</span>
                                )}
                              </span>
                            </div>
                          )}

                          {/* Special Requests */}
                          {reservation.specialRequests && (
                            <div className="mb-2">
                              <p className="text-xs text-gray-600 bg-blue-50 p-2 rounded">
                                <strong>💬 Solicitudes:</strong> {reservation.specialRequests}
                              </p>
                            </div>
                          )}

                          {/* Actions */}
                          <div className="flex gap-2">
                            <button
                              onClick={() => {
                                setSelectedReservation(reservation);
                                setShowReservationModal(true);
                              }}
                              className="px-3 py-1.5 text-xs bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
                            >
                              Ver detalles
                            </button>
                            <a
                              href={`tel:${reservation.restaurantPhone}`}
                              className="px-3 py-1.5 text-xs bg-green-600 text-white rounded hover:bg-green-700 transition-colors"
                            >
                              Llamar
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <span className="text-5xl sm:text-6xl mb-4 block">📅</span>
                  <h4 className="text-base sm:text-lg font-medium text-gray-900 mb-2">No tienes reservas</h4>
                  <p className="text-sm sm:text-base text-gray-600">Cuando hagas una reserva en un restaurante o evento, aparecerá aquí</p>
                </div>
              )}

              {/* Quick Stats */}
              {userReservations.length > 0 && (
                <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                  <h5 className="font-medium text-gray-900 mb-3 text-sm">Resumen de reservas</h5>
                  <div className="grid grid-cols-2 sm:grid-cols-6 gap-4 text-center">
                    <div>
                      <div className="text-lg font-bold text-orange-600">
                        {restaurantReservations.length}
                      </div>
                      <div className="text-xs text-gray-600">Restaurantes</div>
                    </div>
                    <div>
                      <div className="text-lg font-bold text-purple-600">
                        {eventReservations.length}
                      </div>
                      <div className="text-xs text-gray-600">Eventos</div>
                    </div>
                    <div>
                      <div className="text-lg font-bold text-green-600">
                        {userReservations.filter(r => r.status === 'confirmed').length}
                      </div>
                      <div className="text-xs text-gray-600">Confirmadas</div>
                    </div>
                    <div>
                      <div className="text-lg font-bold text-yellow-600">
                        {userReservations.filter(r => r.status === 'pending').length}
                      </div>
                      <div className="text-xs text-gray-600">Pendientes</div>
                    </div>
                    <div>
                      <div className="text-lg font-bold text-blue-600">
                        {userReservations.filter(r => r.status === 'completed').length}
                      </div>
                      <div className="text-xs text-gray-600">Completadas</div>
                    </div>
                    <div>
                      <div className="text-lg font-bold text-red-600">
                        {userReservations.filter(r => r.status === 'cancelled').length}
                      </div>
                      <div className="text-xs text-gray-600">Canceladas</div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Settings Tab */}
          {activeTab === 'settings' && (
            <div className="p-4 sm:p-6 space-y-4 sm:space-y-6">
              <div>
                <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-4">Notificaciones</h3>
                <div className="space-y-4">
                  <label className="flex items-center justify-between">
                    <div>
                      <span className="text-xs sm:text-sm font-medium text-gray-900">Notificaciones por email</span>
                      <p className="text-xxs sm:text-xs text-gray-500">Recibe recordatorios de eventos por email</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={user.notifications.email}
                      onChange={(e) => onUpdateUser({
                        notifications: { ...user.notifications, email: e.target.checked }
                      })}
                      className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-orange-600 border-gray-300 rounded focus:ring-orange-500"
                    />
                  </label>

                  <label className="flex items-center justify-between">
                    <div>
                      <span className="text-xs sm:text-sm font-medium text-gray-900">Notificaciones push</span>
                      <p className="text-xxs sm:text-xs text-gray-500">Recibe notificaciones en el navegador</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={user.notifications.push}
                      onChange={(e) => onUpdateUser({
                        notifications: { ...user.notifications, push: e.target.checked }
                      })}
                      className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-orange-600 border-gray-300 rounded focus:ring-orange-500"
                    />
                  </label>

                  <label className="flex items-center justify-between">
                    <div>
                      <span className="text-xs sm:text-sm font-medium text-gray-900">Integración con Google Calendar</span>
                      <p className="text-xxs sm:text-xs text-gray-500">Añade eventos automáticamente a tu calendario</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={user.notifications.calendar}
                      onChange={(e) => onUpdateUser({
                        notifications: { ...user.notifications, calendar: e.target.checked }
                      })}
                      className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-orange-600 border-gray-300 rounded focus:ring-orange-500"
                    />
                  </label>
                </div>
              </div>

              <div className="border-t pt-6">
                <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-4">Cuenta</h3>
                <button
                  onClick={onLogout}
                  className="w-full py-2.5 sm:py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-medium text-sm sm:text-base"
                >
                  Cerrar sesión
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>

      <ReservationModal
        isOpen={showReservationModal}
        onClose={() => setShowReservationModal(false)}
        reservation={selectedReservation}
        onModify={handleModifyReservation}
        onCancel={handleCancelReservation}
      />
    </>
  );
};

export default ProfileModal;