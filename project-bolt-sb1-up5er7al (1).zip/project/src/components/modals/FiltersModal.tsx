import React, { useState } from 'react';
import { X, MapPin, Euro, Clock, Star, Building, UtensilsCrossed, Wifi, Filter } from 'lucide-react';
import { Filters, SearchTab } from '../../types';

interface FiltersModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab: SearchTab;
  filters: Filters;
  onFiltersChange: (filters: Filters) => void;
  filterOptions?: {
    establishmentTypes: any[];
    cuisineTypes: any[];
    services: any[];
    dishCategories: any[];
  };
}

const FiltersModal: React.FC<FiltersModalProps> = ({
  isOpen,
  onClose,
  activeTab,
  filters,
  onFiltersChange,
  filterOptions = { establishmentTypes: [], cuisineTypes: [], services: [], dishCategories: [] }
}) => {
  const [localFilters, setLocalFilters] = useState<Filters>(filters);

  if (!isOpen) return null;

  const handleApplyFilters = () => {
    onFiltersChange(localFilters);
    onClose();
  };

  const handleClearFilters = () => {
    const clearedFilters: Filters = {
      location: { radius: 2000 },
      price: [],
      schedule: [],
      rating: 0,
      establishmentType: [],
      cuisineType: [],
      services: [],
      categories: [],
      diets: [],
      allergens: [],
      spiceLevel: [],
      occasion: [],
      scheduleHours: [],
      hasPromotions: false
    };
    setLocalFilters(clearedFilters);
  };

  const updateFilter = (key: string, value: any) => {
    setLocalFilters(prev => ({ ...prev, [key]: value }));
  };

  const toggleArrayFilter = (key: string, value: string) => {
    setLocalFilters(prev => ({
      ...prev,
      [key]: prev[key as keyof Filters].includes(value)
        ? (prev[key as keyof Filters] as string[]).filter(item => item !== value)
        : [...(prev[key as keyof Filters] as string[]), value]
    }));
  };

  const getActiveFiltersCount = () => {
    let count = 0;
    if (localFilters.location.radius !== 2000) count++;
    if (localFilters.price.length > 0) count++;
    if (localFilters.schedule.length > 0) count++;
    if (localFilters.rating > 0) count++;
    if (localFilters.hasPromotions) count++;
    if (localFilters.allergens.length > 0) count++;
    if (localFilters.diets.length > 0) count++;
    if (localFilters.establishmentType.length > 0) count++;
    if (localFilters.cuisineType.length > 0) count++;
    if (localFilters.services.length > 0) count++;
    if (localFilters.categories.length > 0) count++;
    return count;
  };

  const FilterSection: React.FC<{ 
    title: string; 
    icon: React.ReactNode; 
    children: React.ReactNode;
    badge?: number;
  }> = ({ title, icon, children, badge }) => (
    <div className="p-4">
      <div className="flex items-center gap-2 mb-4">
        {icon}
        <span className="font-medium text-gray-900">{title}</span>
        {badge && badge > 0 && (
          <span className="bg-orange-600 text-white text-xs font-bold px-2 py-1 rounded-full">
            {badge}
          </span>
        )}
      </div>
      {children}
    </div>
  );

  const CheckboxGroup: React.FC<{ 
    options: string[]; 
    selected: string[]; 
    onChange: (value: string) => void;
    columns?: number;
  }> = ({ options, selected, onChange, columns = 1 }) => (
    <div className={`grid gap-3 ${columns === 2 ? 'grid-cols-2' : 'grid-cols-1'}`}>
      {options.map(option => (
        <label key={option} className="flex items-center gap-3 cursor-pointer group">
          <input
            type="checkbox"
            checked={selected.includes(option)}
            onChange={() => onChange(option)}
            className="w-4 h-4 text-orange-600 border-gray-300 rounded focus:ring-orange-500 focus:ring-2"
          />
          <span className="text-sm text-gray-700 group-hover:text-gray-900 transition-colors">
            {option}
          </span>
        </label>
      ))}
    </div>
  );

  const RadioGroup: React.FC<{ 
    options: { value: any; label: string }[]; 
    selected: any; 
    onChange: (value: any) => void;
    name: string;
  }> = ({ options, selected, onChange, name }) => (
    <div className="space-y-3">
      {options.map(option => (
        <label key={option.value} className="flex items-center gap-3 cursor-pointer group">
          <input
            type="radio"
            name={name}
            checked={selected === option.value}
            onChange={() => onChange(option.value)}
            className="w-4 h-4 text-orange-600 border-gray-300 focus:ring-orange-500 focus:ring-2"
          />
          <span className="text-sm text-gray-700 group-hover:text-gray-900 transition-colors">
            {option.label}
          </span>
        </label>
      ))}
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-3xl w-full max-h-[90vh] overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b bg-gradient-to-r from-orange-50 to-blue-50">
          <div className="flex items-center gap-3">
            <Filter className="w-6 h-6 text-orange-600" />
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Filtros de búsqueda</h2>
              <p className="text-sm text-gray-600">
                Personaliza tu búsqueda para encontrar exactamente lo que buscas
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white hover:bg-opacity-50 rounded-lg transition-colors"
          >
            <X className="w-6 h-6 text-gray-600" />
          </button>
        </div>

        <div className="overflow-y-auto max-h-[calc(90vh-200px)] p-6">
          <div className="space-y-6">
            {/* Essential Filters - Common to all tabs */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <FilterSection 
                title="Ubicación" 
                icon={<MapPin className="w-5 h-5 text-blue-600" />}
                badge={localFilters.location.radius !== 2000 ? 1 : 0}
              >
                <RadioGroup
                  options={[
                    { value: 500, label: '500m - Muy cerca' },
                    { value: 1000, label: '1km - Caminando' },
                    { value: 2000, label: '2km - En bicicleta' },
                    { value: 5000, label: '5km - En transporte' },
                    { value: 10000, label: '10km - En coche' },
                    { value: 999999, label: 'Sin límite' }
                  ]}
                  selected={localFilters.location.radius}
                  onChange={(value) => updateFilter('location', { ...localFilters.location, radius: value })}
                  name="location"
                />
              </FilterSection>

              {/* Price filter - only for restaurants and dishes */}
              {(activeTab === 'restaurants' || activeTab === 'dishes') && (
                <FilterSection 
                  title="Precio" 
                  icon={<Euro className="w-5 h-5 text-green-600" />}
                  badge={localFilters.price.length}
                >
                  <CheckboxGroup
                    options={['€ (< 10€)', '€€ (10-20€)', '€€€ (20-35€)', '€€€€ (> 35€)']}
                    selected={localFilters.price.map(p => 
                      p === 1 ? '€ (< 10€)' :
                      p === 2 ? '€€ (10-20€)' :
                      p === 3 ? '€€€ (20-35€)' : '€€€€ (> 35€)'
                    )}
                    onChange={(value) => {
                      const priceValue = 
                        value === '€ (< 10€)' ? 1 :
                        value === '€€ (10-20€)' ? 2 :
                        value === '€€€ (20-35€)' ? 3 : 4;
                      
                      const newPrice = localFilters.price.includes(priceValue)
                        ? localFilters.price.filter(p => p !== priceValue)
                        : [...localFilters.price, priceValue];
                      updateFilter('price', newPrice);
                    }}
                  />
                </FilterSection>
              )}

              {/* Rating filter - only for restaurants */}
              {activeTab === 'restaurants' && (
                <FilterSection 
                  title="Valoración" 
                  icon={<Star className="w-5 h-5 text-yellow-500" />}
                  badge={localFilters.rating > 0 ? 1 : 0}
                >
                  <RadioGroup
                    options={[
                      { value: 0, label: '⭐ Cualquier valoración' },
                      { value: 4, label: '⭐⭐⭐⭐ 4+ estrellas' },
                      { value: 4.5, label: '⭐⭐⭐⭐⭐ 4.5+ estrellas' }
                    ]}
                    selected={localFilters.rating}
                    onChange={(value) => updateFilter('rating', value)}
                    name="rating"
                  />
                </FilterSection>
              )}
            </div>

            {/* Schedule filter - only for restaurants */}
            {activeTab === 'restaurants' && (
              <FilterSection 
                title="Horario" 
                icon={<Clock className="w-5 h-5 text-purple-600" />}
                badge={localFilters.schedule.length}
              >
                <CheckboxGroup
                  options={[
                    'Abierto ahora', 'Desayuno (8-12h)', 'Comida (12-16h)',
                    'Merienda (16-20h)', 'Cena (20-24h)', 'Fines de semana',
                    'Abierto 24 horas'
                  ]}
                  selected={localFilters.schedule}
                  onChange={(value) => toggleArrayFilter('schedule', value)}
                />
              </FilterSection>
            )}

            {/* Promotions filter - for restaurants and dishes */}
            {(activeTab === 'restaurants' || activeTab === 'dishes') && (
              <FilterSection 
                title="Promociones" 
                icon={<span className="w-5 h-5 text-red-600">🎯</span>}
                badge={localFilters.promoType.length + (localFilters.hasPromotions ? 1 : 0)}
              >
                <div className="space-y-3">
                  {/* General promotions toggle */}
                  <label className="flex items-center gap-3 cursor-pointer group">
                    <input
                      type="checkbox"
                      checked={localFilters.hasPromotions}
                      onChange={(e) => updateFilter('hasPromotions', e.target.checked)}
                      className="w-4 h-4 text-orange-600 border-gray-300 rounded focus:ring-orange-500 focus:ring-2"
                    />
                    <span className="text-sm text-gray-700 group-hover:text-gray-900 transition-colors">
                      Solo con promociones activas
                    </span>
                  </label>

                  {/* Promotion types */}
                  <div className="border-t pt-3">
                    <h4 className="text-xs font-medium text-gray-600 mb-2 uppercase tracking-wide">Tipos específicos</h4>
                    <CheckboxGroup
                      options={[
                        '2x1', 'Happy Hour', 'Descuento estudiantes', 
                        'Menú del día', 'Descuento grupos', 'Primera consumición gratis'
                      ]}
                      selected={localFilters.promoType}
                      onChange={(value) => toggleArrayFilter('promoType', value)}
                    />
                  </div>
                </div>
              </FilterSection>
            )}

            {/* Diet and allergen filters - only for restaurants and dishes */}
            {(activeTab === 'restaurants' || activeTab === 'dishes') && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <FilterSection 
                  title="Alérgenos a evitar" 
                  icon={<span className="w-5 h-5 text-red-600">⚠️</span>}
                  badge={localFilters.allergens.length}
                >
                  <CheckboxGroup
                    options={[
                      'Gluten', 'Lácteos', 'Huevos', 'Frutos secos', 'Cacahuetes', 
                      'Soja', 'Pescado', 'Mariscos', 'Apio', 'Mostaza', 'Sésamo', 'Sulfitos'
                    ]}
                    selected={localFilters.allergens}
                    onChange={(value) => toggleArrayFilter('allergens', value)}
                    columns={2}
                  />
                </FilterSection>

                <FilterSection 
                  title="Tipo de dieta" 
                  icon={<span className="w-5 h-5 text-green-600">🌱</span>}
                  badge={localFilters.diets.length}
                >
                  <CheckboxGroup
                    options={[
                      'Vegetariano', 'Vegano', 'Sin gluten', 'Sin lactosa', 'Keto/Low carb', 
                      'Halal', 'Kosher', 'Paleo', 'Sin azúcar', 'Diabéticos', 'Orgánico/Eco'
                    ]}
                    selected={localFilters.diets}
                    onChange={(value) => toggleArrayFilter('diets', value)}
                    columns={2}
                  />
                </FilterSection>
              </div>
            )}
            {/* Restaurant-specific Filters */}
            {activeTab === 'restaurants' && (
              <>
                <FilterSection 
                  title="Tipo de establecimiento" 
                  icon={<Building className="w-5 h-5 text-gray-600" />}
                  badge={localFilters.establishmentType.length}
                >
                  <CheckboxGroup
                    options={filterOptions.establishmentTypes.map(type => type.name)}
                    selected={localFilters.establishmentType}
                    onChange={(value) => toggleArrayFilter('establishmentType', value)}
                    columns={2}
                  />
                </FilterSection>

                <FilterSection 
                  title="Tipo de cocina" 
                  icon={<UtensilsCrossed className="w-5 h-5 text-orange-600" />}
                  badge={localFilters.cuisineType.length}
                >
                  <CheckboxGroup
                    options={filterOptions.cuisineTypes.map(type => type.name)}
                    selected={localFilters.cuisineType}
                    onChange={(value) => toggleArrayFilter('cuisineType', value)}
                    columns={2}
                  />
                </FilterSection>

                <FilterSection 
                  title="Servicios" 
                  icon={<Wifi className="w-5 h-5 text-blue-600" />}
                  badge={localFilters.services.length}
                >
                  <CheckboxGroup
                    options={filterOptions.services.map(service => service.name)}
                    selected={localFilters.services}
                    onChange={(value) => toggleArrayFilter('services', value)}
                    columns={2}
                  />
                </FilterSection>
              </>
            )}

            {/* Dish-specific Filters */}
            {activeTab === 'dishes' && (
              <FilterSection 
                title="Categoría de plato" 
                icon={<UtensilsCrossed className="w-5 h-5 text-orange-600" />}
                badge={localFilters.categories.length}
              >
                <CheckboxGroup
                  options={filterOptions.dishCategories.map(category => category.name)}
                  selected={localFilters.categories}
                  onChange={(value) => toggleArrayFilter('categories', value)}
                  columns={2}
                />
              </FilterSection>
            )}

            {/* Events-specific Filters */}
            {activeTab === 'events' && (
              <>
                <FilterSection 
                  title="Tipo de evento" 
                  icon={<span className="w-5 h-5 text-purple-600">🎪</span>}
                  badge={localFilters.eventType.length}
                >
                  <CheckboxGroup
                    options={[
                      'Deportivo', 'Música en vivo', 'Espectáculo', 'Social', 'Gastronómico', 'Cata', 
                      'Taller', 'Degustación', 'Masterclass', 'Temático', 'Familiar', 'Nocturno', 
                      'Brunch', 'Cena-show', 'Karaoke'
                    ]}
                    selected={localFilters.eventType}
                    onChange={(value) => toggleArrayFilter('eventType', value)}
                    columns={2}
                  />
                </FilterSection>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <FilterSection 
                    title="Reserva" 
                    icon={<span className="w-5 h-5 text-blue-600">📅</span>}
                    badge={localFilters.requiresReservation !== null ? 1 : 0}
                  >
                    <RadioGroup
                      options={[
                        { value: null, label: 'Cualquier tipo' },
                        { value: true, label: 'Con reserva obligatoria' },
                        { value: false, label: 'Sin reserva necesaria' }
                      ]}
                      selected={localFilters.requiresReservation}
                      onChange={(value) => updateFilter('requiresReservation', value)}
                      name="reservation"
                    />
                  </FilterSection>

                  <FilterSection 
                    title="Precio del evento" 
                    icon={<span className="w-5 h-5 text-green-600">💰</span>}
                    badge={localFilters.isFree !== null ? 1 : 0}
                  >
                    <RadioGroup
                      options={[
                        { value: null, label: 'Cualquier precio' },
                        { value: true, label: 'Solo eventos gratuitos' },
                        { value: false, label: 'Solo eventos de pago' }
                      ]}
                      selected={localFilters.isFree}
                      onChange={(value) => updateFilter('isFree', value)}
                      name="eventPrice"
                    />
                  </FilterSection>
                  </div>

                <FilterSection 
                  title="Fecha del evento" 
                  icon={<span className="w-5 h-5 text-orange-600">📅</span>}
                  badge={localFilters.dateRange.length}
                >
                  <CheckboxGroup
                    options={[
                      'Hoy', 'Mañana', 'Este fin de semana', 'Esta semana', 'Próxima semana', 'Este mes', 'Próximo mes'
                    ]}
                    selected={localFilters.dateRange}
                    onChange={(value) => toggleArrayFilter('dateRange', value)}
                    columns={2}
                  />
                </FilterSection>

                <FilterSection 
                  title="Horario del evento" 
                  icon={<span className="w-5 h-5 text-indigo-600">🕐</span>}
                  badge={localFilters.timeSlots.length}
                >
                  <CheckboxGroup
                    options={[
                      'Mañana (8-12h)', 'Mediodía (12-16h)', 'Tarde (16-20h)', 'Noche (20-24h)', 'Madrugada (0-6h)'
                    ]}
                    selected={localFilters.timeSlots}
                    onChange={(value) => toggleArrayFilter('timeSlots', value)}
                  />
                </FilterSection>
              </>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between p-6 border-t bg-gray-50">
          <div className="flex items-center gap-4">
            <button
              onClick={handleClearFilters}
              className="px-4 py-2 text-gray-600 hover:text-gray-800 font-medium transition-colors"
            >
              Limpiar filtros
            </button>
            {getActiveFiltersCount() > 0 && (
              <span className="text-sm text-gray-500">
                {getActiveFiltersCount()} filtro{getActiveFiltersCount() !== 1 ? 's' : ''} activo{getActiveFiltersCount() !== 1 ? 's' : ''}
              </span>
            )}
          </div>
          <div className="flex gap-3">
            <button
              onClick={onClose}
              className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
            >
              Cancelar
            </button>
            <button
              onClick={handleApplyFilters}
              className="px-6 py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors font-medium shadow-sm"
            >
              Aplicar filtros
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FiltersModal;