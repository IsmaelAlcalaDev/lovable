import React, { useState } from 'react';
import { X, Calendar, Clock, Users, Edit, AlertTriangle, CheckCircle } from 'lucide-react';
import { Reservation } from '../../types';

interface ReservationModalProps {
  isOpen: boolean;
  onClose: () => void;
  reservation: Reservation | null;
  onModify: (reservationId: string, newData: { date: string; time: string; guests: number; specialRequests?: string }) => void;
  onCancel: (reservationId: string) => void;
}

const ReservationModal: React.FC<ReservationModalProps> = ({
  isOpen,
  onClose,
  reservation,
  onModify,
  onCancel
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    date: '',
    time: '',
    guests: 1,
    specialRequests: ''
  });

  // Initialize form when reservation changes
  React.useEffect(() => {
    if (reservation) {
      setEditForm({
        date: reservation.date,
        time: reservation.time,
        guests: reservation.guests,
        specialRequests: reservation.specialRequests || ''
      });
    }
  }, [reservation]);

  if (!isOpen || !reservation) return null;

  // Check if reservation can be cancelled (2 hours before)
  const canCancel = () => {
    const reservationDateTime = new Date(`${reservation.date}T${reservation.time}`);
    const now = new Date();
    const hoursUntilReservation = (reservationDateTime.getTime() - now.getTime()) / (1000 * 60 * 60);
    return hoursUntilReservation >= 2 && (reservation.status === 'confirmed' || reservation.status === 'pending');
  };

  // Check if reservation can be modified
  const canModify = () => {
    const reservationDateTime = new Date(`${reservation.date}T${reservation.time}`);
    const now = new Date();
    const hoursUntilReservation = (reservationDateTime.getTime() - now.getTime()) / (1000 * 60 * 60);
    return hoursUntilReservation >= 4 && (reservation.status === 'confirmed' || reservation.status === 'pending');
  };

  const handleSave = () => {
    onModify(reservation.id, editForm);
    setIsEditing(false);
  };

  const handleCancel = () => {
    if (canCancel()) {
      onCancel(reservation.id);
      onClose();
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'text-green-600 bg-green-50 border-green-200';
      case 'pending':
        return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'cancelled':
        return 'text-red-600 bg-red-50 border-red-200';
      case 'completed':
        return 'text-blue-600 bg-blue-50 border-blue-200';
      default:
        return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'confirmed': return 'Confirmada';
      case 'pending': return 'Pendiente';
      case 'cancelled': return 'Cancelada';
      case 'completed': return 'Completada';
      default: return status;
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[95vh] overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b bg-gradient-to-r from-blue-50 to-purple-50">
          <div className="flex items-center gap-3">
            <Calendar className="w-6 h-6 text-blue-600" />
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Detalles de la Reserva</h2>
              <p className="text-sm text-gray-600">Código: {reservation.confirmationCode}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white hover:bg-opacity-50 rounded-lg transition-colors"
          >
            <X className="w-6 h-6 text-gray-600" />
          </button>
        </div>

        <div className="overflow-y-auto max-h-[calc(95vh-200px)]">
          {/* Restaurant Info */}
          <div className="p-6 border-b">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gray-100 rounded-xl overflow-hidden">
                {reservation.restaurantImage ? (
                  <img
                    src={reservation.restaurantImage}
                    alt={reservation.restaurantName}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-orange-100">
                    <span className="text-2xl">🏪</span>
                  </div>
                )}
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-gray-900">{reservation.restaurantName}</h3>
                <p className="text-sm text-gray-600 mb-2">{reservation.restaurantAddress}</p>
                <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(reservation.status)}`}>
                  {getStatusText(reservation.status)}
                </div>
              </div>
            </div>
          </div>

          {/* Reservation Details */}
          <div className="p-6 space-y-6">
            {isEditing ? (
              <div className="space-y-4">
                <h4 className="font-semibold text-gray-900">Modificar Reserva</h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Fecha
                    </label>
                    <input
                      type="date"
                      value={editForm.date}
                      onChange={(e) => setEditForm({ ...editForm, date: e.target.value })}
                      min={new Date().toISOString().split('T')[0]}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Hora
                    </label>
                    <input
                      type="time"
                      value={editForm.time}
                      onChange={(e) => setEditForm({ ...editForm, time: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Número de comensales
                    </label>
                    <select
                      value={editForm.guests}
                      onChange={(e) => setEditForm({ ...editForm, guests: parseInt(e.target.value) })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(num => (
                        <option key={num} value={num}>{num} persona{num !== 1 ? 's' : ''}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Solicitudes especiales
                  </label>
                  <textarea
                    value={editForm.specialRequests}
                    onChange={(e) => setEditForm({ ...editForm, specialRequests: e.target.value })}
                    placeholder="Alergias, celebraciones, preferencias de mesa..."
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setIsEditing(false)}
                    className="flex-1 py-2 px-4 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    Cancelar
                  </button>
                  <button
                    onClick={handleSave}
                    className="flex-1 py-2 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    Guardar Cambios
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                    <Calendar className="w-5 h-5 text-gray-600" />
                    <div>
                      <div className="text-sm font-medium text-gray-900">
                        {new Date(reservation.date).toLocaleDateString('es-ES', { 
                          weekday: 'long', 
                          year: 'numeric', 
                          month: 'long', 
                          day: 'numeric' 
                        })}
                      </div>
                      <div className="text-xs text-gray-500">Fecha</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                    <Clock className="w-5 h-5 text-gray-600" />
                    <div>
                      <div className="text-sm font-medium text-gray-900">{reservation.time}</div>
                      {reservation.type === 'event' && reservation.eventDuration && (
                        <div className="text-xs text-gray-500">Duración: {reservation.eventDuration}</div>
                      )}
                      <div className="text-xs text-gray-500">Hora</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                    {reservation.type === 'event' ? (
                      <span className="text-lg">🎫</span>
                    ) : (
                      <Users className="w-5 h-5 text-gray-600" />
                    )}
                    <div>
                      <div className="text-sm font-medium text-gray-900">
                        {reservation.type === 'event' ? (
                          `${reservation.ticketCount || reservation.guests} ticket${(reservation.ticketCount || reservation.guests) !== 1 ? 's' : ''}`
                        ) : (
                          `${reservation.guests} persona${reservation.guests !== 1 ? 's' : ''}`
                        )}
                      </div>
                      <div className="text-xs text-gray-500">
                        {reservation.type === 'event' ? 'Entradas' : 'Comensales'}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Event Price */}
                {reservation.type === 'event' && reservation.eventPrice !== undefined && (
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h5 className="font-medium text-purple-900 mb-2">Precio del Evento</h5>
                    <div className="text-sm text-purple-700">
                      {reservation.eventPrice === 0 ? (
                        <span className="font-semibold text-green-600">✨ Evento Gratuito</span>
                      ) : (
                        <span>💰 €{reservation.eventPrice.toFixed(2)} por persona</span>
                      )}
                      {reservation.eventPrice > 0 && reservation.ticketCount && (
                        <span className="block text-xs mt-1">
                          Total: €{(reservation.eventPrice * reservation.ticketCount).toFixed(2)} ({reservation.ticketCount} tickets)
                        </span>
                      )}
                    </div>
                  </div>
                )}

                {reservation.specialRequests && (
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h5 className="font-medium text-blue-900 mb-2">Solicitudes Especiales</h5>
                    <p className="text-sm text-blue-700">{reservation.specialRequests}</p>
                  </div>
                )}

                <div className="p-4 bg-gray-50 rounded-lg">
                  <h5 className="font-medium text-gray-900 mb-2">
                    {reservation.type === 'event' ? 'Información del Evento' : 'Información del Restaurante'}
                  </h5>
                  <div className="space-y-2 text-sm text-gray-600">
                    {reservation.type === 'event' && (
                      <p><strong>Evento:</strong> {reservation.eventName}</p>
                    )}
                    <p><strong>Dirección:</strong> {reservation.restaurantAddress}</p>
                    <p><strong>Teléfono:</strong> {reservation.restaurantPhone}</p>
                    <p><strong>Reserva realizada:</strong> {new Date(reservation.createdAt).toLocaleDateString('es-ES')}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Action Restrictions Info */}
            <div className="space-y-3">
              {!canModify() && reservation.status !== 'cancelled' && reservation.status !== 'completed' && (
                <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-yellow-600 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-yellow-900">Modificación no disponible</p>
                      <p className="text-xs text-yellow-700 mt-1">
                        Solo se puede modificar hasta 4 horas antes de la reserva
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {!canCancel() && reservation.status !== 'cancelled' && reservation.status !== 'completed' && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-600 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-red-900">Cancelación no disponible</p>
                      <p className="text-xs text-red-700 mt-1">
                        Solo se puede cancelar hasta 2 horas antes de la reserva
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex gap-3 p-6 border-t bg-gray-50">
          <a
            href={`tel:${reservation.restaurantPhone}`}
            className="flex-1 py-3 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-center font-medium"
          >
            Llamar al restaurante
          </a>
          
          {canModify() && !isEditing && (
            <button
              onClick={() => setIsEditing(true)}
              className="flex-1 py-3 px-4 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
            >
              Modificar
            </button>
          )}
          
          {canCancel() && (
            <button
              onClick={handleCancel}
              className="flex-1 py-3 px-4 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-medium"
            >
              Cancelar Reserva
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ReservationModal;