import React, { useState } from 'react';
import { X, CheckCircle, AlertTriangle, AlertCircle, FileText, Shield, Crown } from 'lucide-react';

interface RestaurantRegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: 'register' | 'claim';
}

const RestaurantRegistrationModal: React.FC<RestaurantRegistrationModalProps> = ({
  isOpen,
  onClose,
  mode
}) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedPlan, setSelectedPlan] = useState<'basic' | 'premium'>('basic');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleNext = () => {
    if (currentStep < 7) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsSubmitting(false);
    onClose();
  };

  const renderPlanBenefits = () => {
    if (currentStep !== 2) return null;

    return (
      <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-60 p-4">
        <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden shadow-2xl">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-xl font-bold text-gray-900">Comparación de Planes</h3>
          </div>
          
          <div className="p-6 overflow-y-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Basic Plan */}
              <div className={`border-2 rounded-lg p-6 ${selectedPlan === 'basic' ? 'border-orange-500 bg-orange-50' : 'border-gray-200'}`}>
                <h4 className="text-lg font-bold text-gray-900 mb-2">Plan Básico</h4>
                <p className="text-2xl font-bold text-orange-500 mb-4">Gratis</p>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li>• Perfil básico del restaurante</li>
                  <li>• Hasta 10 fotos</li>
                  <li>• Información de contacto</li>
                  <li>• Horarios de apertura</li>
                  <li>• Verificación estándar (24-48h)</li>
                </ul>
                <button
                  onClick={() => setSelectedPlan('basic')}
                  className={`w-full mt-4 py-2 px-4 rounded-lg transition-colors ${
                    selectedPlan === 'basic' 
                      ? 'bg-orange-500 text-white' 
                      : 'border border-orange-500 text-orange-500 hover:bg-orange-50'
                  }`}
                >
                  Seleccionar Básico
                </button>
              </div>

              {/* Premium Plan */}
              <div className={`border-2 rounded-lg p-6 relative ${selectedPlan === 'premium' ? 'border-orange-500 bg-orange-50' : 'border-gray-200'}`}>
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <span className="bg-orange-500 text-white px-3 py-1 rounded-full text-xs font-medium">
                    Recomendado
                  </span>
                </div>
                <h4 className="text-lg font-bold text-gray-900 mb-2 flex items-center">
                  <Crown className="w-5 h-5 text-orange-500 mr-2" />
                  Plan Premium
                </h4>
                <p className="text-2xl font-bold text-orange-500 mb-4">€29/mes</p>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li>• Todo lo del plan básico</li>
                  <li>• Fotos ilimitadas</li>
                  <li>• Menú digital completo</li>
                  <li>• Estadísticas avanzadas</li>
                  <li>• Verificación prioritaria (12-24h)</li>
                  <li>• Soporte dedicado</li>
                  <li>• Posición destacada</li>
                </ul>
                <button
                  onClick={() => setSelectedPlan('premium')}
                  className={`w-full mt-4 py-2 px-4 rounded-lg transition-colors ${
                    selectedPlan === 'premium' 
                      ? 'bg-orange-500 text-white' 
                      : 'border border-orange-500 text-orange-500 hover:bg-orange-50'
                  }`}
                >
                  Seleccionar Premium
                </button>
              </div>
            </div>
          </div>

          <div className="flex justify-end p-6 border-t border-gray-200 bg-gray-50">
            <button
              onClick={() => setCurrentStep(3)}
              className="px-6 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
            >
              Continuar
            </button>
          </div>
        </div>
      </div>
    );
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileText className="w-8 h-8 text-orange-500" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">
                {mode === 'register' ? 'Información básica' : 'Verificar propiedad'}
              </h3>
              <p className="text-gray-600">
                {mode === 'register' 
                  ? 'Comencemos con los datos básicos de tu restaurante'
                  : 'Confirma que eres el propietario de este restaurante'
                }
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nombre del restaurante *
                </label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  placeholder="Ej: La Paella Dorada"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Tipo de cocina *
                </label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent">
                  <option value="">Selecciona el tipo</option>
                  <option value="española">Española</option>
                  <option value="italiana">Italiana</option>
                  <option value="japonesa">Japonesa</option>
                  <option value="mexicana">Mexicana</option>
                  <option value="china">China</option>
                  <option value="india">India</option>
                  <option value="francesa">Francesa</option>
                  <option value="mediterranea">Mediterránea</option>
                  <option value="fusion">Fusión</option>
                  <option value="vegetariana">Vegetariana</option>
                  <option value="vegana">Vegana</option>
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Dirección completa *
                </label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  placeholder="Calle, número, código postal, ciudad"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Teléfono *
                </label>
                <input
                  type="tel"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  placeholder="+34 XXX XXX XXX"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email de contacto *
                </label>
                <input
                  type="email"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  placeholder="contacto@restaurante.com"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Descripción breve
                </label>
                <textarea
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  placeholder="Describe tu restaurante en pocas palabras..."
                />
              </div>
            </div>

            {mode === 'claim' && (
              <div className="mt-6 p-4 bg-orange-50 border border-orange-200 rounded-lg">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-orange-900 mb-1">Reclamando este restaurante</h4>
                    <p className="text-sm text-orange-700">
                      Al reclamar este restaurante, confirmas que eres el propietario o tienes autorización 
                      para gestionarlo. Necesitaremos verificar tu identidad y propiedad.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <Crown className="w-16 h-16 text-orange-500 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Elige tu plan</h3>
              <p className="text-gray-600">Selecciona el plan que mejor se adapte a tus necesidades</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Basic Plan Card */}
              <div className={`border-2 rounded-lg p-6 cursor-pointer transition-all ${
                selectedPlan === 'basic' ? 'border-orange-500 bg-orange-50' : 'border-gray-200 hover:border-gray-300'
              }`} onClick={() => setSelectedPlan('basic')}>
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-lg font-bold text-gray-900">Plan Básico</h4>
                  <div className={`w-4 h-4 rounded-full border-2 ${
                    selectedPlan === 'basic' ? 'border-orange-500 bg-orange-500' : 'border-gray-300'
                  }`}>
                    {selectedPlan === 'basic' && <div className="w-2 h-2 bg-white rounded-full m-0.5" />}
                  </div>
                </div>
                <p className="text-3xl font-bold text-orange-500 mb-4">Gratis</p>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    Perfil básico del restaurante
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    Hasta 10 fotos
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    Información de contacto
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    Horarios de apertura
                  </li>
                </ul>
              </div>

              {/* Premium Plan Card */}
              <div className={`border-2 rounded-lg p-6 cursor-pointer transition-all relative ${
                selectedPlan === 'premium' ? 'border-orange-500 bg-orange-50' : 'border-gray-200 hover:border-gray-300'
              }`} onClick={() => setSelectedPlan('premium')}>
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <span className="bg-orange-500 text-white px-3 py-1 rounded-full text-xs font-medium">
                    Recomendado
                  </span>
                </div>
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-lg font-bold text-gray-900 flex items-center">
                    <Crown className="w-5 h-5 text-orange-500 mr-2" />
                    Plan Premium
                  </h4>
                  <div className={`w-4 h-4 rounded-full border-2 ${
                    selectedPlan === 'premium' ? 'border-orange-500 bg-orange-500' : 'border-gray-300'
                  }`}>
                    {selectedPlan === 'premium' && <div className="w-2 h-2 bg-white rounded-full m-0.5" />}
                  </div>
                </div>
                <p className="text-3xl font-bold text-orange-500 mb-4">€29/mes</p>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    Todo lo del plan básico
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    Fotos ilimitadas
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    Menú digital completo
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    Estadísticas avanzadas
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    Verificación prioritaria
                  </li>
                </ul>
              </div>
            </div>

            <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <h5 className="font-medium text-blue-900 mb-2">¿Por qué elegir Premium?</h5>
              <p className="text-sm text-blue-700">
                Los restaurantes Premium obtienen 3x más visibilidad, verificación más rápida y herramientas 
                avanzadas para gestionar su presencia online. Puedes cambiar de plan en cualquier momento.
              </p>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <FileText className="w-16 h-16 text-orange-500 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Horarios y servicios</h3>
              <p className="text-gray-600">Configura cuándo está abierto tu restaurante</p>
            </div>

            <div className="space-y-4">
              <h4 className="font-medium text-gray-900">Horarios de apertura</h4>
              
              {['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'].map((day) => (
                <div key={day} className="flex items-center space-x-4 p-3 border border-gray-200 rounded-lg">
                  <div className="w-20">
                    <span className="text-sm font-medium text-gray-700">{day}</span>
                  </div>
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" defaultChecked={day !== 'Domingo'} />
                    <span className="text-sm text-gray-600">Abierto</span>
                  </label>
                  <div className="flex items-center space-x-2">
                    <input
                      type="time"
                      defaultValue="12:00"
                      className="px-2 py-1 border border-gray-300 rounded text-sm"
                    />
                    <span className="text-gray-500">-</span>
                    <input
                      type="time"
                      defaultValue="16:00"
                      className="px-2 py-1 border border-gray-300 rounded text-sm"
                    />
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="time"
                      defaultValue="20:00"
                      className="px-2 py-1 border border-gray-300 rounded text-sm"
                    />
                    <span className="text-gray-500">-</span>
                    <input
                      type="time"
                      defaultValue="23:30"
                      className="px-2 py-1 border border-gray-300 rounded text-sm"
                    />
                  </div>
                </div>
              ))}
            </div>

            <div className="space-y-4">
              <h4 className="font-medium text-gray-900">Servicios disponibles</h4>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {[
                  'Comida para llevar',
                  'Entrega a domicilio',
                  'Reservas online',
                  'Terraza',
                  'Parking',
                  'WiFi gratuito',
                  'Acceso para discapacitados',
                  'Acepta tarjetas',
                  'Menú infantil'
                ].map((service) => (
                  <label key={service} className="flex items-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                    <input type="checkbox" className="mr-3" />
                    <span className="text-sm text-gray-700">{service}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <FileText className="w-16 h-16 text-orange-500 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Fotos del restaurante</h3>
              <p className="text-gray-600">Las fotos son clave para atraer clientes</p>
            </div>

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Foto principal del restaurante *
                </label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-orange-500 transition-colors cursor-pointer">
                  <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 mb-2">Arrastra tu foto principal aquí o haz clic para seleccionar</p>
                  <p className="text-xs text-gray-500">JPG, PNG hasta 5MB</p>
                  <input type="file" className="hidden" accept="image/*" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Galería de fotos ({selectedPlan === 'premium' ? 'Ilimitadas' : 'Hasta 10'})
                </label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {Array.from({ length: selectedPlan === 'premium' ? 6 : 4 }, (_, i) => (
                    <div key={i} className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-orange-500 transition-colors cursor-pointer aspect-square flex items-center justify-center">
                      <div>
                        <FileText className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                        <p className="text-xs text-gray-500">Foto {i + 1}</p>
                      </div>
                      <input type="file" className="hidden" accept="image/*" />
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h5 className="font-medium text-blue-900 mb-2">Consejos para mejores fotos</h5>
                <ul className="text-sm text-blue-700 space-y-1">
                  <li>• Usa buena iluminación natural</li>
                  <li>• Muestra el ambiente del restaurante</li>
                  <li>• Incluye fotos de tus platos más populares</li>
                  <li>• Evita fotos borrosas o muy oscuras</li>
                </ul>
              </div>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <FileText className="w-16 h-16 text-orange-500 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Menú y precios</h3>
              <p className="text-gray-600">
                {selectedPlan === 'premium' ? 'Crea tu menú digital completo' : 'Añade algunos platos destacados'}
              </p>
            </div>

            <div className="space-y-6">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-medium text-gray-900">Platos destacados</h4>
                  <button className="text-orange-500 hover:text-orange-600 text-sm font-medium">
                    + Añadir plato
                  </button>
                </div>

                <div className="space-y-4">
                  {Array.from({ length: selectedPlan === 'premium' ? 5 : 3 }, (_, i) => (
                    <div key={i} className="border border-gray-200 rounded-lg p-4">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <label className="block text-xs font-medium text-gray-700 mb-1">
                            Nombre del plato
                          </label>
                          <input
                            type="text"
                            className="w-full px-3 py-2 border border-gray-300 rounded text-sm"
                            placeholder="Ej: Paella Valenciana"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-gray-700 mb-1">
                            Precio
                          </label>
                          <input
                            type="number"
                            step="0.01"
                            className="w-full px-3 py-2 border border-gray-300 rounded text-sm"
                            placeholder="0.00"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-gray-700 mb-1">
                            Categoría
                          </label>
                          <select className="w-full px-3 py-2 border border-gray-300 rounded text-sm">
                            <option value="">Seleccionar</option>
                            <option value="entrantes">Entrantes</option>
                            <option value="principales">Principales</option>
                            <option value="postres">Postres</option>
                            <option value="bebidas">Bebidas</option>
                          </select>
                        </div>
                      </div>
                      <div className="mt-3">
                        <label className="block text-xs font-medium text-gray-700 mb-1">
                          Descripción
                        </label>
                        <textarea
                          rows={2}
                          className="w-full px-3 py-2 border border-gray-300 rounded text-sm"
                          placeholder="Describe los ingredientes y preparación..."
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {selectedPlan === 'premium' && (
                <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                  <h5 className="font-medium text-orange-900 mb-2">
                    <Crown className="w-4 h-4 inline mr-1" />
                    Funciones Premium del Menú
                  </h5>
                  <ul className="text-sm text-orange-700 space-y-1">
                    <li>• Menú digital completo con categorías</li>
                    <li>• Fotos para cada plato</li>
                    <li>• Indicadores de alérgenos</li>
                    <li>• Precios especiales y ofertas</li>
                    <li>• Actualización en tiempo real</li>
                  </ul>
                </div>
              )}

              <div>
                <h4 className="font-medium text-gray-900 mb-3">Rango de precios</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Precio medio por persona
                    </label>
                    <select className="w-full px-3 py-2 border border-gray-300 rounded-lg">
                      <option value="">Seleccionar rango</option>
                      <option value="10-20">€10 - €20</option>
                      <option value="20-30">€20 - €30</option>
                      <option value="30-50">€30 - €50</option>
                      <option value="50+">€50+</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Métodos de pago
                    </label>
                    <div className="space-y-2">
                      {['Efectivo', 'Tarjeta', 'Bizum', 'PayPal'].map((method) => (
                        <label key={method} className="flex items-center">
                          <input type="checkbox" className="mr-2" defaultChecked />
                          <span className="text-sm text-gray-700">{method}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 6:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <Shield className="w-16 h-16 text-orange-500 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Verificación de identidad</h3>
              <p className="text-gray-600">Para proteger a todos los usuarios, necesitamos verificar tu identidad</p>
            </div>

            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Documento de identidad *
                  </label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-orange-500 transition-colors cursor-pointer">
                    <FileText className="w-6 h-6 text-gray-400 mx-auto mb-1" />
                    <p className="text-xs text-gray-600">DNI, NIE o Pasaporte (ambas caras)</p>
                    <input type="file" className="hidden" accept=".pdf,.jpg,.jpeg,.png" />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Selfie con documento *
                  </label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-orange-500 transition-colors cursor-pointer">
                    <FileText className="w-6 h-6 text-gray-400 mx-auto mb-1" />
                    <p className="text-xs text-gray-600">Foto tuya sosteniendo el documento</p>
                    <input type="file" className="hidden" accept=".jpg,.jpeg,.png" />
                  </div>
                </div>
              </div>

              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex items-start gap-3">
                  <Shield className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-blue-900 mb-1">¿Por qué necesitamos esto?</h4>
                    <ul className="text-sm text-blue-700 space-y-1">
                      <li>• Prevenir perfiles falsos</li>
                      <li>• Proteger a los restaurantes reales</li>
                      <li>• Cumplir con regulaciones de seguridad</li>
                      <li>• Generar confianza en la plataforma</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-green-900 mb-1">Tus datos están seguros</h4>
                    <p className="text-sm text-green-700">
                      Utilizamos encriptación de nivel bancario y cumplimos con GDPR. 
                      Tus documentos solo se usan para verificación y se eliminan después del proceso.
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-medium text-gray-900 mb-3">Información personal</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Nombre completo *
                    </label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      placeholder="Como aparece en tu documento"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Número de documento *
                    </label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      placeholder="12345678A"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Fecha de nacimiento *
                    </label>
                    <input
                      type="date"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Teléfono personal *
                    </label>
                    <input
                      type="tel"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      placeholder="+34 XXX XXX XXX"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 7:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <FileText className="w-16 h-16 text-orange-500 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Documentos de propiedad</h3>
              <p className="text-gray-600">Protege y verifica tu negocio</p>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
              <div className="flex items-start gap-3">
                <Shield className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <h4 className="font-medium text-blue-900 mb-1">Protege tu propiedad (Recomendado)</h4>
                  <p className="text-sm text-blue-700">
                    Aunque no es obligatorio, subir documentos de propiedad te ayuda a proteger tu restaurante 
                    de reclamaciones fraudulentas y acelera el proceso de verificación.
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                  Licencia de apertura
                  <span className="text-xs text-green-600 bg-green-100 px-2 py-0.5 rounded-full">Recomendado</span>
                </label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-orange-500 transition-colors cursor-pointer">
                  <FileText className="w-6 h-6 text-gray-400 mx-auto mb-1" />
                  <p className="text-xs text-gray-600">Arrastra aquí tu licencia de apertura o haz clic para seleccionar (Opcional)</p>
                  <input type="file" className="hidden" accept=".pdf,.jpg,.jpeg,.png" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                  Certificado de manipulador de alimentos
                  <span className="text-xs text-green-600 bg-green-100 px-2 py-0.5 rounded-full">Recomendado</span>
                </label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-orange-500 transition-colors cursor-pointer">
                  <FileText className="w-6 h-6 text-gray-400 mx-auto mb-1" />
                  <p className="text-xs text-gray-600">Arrastra aquí tu certificado o haz clic para seleccionar (Opcional)</p>
                  <input type="file" className="hidden" accept=".pdf,.jpg,.jpeg,.png" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                  Seguro de responsabilidad civil
                  <span className="text-xs text-green-600 bg-green-100 px-2 py-0.5 rounded-full">Recomendado</span>
                </label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-orange-500 transition-colors cursor-pointer">
                  <FileText className="w-6 h-6 text-gray-400 mx-auto mb-1" />
                  <p className="text-xs text-gray-600">Arrastra aquí tu póliza de seguro o haz clic para seleccionar (Opcional)</p>
                  <input type="file" className="hidden" accept=".pdf,.jpg,.jpeg,.png" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                  Otros documentos de propiedad
                  <span className="text-xs text-gray-500 bg-gray-100 px-2 py-0.5 rounded-full">Opcional</span>
                </label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-orange-500 transition-colors cursor-pointer">
                  <FileText className="w-6 h-6 text-gray-400 mx-auto mb-1" />
                  <p className="text-xs text-gray-600">Contrato de alquiler, escrituras, etc. (Opcional)</p>
                  <input type="file" className="hidden" accept=".pdf,.jpg,.jpeg,.png" />
                </div>
              </div>
            </div>

            <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-yellow-600 mt-0.5" />
                <div>
                  <p className="text-sm text-yellow-800">
                    <strong>Importante:</strong> Sin documentos de propiedad, tu restaurante podría ser 
                    vulnerable a reclamaciones de terceros. Te recomendamos subir al menos la licencia de apertura.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <h5 className="font-medium text-blue-900 mb-2">Proceso de Verificación</h5>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• Revisión de documentos: 24-48 horas</li>
                <li>• Verificación telefónica</li>
                <li>• Activación del perfil</li>
                <li>• Notificación por email</li>
                <li>• Verificación de información ({selectedPlan === 'premium' ? '12-24h' : '24-48h'})</li>
                {selectedPlan === 'basic' && (
                  <li>• Opción de upgrade a Premium disponible</li>
                )}
              </ul>
            </div>

            {selectedPlan === 'premium' && (
              <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                <h5 className="font-medium text-orange-900 mb-2">
                  <Crown className="w-4 h-4 inline mr-1" />
                  Beneficios Premium
                </h5>
                <ul className="text-sm text-orange-700 space-y-1">
                  <li>• Verificación prioritaria (12-24h)</li>
                  <li>• Soporte dedicado</li>
                  <li>• Configuración asistida</li>
                  <li>• Posición destacada desde el día 1</li>
                </ul>
              </div>
            )}

            {mode === 'claim' && (
              <div className="mt-6 p-4 bg-orange-50 border border-orange-200 rounded-lg">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-orange-900 mb-1">Documentos adicionales para reclamación</h4>
                    <p className="text-sm text-orange-700">
                      Para verificar la propiedad, necesitarás subir documentos que demuestren que eres el propietario o tienes autorización legal para gestionar este restaurante.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        );

      default:
        return null;
    }
  };

  const getStepStatus = (step: number) => {
    if (step < currentStep) return 'completed';
    if (step === currentStep) return 'current';
    return 'upcoming';
  };

  const totalSteps = 7;

  return (
    <>
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[95vh] overflow-hidden shadow-2xl">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-200">
            <div>
              <h2 className="text-xl font-bold text-gray-900">
                {mode === 'register' ? 'Registro de Restaurante' : 'Reclamar Restaurante'}
              </h2>
              <p className="text-sm text-gray-600 mt-1">Paso {currentStep} de {totalSteps}</p>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>

          {/* Progress Steps */}
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              {Array.from({ length: totalSteps }, (_, i) => i + 1).map((step) => {
                const status = getStepStatus(step);
                return (
                  <div key={step} className="flex items-center">
                    <div className={`
                      w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium
                      ${status === 'completed' ? 'bg-green-500 text-white' : 
                        status === 'current' ? 'bg-orange-500 text-white' : 
                        'bg-gray-200 text-gray-600'}
                    `}>
                      {status === 'completed' ? (
                        <CheckCircle className="w-4 h-4" />
                      ) : (
                        step
                      )}
                    </div>
                    {step < totalSteps && (
                      <div className={`
                        w-12 h-0.5 mx-1
                        ${step < currentStep ? 'bg-green-500' : 'bg-gray-200'}
                      `} />
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Content */}
          <div className="p-6 overflow-y-auto max-h-[60vh]">
            {renderStepContent()}
          </div>

          {/* Footer */}
          <div className="flex items-center justify-between p-6 border-t border-gray-200 bg-gray-50">
            <button
              onClick={handlePrevious}
              disabled={currentStep === 1}
              className="px-6 py-2 text-gray-600 hover:text-gray-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Anterior
            </button>

            <div className="flex space-x-3">
              <button
                onClick={onClose}
                className="px-6 py-2 text-gray-600 hover:text-gray-800 transition-colors"
              >
                Cancelar
              </button>
              
              {currentStep < totalSteps ? (
                <button
                  onClick={handleNext}
                  className="px-6 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  Siguiente
                </button>
              ) : (
                <button
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                  className="px-6 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center space-x-2"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Enviando...</span>
                    </>
                  ) : (
                    <span>{mode === 'register' ? 'Completar Registro' : 'Enviar Reclamación'}</span>
                  )}
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {renderPlanBenefits()}
    </>
  );
};

export default RestaurantRegistrationModal;