import React from 'react';
import { X, MapPin, Calendar, Clock, Eye, Share2, Phone, ExternalLink, Bookmark, BookmarkCheck } from 'lucide-react';
import { Event } from '../../types';

interface EventModalProps {
  isOpen: boolean;
  onClose: () => void;
  event: Event | null;
  onViewRestaurant: (restaurantId: string) => void;
  isEventSaved?: boolean;
  onSaveEvent?: (event: Event) => void;
  onUnsaveEvent?: (eventId: string) => void;
  onShare?: (event: Event) => void;
}

const EventModal: React.FC<EventModalProps> = ({
  isOpen,
  onClose,
  event,
  onViewRestaurant,
  isEventSaved = false,
  onSaveEvent,
  onUnsaveEvent,
  onShare
}) => {
  if (!isOpen || !event) return null;

  // Format distance display
  const formatDistance = (distance: number) => {
    if (distance < 1000) {
      return `${distance}m`;
    } else {
      return `${(distance / 1000).toFixed(1)}km`;
    }
  };

  // Format date display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-ES', { 
      weekday: 'long', 
      year: 'numeric',
      month: 'long', 
      day: 'numeric' 
    });
  };

  // Get event type icon
  const getEventTypeIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'espectáculo': return '🎭';
      case 'cata': return '🍷';
      case 'taller': return '👨‍🍳';
      case 'social': return '🎉';
      case 'gastronómico': return '🍽️';
      default: return '🎪';
    }
  };

  // Mock reservation link - in real app this would come from restaurant configuration
  const reservationLink = event.restaurant.id === '3' ? 'https://wa.me/34954456789' : null;

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: event.name,
        text: `${event.name} en ${event.restaurant.name} - ${formatDate(event.date)} a las ${event.time}`,
        url: window.location.href
      }).catch(() => {
        // If share fails or is cancelled, fall back to clipboard
        const shareText = `🎪 ${event.name}\n📍 ${event.restaurant.name}\n📅 ${formatDate(event.date)} - ${event.time}\n\n${event.description}\n\n¡Descúbrelo en LaCartica!`;
        navigator.clipboard.writeText(shareText).then(() => {
          alert('¡Enlace copiado al portapapeles!');
        });
      });
    } else {
      // Fallback: copy to clipboard
      const shareText = `🎪 ${event.name}\n📍 ${event.restaurant.name}\n📅 ${formatDate(event.date)} - ${event.time}\n\n${event.description}\n\n¡Descúbrelo en LaCartica!`;
      navigator.clipboard.writeText(shareText).then(() => {
        alert('¡Enlace copiado al portapapeles!');
      });
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-hidden shadow-2xl">
        {/* Header with image */}
        <div className="relative h-48 md:h-64">
          {event.image ? (
            <img
              src={event.image}
              alt={event.name}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-purple-100 to-purple-200">
              <div className="text-center">
                <div className="text-6xl mb-2">{getEventTypeIcon(event.eventType)}</div>
                <div className="text-lg font-medium text-gray-700">{event.eventType}</div>
              </div>
            </div>
          )}
          
          {/* Overlay badges */}
          {/* No overlay badges */}

          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 bg-white bg-opacity-90 hover:bg-opacity-100 rounded-full transition-all shadow-sm"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>

          {/* Action buttons */}
          <div className="absolute bottom-4 right-4 flex gap-2">
            {onSaveEvent && onUnsaveEvent && (
              <button 
                onClick={() => isEventSaved ? onUnsaveEvent(event.id) : onSaveEvent(event)}
                className="p-2 bg-white bg-opacity-90 hover:bg-opacity-100 rounded-full transition-all shadow-sm"
              >
                {isEventSaved ? (
                  <BookmarkCheck className="w-5 h-5 text-orange-600" />
                ) : (
                  <Bookmark className="w-5 h-5 text-gray-600" />
                )}
              </button>
            )}
            <button 
              onClick={handleShare}
              className="p-2 bg-white bg-opacity-90 hover:bg-opacity-100 rounded-full transition-all shadow-sm"
            >
              <Share2 className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </div>

        <div className="overflow-y-auto max-h-[calc(90vh-200px)]">
          {/* Content */}
          <div className="p-6">
            {/* Title and price */}
            <div className="flex items-start justify-between gap-4 mb-4">
              <div className="flex-1">
                <h1 className="text-2xl font-bold text-gray-900 mb-2">{event.name}</h1>
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-purple-600 font-medium">
                    {getEventTypeIcon(event.eventType)} {event.eventType}
                  </span>
                  <span className="text-gray-400">•</span>
                  <button 
                    onClick={() => onViewRestaurant(event.restaurant.id)}
                    className="text-blue-600 hover:text-blue-800 font-medium flex items-center gap-1"
                  >
                    {event.restaurant.name}
                    <ExternalLink className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <div className="text-right">
                {event.isFree ? (
                  <div className="text-2xl font-bold text-green-600">GRATIS</div>
                ) : (
                  <div className="text-2xl font-bold text-gray-900">€{event.price.toFixed(2)}</div>
                )}
              </div>
            </div>

            {/* Event details */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
              <div className="text-center">
                <Calendar className="w-5 h-5 text-gray-600 mx-auto mb-1" />
                <div className="text-sm font-medium text-gray-900">{formatDate(event.date)}</div>
              </div>
              <div className="text-center">
                <Clock className="w-5 h-5 text-gray-600 mx-auto mb-1" />
                <div className="text-sm font-medium text-gray-900">{event.time}</div>
                <div className="text-xs text-gray-500">{event.duration}</div>
              </div>
              <div className="text-center">
                <Eye className="w-5 h-5 text-gray-600 mx-auto mb-1" />
                <div className="text-sm font-medium text-gray-900">{event.views}</div>
                <div className="text-xs text-gray-500">visualizaciones</div>
              </div>
              <div className="text-center">
                <MapPin className="w-5 h-5 text-gray-600 mx-auto mb-1" />
                <div className="text-sm font-medium text-gray-900">{formatDistance(event.distance)}</div>
                <div className="text-xs text-gray-500">de distancia</div>
              </div>
            </div>

            {/* Description */}
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Descripción</h3>
              <p className="text-gray-700 leading-relaxed">{event.description}</p>
            </div>

            {/* What's included */}
            {event.includes.length > 0 && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">¿Qué incluye?</h3>
                <ul className="space-y-2">
                  {event.includes.map((item, index) => (
                    <li key={index} className="flex items-center gap-2 text-gray-700">
                      <span className="w-2 h-2 bg-green-500 rounded-full flex-shrink-0"></span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Tags */}
            {event.tags.length > 0 && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Características</h3>
                <div className="flex flex-wrap gap-2">
                  {event.tags.map((tag, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Additional info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              {event.ageRestriction && (
                <div className="p-3 bg-blue-50 rounded-lg">
                  <div className="text-sm font-medium text-blue-900">Edad recomendada</div>
                  <div className="text-sm text-blue-700">{event.ageRestriction}</div>
                </div>
              )}
              {event.dresscode && (
                <div className="p-3 bg-purple-50 rounded-lg">
                  <div className="text-sm font-medium text-purple-900">Código de vestimenta</div>
                  <div className="text-sm text-purple-700">{event.dresscode}</div>
                </div>
              )}
              {event.requiresReservation && (
                <div className="p-3 bg-orange-50 rounded-lg">
                  <div className="text-sm font-medium text-orange-900">Reserva</div>
                  <div className="text-sm text-orange-700">Reserva obligatoria</div>
                </div>
              )}
            </div>

            {/* Restaurant info */}
            <div className="border-t pt-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Información del restaurante</h3>
              <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                  <span className="text-xl">🏪</span>
                </div>
                <div className="flex-1">
                  <div className="font-medium text-gray-900">{event.restaurant.name}</div>
                  <div className="text-sm text-gray-600">{event.restaurant.address}</div>
                  <div className="text-sm text-gray-600">{event.restaurant.cuisineType}</div>
                </div>
                <div className="flex gap-2">
                  <button className="p-2 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                    <Phone className="w-4 h-4 text-gray-600" />
                  </button>
                  <button 
                    onClick={() => onViewRestaurant(event.restaurant.id)}
                    className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
                  >
                    Ver perfil
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          {reservationLink && (
            <div className="border-t bg-gray-50 p-6">
              <div className="flex justify-center">
                <a
                  href={reservationLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-8 py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors font-medium flex items-center gap-2"
                >
                  <Phone className="w-4 h-4" />
                  {event.requiresReservation ? 'Reservar plaza' : 'Contactar para apuntarse'}
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default EventModal;