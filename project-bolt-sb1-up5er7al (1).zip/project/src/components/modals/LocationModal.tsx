/**
 * Modern Location Search Modal for Restaurants
 * Advanced GPS + Manual search with autocomplete and categorization
 */

import React, { useState, useEffect, useRef } from 'react';
import { X, Navigation, Search, MapPin, Users, Store, Building, Star, Target, Clock } from 'lucide-react';
import { Location } from '../../types';
import { useLocationSearch } from '../../hooks/useSupabaseData';
import { getRestaurantCountForLocation } from '../../services/locationService';

interface LocationModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLocation: Location | null;
  onLocationSelect: (location: Location) => void;
}

// Get type label
function getTypeLabel(type: string): string {
  switch (type) {
    case 'city': return 'Ciudad';
    case 'district': return 'Distrito';
    case 'municipality': return 'Municipio';
    default: return 'Ubicación';
  }
}

const LocationModal: React.FC<LocationModalProps> = ({
  isOpen,
  onClose,
  currentLocation,
  onLocationSelect
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showResults, setShowResults] = useState(false);
  const [gpsLocation, setGpsLocation] = useState<any>(null);
  const [selectedLocation, setSelectedLocation] = useState<any>(null);
  const [isGpsLoading, setIsGpsLoading] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);
  
  const { locations: searchResults, isSearching, searchLocationOptions } = useLocationSearch();
  const searchInputRef = useRef<HTMLInputElement>(null);
  const resultsRef = useRef<HTMLDivElement>(null);

  // Handle search input
  useEffect(() => {
    searchLocationOptions(searchQuery);
    setShowResults(searchQuery.length >= 2 && searchResults.length > 0);
  }, [searchQuery, searchLocationOptions]);

  // Update showResults when searchResults change
  useEffect(() => {
    setShowResults(searchQuery.length >= 2 && searchResults.length > 0);
  }, [searchResults, searchQuery]);

  // Handle GPS location
  const handleGpsLocation = async () => {
    setIsGpsLoading(true);
    setGpsError(null);
    
    try {
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0
        });
      });
      
      const { latitude, longitude } = position.coords;
      
      // Find nearest location
      const nearest = await findNearestLocationFromDB(latitude, longitude);
      
      if (nearest) {
        setGpsLocation({
          lat: latitude,
          lng: longitude,
          accuracy: position.coords.accuracy,
          nearest: nearest
        });
        
        setSelectedLocation(nearest);
      }
      
    } catch (error) {
      setGpsError('Error al obtener la ubicación GPS. Verifica los permisos.');
      console.error('GPS Error:', error);
    } finally {
      setIsGpsLoading(false);
    }
  };

  // Find nearest location from database
  const findNearestLocationFromDB = async (userLat: number, userLng: number) => {
    try {
      const { data: cities } = await supabase
        .from('cities')
        .select('*')
        .limit(50);

      if (!cities || cities.length === 0) return null;

      let nearest = cities[0];
      let minDistance = calculateDistance(userLat, userLng, nearest.latitude, nearest.longitude);

      for (const city of cities) {
        const distance = calculateDistance(userLat, userLng, city.latitude, city.longitude);
        if (distance < minDistance) {
          minDistance = distance;
          nearest = city;
        }
      }

      return { ...nearest, distance: minDistance, type: 'city', lat: nearest.latitude, lng: nearest.longitude };
    } catch (error) {
      console.error('Error finding nearest location:', error);
      return null;
    }
  };

  // Calculate distance helper
  function calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
    const R = 6371e3;
    const φ1 = lat1 * Math.PI / 180;
    const φ2 = lat2 * Math.PI / 180;
    const Δφ = (lat2 - lat1) * Math.PI / 180;
    const Δλ = (lng2 - lng1) * Math.PI / 180;

    const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c;
  }

  // Handle location selection
  const handleLocationSelect = (location: any) => {
    setSelectedLocation(location);
    setSearchQuery(location.name);
    setShowResults(false);
  };

  // Handle final selection
  const handleFinalSelect = () => {
    if (selectedLocation) {
      const newLocation: Location = {
        latitude: selectedLocation.latitude || selectedLocation.lat,
        longitude: selectedLocation.longitude || selectedLocation.lng,
        address: selectedLocation.name,
        name: selectedLocation.name
      };
      onLocationSelect(newLocation);
      onClose();
    }
  };

  // Close results on click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        resultsRef.current && 
        !resultsRef.current.contains(event.target as Node) &&
        !searchInputRef.current?.contains(event.target as Node)
      ) {
        setShowResults(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Initialize GPS on open
  useEffect(() => {
    if (isOpen) {
      handleGpsLocation();
    }
  }, [isOpen]);

  if (!isOpen) return null;


  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl sm:rounded-3xl max-w-lg sm:max-w-2xl w-full max-h-[95vh] sm:max-h-[90vh] overflow-hidden shadow-2xl border border-gray-100/20">
        
        {/* === HEADER === */}
        <div className="flex items-center justify-between p-4 sm:p-6 border-b border-gray-100/50 bg-gradient-to-r from-orange-50/80 via-blue-50/80 to-purple-50/80">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 sm:w-12 sm:h-12 bg-gradient-to-br from-orange-500 to-blue-600 rounded-xl sm:rounded-2xl flex items-center justify-center shadow-lg">
              <MapPin className="w-4 h-4 sm:w-6 sm:h-6 text-white" />
            </div>
            <div>
              <h2 className="text-base sm:text-xl font-bold text-gray-900 tracking-tight">Selecciona tu ubicación</h2>
              <p className="text-xs sm:text-sm text-gray-600 mt-0.5">
                Encuentra restaurantes cerca de ti
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 sm:p-2.5 hover:bg-white/60 rounded-lg sm:rounded-xl transition-all duration-200 hover:scale-105"
          >
            <X className="w-5 h-5 sm:w-6 sm:h-6 text-gray-600" />
          </button>
        </div>

        <div className="overflow-y-auto max-h-[calc(95vh-120px)] sm:max-h-[calc(90vh-140px)]">
          <div className="p-4 sm:p-6 space-y-4 sm:space-y-8">
            
            {/* === USE CURRENT LOCATION === */}
            <div className="text-center">
              <button
                onClick={handleGpsLocation}
                disabled={isGpsLoading}
                className={`
                  w-full flex items-center justify-center gap-2 sm:gap-3 p-3 sm:p-4 rounded-lg sm:rounded-xl border-2 transition-all duration-200 max-w-sm sm:max-w-md mx-auto
                  ${isGpsLoading 
                    ? 'border-orange-300 bg-orange-50 cursor-not-allowed' 
                    : 'border-orange-200 bg-orange-50 hover:bg-orange-100 hover:border-orange-300 hover:scale-105'
                  }
                `}
              >
                <Navigation className={`w-4 h-4 sm:w-5 sm:h-5 text-orange-600 ${isGpsLoading ? 'animate-spin' : ''}`} />
                <div className="text-left">
                  <div className="font-semibold text-gray-900 text-sm sm:text-base">
                    {isGpsLoading ? 'Obteniendo ubicación...' : '📍 Usar mi ubicación actual'}
                  </div>
                  <div className="text-xs sm:text-sm text-gray-600">
                    {isGpsLoading ? 'Detectando con GPS y WiFi...' : 'Precisión hasta 10m • GPS + WiFi'}
                  </div>
                </div>
              </button>
            </div>

            {/* === SEARCH BAR === */}
            <div className="relative">
              <div className="relative group">
                <div className="absolute inset-0 bg-gradient-to-r from-orange-200/20 to-blue-200/20 rounded-lg sm:rounded-2xl blur opacity-0 group-focus-within:opacity-100 transition-all duration-300"></div>
                <div className="relative">
                  <Search className="absolute left-3 sm:left-5 top-1/2 transform -translate-y-1/2 w-4 h-4 sm:w-5 sm:h-5 text-gray-400 group-focus-within:text-orange-500 transition-colors duration-200" />
                <input
                  ref={searchInputRef}
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Buscar por nombre, barrio, distrito..."
                    className="w-full pl-10 pr-10 py-3 sm:pl-14 sm:pr-14 sm:py-5 border-2 border-gray-200 rounded-lg sm:rounded-2xl focus:border-orange-500 focus:ring-2 sm:focus:ring-4 focus:ring-orange-100 transition-all duration-200 bg-white/80 backdrop-blur-sm text-sm sm:text-base placeholder-gray-500 font-medium"
                  onFocus={() => searchResults.length > 0 && setShowResults(true)}
                />
                {searchQuery && (
                  <button
                    onClick={() => {
                      setSearchQuery('');
                      setShowResults(false);
                    }}
                      className="absolute right-3 sm:right-5 top-1/2 transform -translate-y-1/2 p-1 sm:p-1.5 hover:bg-gray-100 rounded-full transition-all duration-200 hover:scale-110"
                  >
                    <X className="w-3 h-3 sm:w-4 sm:h-4 text-gray-400" />
                  </button>
                )}
                </div>
              </div>

              {/* === SEARCH RESULTS DROPDOWN === */}
              {showResults && searchResults.length > 0 && (
                <div
                  ref={resultsRef}
                  className="absolute top-full left-0 right-0 mt-2 sm:mt-3 bg-white/95 backdrop-blur-sm border border-gray-200/50 rounded-lg sm:rounded-2xl shadow-2xl z-50 max-h-60 sm:max-h-80 overflow-y-auto"
                >
                  {searchResults.map((result, index) => (
                    <button
                      key={result.id}
                      onClick={() => handleLocationSelect(result)}
                      className="w-full flex items-center gap-3 sm:gap-4 p-3 sm:p-4 hover:bg-gradient-to-r hover:from-orange-50/50 hover:to-blue-50/50 transition-all duration-200 border-b border-gray-100/50 last:border-b-0 first:rounded-t-lg first:sm:rounded-t-2xl last:rounded-b-lg last:sm:rounded-b-2xl group"
                    >
                      <div className="flex-1 text-left">
                        <div className="font-semibold text-gray-900 text-sm sm:text-base group-hover:text-orange-700 transition-colors">{result.name}</div>
                        <div className="text-xs sm:text-sm text-gray-600 mt-0.5">
                          {getTypeLabel(result.type)}
                          {result.parent && ` • ${result.parent}`}
                        </div>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <div className="text-xs sm:text-sm font-medium text-gray-600 bg-gray-100 px-2 py-1 sm:px-3 sm:py-1.5 rounded-full">
                          {result.restaurantCount || 0} restaurantes
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* === GPS LOCATION CARD === */}
            <div className="text-center">
              {gpsError && (
                <div className="text-red-600 text-xs sm:text-sm font-medium bg-red-50 px-3 py-1.5 sm:px-4 sm:py-2 rounded-lg sm:rounded-xl border border-red-200">{gpsError}</div>
              )}
              
              {gpsLocation && (
                <div className="text-xs sm:text-sm text-green-600 font-medium bg-green-50 px-3 py-1.5 sm:px-4 sm:py-2 rounded-lg sm:rounded-xl border border-green-200">
                  ✓ Ubicación detectada: {gpsLocation.nearest.name}
                </div>
              )}
            </div>

          </div>
        </div>

        {/* === FOOTER === */}
        <div className="flex flex-col sm:flex-row items-center justify-between p-4 sm:p-6 border-t border-gray-100/50 bg-gradient-to-r from-gray-50/80 to-gray-100/80 gap-3 sm:gap-0">
          <div className="text-xs sm:text-sm text-gray-600 font-medium text-center sm:text-left">
            {selectedLocation ? (
              <span className="text-green-600 font-semibold bg-green-50 px-2 py-1 sm:px-3 sm:py-1 rounded-full text-xs sm:text-sm">
                ✓ {selectedLocation.name} seleccionado
              </span>
            ) : (
              'Selecciona una ubicación para continuar'
            )}
          </div>
          <div className="flex gap-2 sm:gap-3 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="flex-1 sm:flex-none px-4 sm:px-6 py-2 sm:py-3 border border-gray-300 text-gray-700 rounded-lg sm:rounded-xl hover:bg-gray-50 hover:border-gray-400 transition-all duration-200 font-medium text-sm sm:text-base"
            >
              Cancelar
            </button>
            <button
              onClick={handleFinalSelect}
              disabled={!selectedLocation}
              className="flex-1 sm:flex-none px-4 sm:px-6 py-2 sm:py-3 bg-gradient-to-r from-orange-600 to-orange-500 text-white rounded-lg sm:rounded-xl hover:from-orange-700 hover:to-orange-600 hover:scale-105 disabled:from-gray-300 disabled:to-gray-300 disabled:cursor-not-allowed disabled:scale-100 transition-all duration-200 font-medium shadow-lg shadow-orange-200/30 text-sm sm:text-base"
            >
              Seleccionar Ubicación
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LocationModal;