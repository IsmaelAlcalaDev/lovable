import React, { useState } from 'react';
import { X, Calendar, Bell, Clock } from 'lucide-react';
import { Event } from '../../types';

interface SaveEventModalProps {
  isOpen: boolean;
  onClose: () => void;
  event: Event | null;
  onSave: (eventId: string, reminderType: 'notification' | 'calendar' | 'both', reminderTime: string) => void;
}

const SaveEventModal: React.FC<SaveEventModalProps> = ({
  isOpen,
  onClose,
  event,
  onSave
}) => {
  const [reminderType, setReminderType] = useState<'notification' | 'calendar' | 'both'>('notification');
  const [reminderTime, setReminderTime] = useState('1 hour before');

  if (!isOpen || !event) return null;

  const handleSave = () => {
    onSave(event.id, reminderType, reminderTime);
  };

  const addToGoogleCalendar = () => {
    const eventDate = new Date(event.date + 'T' + event.time);
    const endDate = new Date(eventDate.getTime() + 2 * 60 * 60 * 1000); // +2 hours
    
    const googleCalendarUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(event.name)}&dates=${eventDate.toISOString().replace(/[-:]/g, '').split('.')[0]}Z/${endDate.toISOString().replace(/[-:]/g, '').split('.')[0]}Z&details=${encodeURIComponent(event.description)}&location=${encodeURIComponent(event.restaurant.address)}`;
    
    window.open(googleCalendarUrl, '_blank');
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-sm sm:max-w-md w-full max-h-[95vh] overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-6 border-b bg-gradient-to-r from-orange-50 to-blue-50">
          <div className="flex items-center gap-3">
            <Calendar className="w-5 h-5 sm:w-6 sm:h-6 text-orange-600" />
            <div>
              <h2 className="text-lg sm:text-xl font-semibold text-gray-900">Guardar evento</h2>
              <p className="text-xs sm:text-sm text-gray-600">Configura recordatorios para este evento</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 sm:p-2 hover:bg-white hover:bg-opacity-50 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 sm:w-6 sm:h-6 text-gray-600" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 sm:space-y-6">
          {/* Event Info */}
          <div className="bg-gray-50 rounded-lg p-3 sm:p-4">
            <h3 className="font-semibold text-base sm:text-lg text-gray-900 mb-1">{event.name}</h3>
            <p className="text-xs sm:text-sm text-gray-600 mb-1.5">{event.restaurant.name}</p>
            <div className="flex items-center gap-4 text-xxs sm:text-xs text-gray-500">
              <span>{new Date(event.date).toLocaleDateString('es-ES')}</span>
              <span>{event.time}</span>
              <span>{event.duration}</span>
            </div>
          </div>

          {/* Reminder Type */}
          <div>
            <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-2 sm:mb-3">
              Tipo de recordatorio
            </label>
            <div className="space-y-2 sm:space-y-3">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="radio"
                  name="reminderType"
                  value="notification"
                  checked={reminderType === 'notification'}
                  onChange={(e) => setReminderType(e.target.value as any)}
                  className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-orange-600 border-gray-300 focus:ring-orange-500"
                />
                <div className="flex items-center gap-2">
                  <Bell className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-blue-600" />
                  <span className="text-xs sm:text-sm text-gray-900">Solo notificación</span>
                </div>
              </label>

              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="radio"
                  name="reminderType"
                  value="calendar"
                  checked={reminderType === 'calendar'}
                  onChange={(e) => setReminderType(e.target.value as any)}
                  className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-orange-600 border-gray-300 focus:ring-orange-500"
                />
                <div className="flex items-center gap-2">
                  <Calendar className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-green-600" />
                  <span className="text-xs sm:text-sm text-gray-900">Solo calendario</span>
                </div>
              </label>

              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="radio"
                  name="reminderType"
                  value="both"
                  checked={reminderType === 'both'}
                  onChange={(e) => setReminderType(e.target.value as any)}
                  className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-orange-600 border-gray-300 focus:ring-orange-500"
                />
                <div className="flex items-center gap-2">
                  <div className="flex">
                    <Bell className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-blue-600" />
                    <Calendar className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-green-600 -ml-1" />
                  </div>
                  <span className="text-xs sm:text-sm text-gray-900">Notificación y calendario</span>
                </div>
              </label>
            </div>
          </div>

          {/* Reminder Time */}
          <div>
            <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-2 sm:mb-3">
              Cuándo recordar
            </label>
            <select
              value={reminderTime}
              onChange={(e) => setReminderTime(e.target.value)}
              className="w-full px-2.5 sm:px-3 py-2 sm:py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-xs sm:text-sm"
            >
              <option value="15 minutes before">15 minutos antes</option>
              <option value="30 minutes before">30 minutos antes</option>
              <option value="1 hour before">1 hora antes</option>
              <option value="2 hours before">2 horas antes</option>
              <option value="1 day before">1 día antes</option>
              <option value="1 week before">1 semana antes</option>
            </select>
          </div>

          {/* Quick Calendar Action */}
          <div className="border-t pt-3 sm:pt-4">
            <button
              onClick={addToGoogleCalendar}
              className="w-full flex items-center justify-center gap-2 py-1.5 sm:py-2 text-xs sm:text-sm text-blue-600 hover:text-blue-700 font-medium"
            >
              <Calendar className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              Añadir directamente a Google Calendar
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="flex gap-3 p-4 sm:p-6 border-t bg-gray-50 flex-shrink-0">
          <button
            onClick={onClose}
            className="flex-1 py-2.5 sm:py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-semibold text-sm sm:text-base"
          >
            Cancelar
          </button>
          <button
            onClick={handleSave}
            className="flex-1 py-2.5 sm:py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors font-semibold text-sm sm:text-base"
          >
            Guardar evento
          </button>
        </div>
      </div>
    </div>
  );
};

export default SaveEventModal;